'use strict';
// Test double only. This is not MongoDB; assertions concern application control flow,
// HTTP behavior and namespace selection, not MongoDB server/driver correctness.
const {randomUUID}=require('crypto');
const copy=x=>structuredClone(x);
function values(o,path){const ks=path.split('.');function rec(a,i){if(i===ks.length)return [a];if(Array.isArray(a)&&!/^\d+$/.test(ks[i]))return a.flatMap(v=>rec(v,i));return rec(a?.[ks[i]],i+1)}return rec(o,0)}
const eq=(a,b)=> a instanceof Date&&b instanceof Date?+a===+b:JSON.stringify(a)===JSON.stringify(b);
function match(doc,q={}){return Object.entries(q).every(([k,v])=>{if(k==='$or')return v.some(z=>match(doc,z));if(k==='$and')return v.every(z=>match(doc,z));const vs=values(doc,k),xs=vs.flatMap(x=>Array.isArray(x)?x:[x]);if(v&&typeof v==='object'&&!Array.isArray(v)&&!(v instanceof Date)&&Object.keys(v).some(x=>x.startsWith('$')))return Object.entries(v).every(([op,z])=>{switch(op){case '$exists':return z?vs.some(x=>x!==undefined):vs.every(x=>x===undefined);case '$in':return xs.some(x=>z.some(t=>eq(x,t)));case '$ne':return xs.every(x=>!eq(x,z));case '$nin':return xs.every(x=>!z.some(t=>eq(x,t)));case '$gt':return xs.some(x=>x>z);case '$gte':return xs.some(x=>x>=z);case '$lt':return xs.some(x=>x<z);case '$lte':return xs.some(x=>x<=z);default:throw Error('Unsupported query operator: '+op)}});return xs.some(x=>eq(x,v))||vs.some(x=>eq(x,v))})}
function get(d,k){return values(d,k)[0]}
function set(d,k,v){const ks=k.split('.');let t=d;for(const a of ks.slice(0,-1))t=t[a]??={};t[ks.at(-1)]=copy(v)}
function unset(d,k){const ks=k.split('.');let t=d;for(const a of ks.slice(0,-1)){t=t?.[a];if(!t)return}delete t[ks.at(-1)]}
function expr(d,x){if(typeof x==='string'&&x.startsWith('$'))return get(d,x.slice(1));if(!x||typeof x!=='object')return x;if(Array.isArray(x))return x.map(v=>expr(d,v));const [k,v]=Object.entries(x)[0];switch(k){case '$in':{const [a,b]=expr(d,v);return b.some(z=>eq(z,a))}case '$ifNull':{const [a,b]=expr(d,v);return a??b}case '$cond':return expr(d,expr(d,v[0])?v[1]:v[2]);case '$and':return expr(d,v).every(Boolean);default:return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,expr(d,v)]))}}
class Cursor{constructor(a,projection){this.a=copy(a);if(projection){const inc=Object.values(projection).some(Boolean);this.a=this.a.map(d=>{if(inc){const r={};if(projection._id!==0&&d._id!==undefined)r._id=d._id;for(const[k,v]of Object.entries(projection))if(v&&get(d,k)!==undefined)set(r,k,get(d,k));return r}for(const[k,v]of Object.entries(projection))if(!v)unset(d,k);return d})}}sort(q){this.a.sort((a,b)=>{for(const[k,v]of Object.entries(q)){const x=get(a,k),y=get(b,k);if(x<y)return -v;if(x>y)return v}return 0});return this}limit(n){this.a=this.a.slice(0,n);return this}async next(){return this.a.shift()??null}async toArray(){return copy(this.a)}}
class MemoryDB{
 constructor(initial={}){this.databaseName='readiness_test_independent_audit';this.data=copy(initial);this.operations=[]}
 collection(n){const db=this;const rows=()=>db.data[n]??[];const write=(m)=>{db.operations.push({collection:n,method:m});return db.data[n]??=[]};const obj={
 find(q={},o={}){db.operations.push({collection:n,method:'find'});return new Cursor(rows().filter(d=>match(d,q)),o.projection)},
 async findOne(q={},o={}){return obj.find(q,o).next()}, async countDocuments(q={}){return rows().filter(d=>match(d,q)).length},
 aggregate(p){let a=copy(rows());for(const stage of p){const[k,v]=Object.entries(stage)[0];switch(k){case '$match':a=a.filter(d=>match(d,v));break;case '$set':a=a.map(d=>{const r=copy(d);for(const[k,x]of Object.entries(v))set(r,k,expr(d,x));return r});break;case '$unset':a.forEach(d=>(Array.isArray(v)?v:[v]).forEach(k=>unset(d,k)));break;case '$count':a=a.length?[{[v]:a.length}]:[];break;case '$group':{const m=new Map();for(const d of a){const key=expr(d,v._id);const t=m.get(key)??{_id:key};for(const[k,x]of Object.entries(v))if(k!=='_id'&&x.$sum!==undefined)t[k]=(t[k]??0)+(expr(d,x.$sum)??0);m.set(key,t)}a=[...m.values()];break}default:throw Error('Unsupported aggregate '+k)}}return new Cursor(a)},
 async insertOne(d){const r=write('insertOne');if(d._id!==undefined&&r.some(x=>eq(x._id,d._id)))throw Object.assign(Error('Duplicate'),{code:11000});r.push(copy({...d,_id:d._id??randomUUID()}));return{insertedId:r.at(-1)._id}},
 async insertMany(ds){for(const d of ds)await obj.insertOne(d);return{insertedCount:ds.length}},
 async updateOne(q,u,o={}){const rs=write('updateOne');let d=rs.find(d=>match(d,q)),insert=false;if(!d){if(!o.upsert)return{matchedCount:0,modifiedCount:0};d=Object.fromEntries(Object.entries(q).filter(([k,v])=>!k.startsWith('$')&&(v===null||typeof v!=='object')));d._id??=randomUUID();rs.push(d);insert=true}for(const[k,v]of Object.entries(u)){if(k==='$set'||(k==='$setOnInsert'&&insert)){for(const[a,b]of Object.entries(v))set(d,a,b)}else if(k==='$inc'){for(const[a,b]of Object.entries(v))set(d,a,(get(d,a)||0)+b)}else if(k==='$unset'){for(const a of Object.keys(v))unset(d,a)}else if(k==='$addToSet'){for(const[a,b]of Object.entries(v)){const ar=get(d,a)||[];const vals=b?.$each??[b];for(const z of vals)if(!ar.some(x=>eq(x,z)))ar.push(copy(z));set(d,a,ar)}}else if(k!=='$setOnInsert')throw Error('Unsupported update '+k)}return{matchedCount:insert?0:1,modifiedCount:1,upsertedCount:insert?1:0}},
 async updateMany(q,u){let n=0;for(const d of [...rows()])if(match(d,q)){await obj.updateOne({_id:d._id},u);n++}return{matchedCount:n,modifiedCount:n}},
 async replaceOne(q,d,o={}){const rs=write('replaceOne'),i=rs.findIndex(d=>match(d,q));if(i<0){if(o.upsert){rs.push(copy(d));return{matchedCount:0,upsertedCount:1}}return{matchedCount:0}}rs[i]=copy(d);return{matchedCount:1}},
 async deleteMany(q){const rs=write('deleteMany'),keep=rs.filter(d=>!match(d,q));db.data[n]=keep;return{deletedCount:rs.length-keep.length}},
 async deleteOne(q){const rs=write('deleteOne'),i=rs.findIndex(d=>match(d,q));if(i<0)return{deletedCount:0};rs.splice(i,1);return{deletedCount:1}},
 async findOneAndUpdate(q,u,o={}){const old=await obj.findOne(q);if(!old&&!o.upsert)return null;await obj.updateOne(q,u,o);return o.returnDocument==='after'?obj.findOne({_id:old?._id??q._id}):old},
 async findOneAndDelete(q){const old=await obj.findOne(q);if(old)await obj.deleteOne({_id:old._id});return old},
 async createIndex(){db.operations.push({collection:n,method:'createIndex'});return 'test_index'}, async dropIndex(){db.operations.push({collection:n,method:'dropIndex'})}
 };return obj}
 async command(q){return{ok:1,version:'IN_MEMORY_TEST_DOUBLE'}}admin(){return this}
 writes(){return this.operations.filter(x=>!['find'].includes(x.method))}
}
module.exports={MemoryDB,match};
