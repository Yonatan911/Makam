'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {runtime,createClient,draft,edit,refresh}=require('./bundle-functions.cjs');
const config={schemaVersion:1,apiBaseUrl:'https://api.example.invalid/makam/api',environment:'production',releaseVersion:'3.1.0',authMode:'iis-session'};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json'}});
test('Delivered bundle: runtime requires explicit API base/prefix and fails before network when missing',async()=>{
 assert.equal(runtime(config).apiBaseUrl,config.apiBaseUrl);
 assert.throws(()=>runtime());assert.throws(()=>runtime({...config,apiBaseUrl:'https://sp.example.invalid/'}));assert.throws(()=>runtime({...config,apiBaseUrl:'http://127.0.0.1:4310/api'}));
 let calls=0;const client=createClient({fetchImpl:async()=>{calls++;return json({})}});await assert.rejects(client.json('/state'));assert.equal(calls,0);
});
test('Delivered bundle: identity credentials separated from Bearer, no replay after failed write',async()=>{
 const calls=[];const client=createClient({runtime:runtime(config),fetchImpl:async(url,options)=>{calls.push({url,options});if(url.endsWith('/auth/session'))return json({token:'a'.repeat(64),expiresAt:new Date(Date.now()+3600000).toISOString()},201);return json({error:'Expired'},401)}});
 await client.authenticate();await assert.rejects(client.json('/rooms',{name:'AUDIT'}),e=>e.status===401&&e.state==='authExpired');
 assert.equal(calls.length,2);assert.equal(calls[0].options.credentials,'include');assert.equal(calls[1].options.credentials,'omit');assert.equal(calls[1].options.headers.get('Authorization'),'Bearer '+'a'.repeat(64));assert.equal(calls[1].url,config.apiBaseUrl+'/rooms');
 await assert.rejects(client.json('/rooms',{name:'AUDIT'}),e=>e.state==='authExpired');assert.equal(calls.length,2);
});
test('Delivered bundle: dirty map draft retains old version; clean draft accepts newer server data',()=>{
 const initial=[{roomId:'A',x:1,y:2}];let state=draft(initial,10);state=edit(state,[{roomId:'A',x:3,y:4}]);let newer=refresh(state,[{roomId:'A',x:8,y:9}],11);
 assert.equal(newer,state);assert.equal(newer.version,10);assert.deepEqual(newer.value,[{roomId:'A',x:3,y:4}]);assert.equal(newer.dirty,true);
 const clean=refresh(draft(initial,10),[{roomId:'B',x:8,y:9}],11);assert.equal(clean.version,11);assert.equal(clean.dirty,false);assert.equal(clean.value[0].roomId,'B');
});
