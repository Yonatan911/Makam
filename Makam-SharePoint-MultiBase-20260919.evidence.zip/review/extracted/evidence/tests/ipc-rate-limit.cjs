'use strict';
// Real Unix-domain socket transport + delivered Express middleware; no Windows/IIS.
const fs=require('fs'),os=require('os'),path=require('path'),http=require('http');
const {createRequire}=require('module');
const root=process.env.MAKAM_AUDIT_SERVER_ROOT||'/mnt/data/makam-verification-20261007/work/package/Makam-SharePoint-MultiBase-20260919/SERVER';
const r=createRequire(root+'/package.json');
const {MemoryDB}=require('./inmemory-db.cjs');
(async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'makam-ipc-'));
 const {loadConfiguration}=r('./src/config.js');
 const db=new MemoryDB();
 const config=loadConfiguration({root:dir,env:{NODE_ENV:'test',AUTH_MODE:'local-test',ENABLE_LOCAL_TEST_LOGIN:'true',AUTO_INITIALIZE_TEST_DB:'true',MONGODB_DATABASE:'readiness_test_ipc_audit',PUBLIC_API_URL:'http://127.0.0.1:4310/api',APP_PUBLIC_URL:'http://127.0.0.1:5173',BOOTSTRAP_OWNER_SAM:'audit.owner'}});
 await r('./src/migrations.js').initializeForTest(db,config);
 const app=await r('./src/app.js').createApp({db,config:{...config,authMode:'iis-session',trustedIdentityVerified:true,listenTarget:'\\\\.\\pipe\\audit-simulated',adDomain:'ARMY'}});
 const socketPath=path.join(dir,'http.sock');
 let firstAddress;
 const server=http.createServer((req,res)=>{if(firstAddress===undefined)firstAddress={remoteAddress:req.socket.remoteAddress??null};app(req,res)});
 await new Promise(resolve=>server.listen(socketPath,resolve));
 const statuses=[];
 try {
  for(let i=0;i<42;i++)statuses.push(await new Promise((resolve,reject)=>{
   const req=http.request({socketPath,path:'/api/auth/session',method:'POST',headers:{Host:'127.0.0.1:4310',Origin:'http://127.0.0.1:5173','Content-Type':'text/plain','X-Forwarded-For':'192.0.2.'+(i+1)}},res=>{res.resume();res.on('end',()=>resolve(res.statusCode))});req.on('error',reject);req.end();
  }));
 } finally {await new Promise(resolve=>server.close(resolve));fs.rmSync(dir,{recursive:true,force:true})}
 const result={environment:{platform:process.platform,node:process.version,transport:'real Unix domain HTTP socket',database:'in-memory double',iis:'NOT RUN'},firstAddress,requests:statuses.length,distinctSyntheticForwardedAddresses:42,statuses,interpretation:'The delivered auth limiter uses req.ip with trust proxy false. An IPC transport supplies no remote IP. Different synthetic forwarded addresses do not separate buckets. First 40 missing-identity requests return 401; requests 41 and 42 hit shared 429. This does not test IIS Windows authentication or real multiple remote client machines.'};
 fs.writeFileSync(path.join(__dirname,'../ipc-rate-limit.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
 if(statuses.length!==42||statuses.slice(0,40).some(s=>s!==401)||statuses.slice(40).some(s=>s!==429))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
