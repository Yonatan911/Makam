# Makam — Delta Remediation Review

:::writing{variant="document" id="makam-delta-remediation-review" title="Makam — Delta Remediation Review"}
Use the three attached review/evidence files as an external review of the **current Makam delivery**, not as a request to restart the audit from zero.

## Scope

Cross-check the findings against:

- the current `Yonatan911/Makam` repository,
- the actual delivered `Makam-SharePoint-MultiBase-20260919.7z`,
- and the documentation/evidence included in the delivery.

Your goal is to determine only the **remaining delta** between the current state and a production-ready, reproducible delivery.

Separate every finding into exactly one of these categories:

1. Already fixed and verified in current code.
2. Still broken or incomplete.
3. Claimed as tested, but the supplied repository/release does not contain enough reproducible evidence to independently verify it.
4. Cannot be closed without the real organizational IIS/SharePoint environment.

Do not reimplement or rewrite areas that are already correctly fixed.

## Execution

Pay special attention to the following:

### 1. Full source must be available and reproducible

The currently supplied Git repository appears to contain mainly the delivery structure:

- `FRONT`
- `SERVER`
- `GUIDE`
- `manifest.json`

while the documentation refers to a fuller development source tree such as:

- `frontend/src`
- `backend/src`
- `shared`
- tests
- build/package scripts

Verify this precisely.

The complete authoritative development source must be present in Git, including the React frontend source, backend source, shared code, tests, lockfiles, build scripts and packaging scripts.

A fresh authorized workstation must be able to:

- clone the repository,
- install dependencies,
- run tests,
- build,
- package,
- and reproduce the release from source.

Do not accept a state where the `.7z` is the real product while Git is only a partial snapshot.

The source commit, release manifest and delivered package must have a clear reproducible relationship.

### 2. Investigate and fix IISNode rate limiting

Review the authentication/session rate limiting under the real IISNode/Named Pipe hosting model.

Do not assume `req.ip` provides a stable per-user/per-client key when the Node process is reached through IISNode IPC.

Verify whether multiple clients can collapse into one shared rate-limit bucket.

If so, implement a safe keying strategy based only on a **trusted IIS/server-derived value** that cannot be spoofed by the browser.

Do not solve this with:

- blind `app.set("trust proxy", true)`,
- arbitrary trust of `X-Forwarded-For`,
- disabling rate limits,
- suppressing express-rate-limit validation warnings.

Add regression tests proving independent clients/users do not unintentionally consume one shared login bucket, while abuse from one trusted identity/source is still limited.

### 3. Do not treat `TRUSTED_IDENTITY_VERIFIED=true` as proof

The supplied documentation explicitly states that real organizational IIS/SharePoint acceptance is still **NOT RUN**.

Treat `TRUSTED_IDENTITY_VERIFIED=true` only as a deployment gate controlled by DevOps, never as evidence that authentication works.

The production gate must still prove on the actual target environment:

- Windows Authentication is active on the intended session endpoint,
- IISNode really promotes `AUTH_USER` and `AUTH_TYPE` as expected,
- client-supplied identity headers are rejected before trusted promotion,
- anonymous access cannot obtain a session,
- OPTIONS/preflight works correctly,
- the React frontend loaded from SharePoint can obtain a session from IIS,
- the resulting session maps to the correct `sAMAccountName`,
- disabled/unassigned users are rejected,
- session revocation works.

If these cannot be tested from the current environment, mark them explicitly as **BLOCKED — TARGET ENVIRONMENT REQUIRED**.

Do not weaken authentication to make local tests pass.

### 4. Git/release parity and manifest reproducibility

Verify byte-level and semantic parity between:

- Git source,
- generated frontend artifact,
- generated server artifact,
- release `.7z`,
- `manifest.json`.

Investigate any line-ending differences or generated-file differences.

The packaging process must generate the manifest **after** final artifact generation and normalization.

A release recreated from the authoritative source must produce a well-defined artifact whose hashes are explainable and reproducible.

Do not silently edit files after manifest generation.

If runtime configuration is intentionally environment-specific, document exactly which file is expected to change after packaging and how its post-deployment hash is recorded.

### 5. Validate previous agent claims from reproducible evidence

The previous agent reported large successful test suites, browser tests, extracted-package tests and Windows checks.

Do not simply repeat those claims.

For each major claim, identify:

- the exact test source,
- the exact command,
- the exact environment,
- the raw/result artifact,
- whether it exists in the repository or delivered package,
- whether you can reproduce it now.

Classify each as:

- REPRODUCED,
- EVIDENCE PRESENT BUT NOT RE-RUN,
- CLAIM ONLY / EVIDENCE MISSING,
- TARGET ENVIRONMENT REQUIRED.

Do not call a claim verified solely because it appears in `TEST-RESULTS.md`.

### 6. Preserve already-fixed work

Do not regress or redesign areas that are already correctly implemented, including where verified:

- direct IISNode backend execution,
- Named Pipe `PORT` preservation,
- deterministic `.env` loading,
- production configuration validation,
- explicit MongoDB service usage,
- runtime frontend API configuration,
- stale map draft/version protection,
- migration preflight-before-write behavior,
- multi-base isolation,
- server-side permission enforcement,
- session revocation,
- offline packaging.

Only change these areas if you reproduce a remaining defect.

## Constraints

- This is **delta remediation**, not a greenfield rewrite.
- Preserve existing business functionality and multibase behavior.
- Do not touch production IIS, SharePoint or production data without explicit authorization.
- Do not weaken authentication, authorization, CORS, TLS or migration protections.
- Do not accept localhost-only success as production proof.
- Do not accept undocumented agent assertions as verification.
- Keep reference repositories read-only.
- Use small reviewable commits.
- Run tests/build/package after changes.
- Keep target-environment-only gates clearly separated from code defects.

## Completion criteria

The task is complete only when:

1. The full authoritative source is present in Git and can reproduce the delivery.
2. All remaining code/package defects found in the three review files are fixed or disproven with evidence.
3. IISNode rate limiting is explicitly validated and corrected if necessary.
4. Git/source/build/release/manifest parity is documented and reproducible.
5. Previous test claims are either reproduced or accurately downgraded to evidence-only/claim-only.
6. All locally verifiable tests, builds and package checks pass.
7. Anything requiring the real IIS/SharePoint environment is isolated into a short, precise target acceptance list.
8. No already-fixed functionality is unnecessarily rewritten.

## Required output

Return:

1. A concise Hebrew summary of what was actually still wrong.
2. A table with every reviewed finding and one status:
   - FIXED,
   - ALREADY FIXED,
   - DISPROVEN,
   - EVIDENCE MISSING,
   - TARGET ENVIRONMENT REQUIRED.
3. Exact changed files and why each changed.
4. Exact commands executed and their real results.
5. Reproducibility evidence from source → build → package → manifest.
6. The final release artifact path and hashes.
7. The exact Git commit SHA containing the complete source.
8. A minimal target-environment checklist containing only the IIS/SharePoint items that genuinely cannot be proven locally.

Do not finish with another broad audit or another theoretical plan.

Implement the remaining fixes, verify them, rebuild/package the release, and provide evidence.
:::
