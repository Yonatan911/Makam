# ראיות הבדיקה העצמאית — מכ״ם 3.1.0

חבילה זו כוללת דוח וקוד בדיקה בלבד. אין בה העתק של ספריות היישום, גופנים או נתוני עבודה.

## תוצאות

- `independent-tests.tap`: שבע קבוצות בדיקות של מודולי השרת שנמסרו, כולן PASS.
- `bundle-tests.tap`: שלוש בדיקות פונקציות מתוך ה־bundle שנמסר, כולן PASS.
- `ipc-rate-limit.log` ו־`ipc-rate-limit.json`: שחזור בעיית המכסה המשותפת מעל IPC. הצלחת סקריפט השחזור פירושה שהבעיה שוחזרה — לא שהמערכת תקינה.
- `vendor-verifier.txt`: פלט אימות החבילה המקורי, 4,905 קבצים.
- `repository-parity.json`: SHA של הארכיון, התאמות קוד הליבה ושני הבדלי CRLF/LF מול GitHub.
- `payload-verification.json`: מניפסט, חסרים/תוספות וחשבון התאמות; יש לקרוא את ההסתייגות לגבי עצי Git ברמת השורש.
- `bundle-extraction.json`: מקור וגיבוב של הצהרות הפונקציות שהועתקו מה־bundle לבדיקה.
- `archive-inventory.json`: תכולת הארכיון שהתקבל.

## הרצה חוזרת בסביבת בדיקה

נדרשים Node מתאים וה־7z המקורי שחולץ. אין להריץ את הבדיקות מול נתוני ארגון. מסד הבדיקות כאן מדומה בזיכרון; אף URI בתסריט אינו משמש לחיבור MongoDB אמיתי.

הגדר `MAKAM_AUDIT_SERVER_ROOT` לנתיב המלא של SERVER בחבילה המחולצת. ההרצה המלאה המתועדת כאן בוצעה על Linux, Node 22.16.0. בדיקות אלו אינן מפעילות IIS או SharePoint.

```bash
export MAKAM_AUDIT_SERVER_ROOT="/absolute/path/to/extracted/SERVER"
node --test evidence/tests/checks.cjs evidence/tests/bundle-checks.cjs
node evidence/tests/ipc-rate-limit.cjs
```

הסקריפט האחרון משתמש ב־Unix domain socket כפי שהורץ בבדיקה זו; הוא אינו תסריט קבלה ל־Windows Named Pipe. על Windows יש לבצע שחזור מותאם דרך IIS עצמו, ולא לסמן אותו PASS אוטומטית.

`inmemory-db.cjs` הוא test double מצומצם. הוא אינו מממש כל תכונה של MongoDB, ובפרט אינו מאמת אינדקסים/טרנזקציות/ביצועים ועמידות מסד אמיתי. בקשות session עם זהות מקודמת הן סימולציית transport בלבד — לא הוכחה לחסימת כותרות מתחזות ב־IIS.

`bundle-functions.cjs` מכיל הצהרות שנשלפו ישירות מן התוצר הקומפילי שבחבילה. הוא אינו שחזור של פרויקט React המקורי, ואינו מבחן DOM או דפדפן.

האימות של Sharp נעשה עם תלויות החבילה על Linux ובחלופת WASM הכלולה בהן; אין בכך אישור לרכיב native של Windows.

הדוחות מתייחסים ל־GitHub commit `f40a1665467c9f162f151113a591dd8c3cef32db`. אין כתיבה למאגר או לסביבת ייצור.
