import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { fileURLToPath } from "node:url";
const here = path.dirname(fileURLToPath(import.meta.url));
export default defineConfig({
  root: here,
  base: "./",
  plugins: [
    react(),
    {
      name: "makam-normalize-html-input",
      // Normalize before Vite removes source script elements. Normalizing only
      // the generated artifact cannot undo CRLF-dependent blank-line removal.
      transformIndexHtml: {
        order: "pre",
        handler: (html) => html.replace(/\r\n?/g, "\n"),
      },
    },
  ],
  build: {
    outDir: path.resolve(here, "../.build/FRONT"),
    emptyOutDir: true,
    sourcemap: false,
  },
  server: { host: "127.0.0.1", port: 5173, strictPort: true },
});
