export function validateRuntime(raw) {
  if (!raw || raw.schemaVersion !== 1)
    throw new Error(
      "חסרה הגדרת מערכת תקינה. יש להגדיר runtime-config.js בספריית SharePoint (schemaVersion: 1).",
    );
  const { apiBaseUrl, environment, releaseVersion, authMode } = raw;
  let url;
  try {
    url = new URL(apiBaseUrl);
  } catch {
    throw new Error(
      "apiBaseUrl חייב להיות כתובת API מלאה, כולל /api וספריית היישום ב־IIS.",
    );
  }
  if (
    !["production", "development", "test"].includes(environment) ||
    !releaseVersion ||
    !["iis-session", "local", "local-test"].includes(authMode) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    /%|\/\//.test(url.pathname)
  )
    throw new Error("הגדרת runtime-config.js אינה תקינה. יש לבדוק את המדריך.");
  url.pathname = url.pathname.replace(/\/+$/, "");
  if (
    !url.pathname.endsWith("/api") ||
    !["https:", "http:"].includes(url.protocol)
  )
    throw new Error("כתובת API חייבת להסתיים ב־/api.");
  if (
    environment === "production" &&
    (url.protocol !== "https:" ||
      authMode !== "iis-session" ||
      ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))
  )
    throw new Error("סביבת ייצור דורשת HTTPS והזדהות IIS מאומתת.");
  return Object.freeze({
    schemaVersion: 1,
    apiBaseUrl: url.href,
    environment,
    releaseVersion,
    authMode,
  });
}
export const getRuntime = () =>
  validateRuntime(globalThis.window?.MAKAM_RUNTIME_CONFIG);
