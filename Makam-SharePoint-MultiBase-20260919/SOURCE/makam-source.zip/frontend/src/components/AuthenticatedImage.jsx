import React, { useState, useEffect } from "react";
import { apiFetch } from "../api.js";
export function AuthenticatedImage({ url, ...props }) {
  const [src, setSrc] = useState(""),
    [error, setError] = useState("");
  useEffect(() => {
    let active = true,
      objectUrl;
    setSrc("");
    setError("");
    apiFetch(url)
      .then(async (response) => {
        if (!response.ok)
          throw new Error(
            "לא ניתן לטעון את תמונת הבסיס. יש לבדוק הרשאות או לרענן את הדף.",
          );
        const blob = await response.blob();
        if (active) {
          objectUrl = URL.createObjectURL(blob);
          setSrc(objectUrl);
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      });
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [url]);
  return error ? (
    <span role="alert">{error}</span>
  ) : src ? (
    <img src={src} {...props} />
  ) : (
    <span role="status">טוען תמונה…</span>
  );
}
