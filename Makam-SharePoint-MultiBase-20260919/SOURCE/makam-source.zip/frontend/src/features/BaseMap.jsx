import React, { useState, useRef, useLayoutEffect } from "react";
import { isManager } from "../../../shared/model.mjs";
import { api, apiFetch } from "../api.js";
import { Field, ErrorMessage, Empty } from "../ui.jsx";
import { AuthenticatedImage } from "../components/AuthenticatedImage.jsx";
import { useVersionedDraft } from "../hooks/useVersionedDraft.js";
export function BaseMap({ data, done, open }) {
  const { baseMap } = data.settings;
  const draft = useVersionedDraft(
    baseMap.markers.map(({ roomId, x, y }) => ({ roomId, x, y })),
    data.settings.version,
  );
  const { value: markers, set: setMarkers, version } = draft;
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [selected, setSelected] = useState(""),
    ref = useRef(),
    viewport = useRef(),
    [viewportSize, setViewportSize] = useState({ width: 800, height: 500 }),
    [imageRatio, setImageRatio] = useState(1),
    drag = useRef(null),
    manager = isManager(data.user);
  useLayoutEffect(() => {
    const element = viewport.current;
    const observer = new ResizeObserver(() =>
      setViewportSize({
        width: element.clientWidth,
        height: element.clientHeight,
      }),
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  const imageWidth = Math.max(
    1,
    Math.min(viewportSize.width, viewportSize.height * imageRatio),
  );
  const point = (e) => {
    const r = ref.current.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100)),
      y: Math.max(0, Math.min(100, ((e.clientY - r.top) / r.height) * 100)),
    };
  };
  const save = async () => {
    setBusy(true);
    try {
      await api("/base-map/markers", { version, markers }, "PUT");
      await done();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div
      className="base-map"
      data-dirty={manager && draft.dirty ? "true" : undefined}
    >
      {manager && (
        <aside className="map-controls">
          {draft.conflict && (
            <div role="alert" className="callout">
              המפה עודכנה בזמן העריכה. השינויים המקומיים נשמרו בטיוטה ולא ניתן
              לדרוס את העדכון.
              <button
                type="button"
                onClick={() => {
                  draft.reload();
                  setError("");
                }}
              >
                טעינת המפה המעודכנת וביטול הטיוטה
              </button>
            </div>
          )}{" "}
          {manager && (
            <>
              <Field label="תמונה אווירית של הבסיס (PNG, JPEG, WebP; עד 10MB)">
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  disabled={busy || draft.dirty}
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (file.size > 10 * 1024 * 1024) {
                      setError("התמונה גדולה מ־10MB");
                      return;
                    }
                    setBusy(true);
                    try {
                      const r = await apiFetch("/base-map/image", {
                        method: "POST",
                        credentials: "same-origin",
                        headers: {
                          "Content-Type": file.type,
                          "X-Readiness-Client": "dashboard",
                        },
                        body: file,
                      });
                      if (!r.ok) throw new Error((await r.json()).error);
                      await done();
                    } catch (e) {
                      setError(e.message);
                    } finally {
                      setBusy(false);
                    }
                  }}
                />
              </Field>
              <div className="form-grid">
                <Field label="הוספת מרחב למפה">
                  <select
                    value=""
                    disabled={!baseMap.imageId}
                    onChange={(e) => {
                      if (!e.target.value) return;
                      setMarkers((ms) => [
                        ...ms,
                        { roomId: e.target.value, x: 50, y: 50 },
                      ]);
                      setSelected(e.target.value);
                    }}
                  >
                    <option value="">בחירת מרחב</option>
                    {data.rooms
                      .filter((r) => !markers.some((m) => m.roomId === r.id))
                      .map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                  </select>
                </Field>
                <button
                  type="button"
                  className="primary"
                  disabled={busy || draft.conflict || !baseMap.imageId}
                  onClick={save}
                >
                  שמירת מיקומי מרחבים
                </button>
              </div>
              <p className="muted">
                גררו את התוויות למיקומן בתמונה או הזינו מיקום מדויק למטה. החלפת
                תמונה שומרת את המיקומים הקיימים.
              </p>
            </>
          )}
          {manager && markers.length > 0 && (
            <div className="form-grid">
              <Field label="מרחב למיקום מדויק">
                <select
                  value={selected}
                  onChange={(e) => setSelected(e.target.value)}
                >
                  <option value="">בחירת מרחב</option>
                  {markers.map((m) => (
                    <option key={m.roomId} value={m.roomId}>
                      {data.rooms.find((r) => r.id === m.roomId)?.name}
                    </option>
                  ))}
                </select>
              </Field>
              {selected &&
                ["x", "y"].map((k, i) => (
                  <Field
                    key={k}
                    label={i ? "מיקום אנכי (%)" : "מיקום אופקי (%)"}
                  >
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step=".1"
                      value={
                        Math.round(
                          (markers.find((m) => m.roomId === selected)?.[k] ||
                            0) * 10,
                        ) / 10
                      }
                      onChange={(e) =>
                        setMarkers((ms) =>
                          ms.map((m) =>
                            m.roomId === selected
                              ? {
                                  ...m,
                                  [k]: Math.max(
                                    0,
                                    Math.min(100, +e.target.value),
                                  ),
                                }
                              : m,
                          ),
                        )
                      }
                    />
                  </Field>
                ))}
              {selected && (
                <button
                  type="button"
                  onClick={() => {
                    setMarkers((ms) => ms.filter((m) => m.roomId !== selected));
                    setSelected("");
                  }}
                >
                  הסרת הסימון מהמפה
                </button>
              )}
            </div>
          )}
        </aside>
      )}
      <div className="map-stage" ref={viewport}>
        {" "}
        {!baseMap.imageId ? (
          <Empty text="טרם הועלתה תמונה אווירית של הבסיס" />
        ) : (
          <div
            className="map-image"
            style={{ width: imageWidth, height: imageWidth / imageRatio }}
            ref={ref}
            onPointerMove={(e) => {
              if (drag.current) {
                const p = point(e);
                setMarkers((ms) =>
                  ms.map((m) =>
                    m.roomId === drag.current ? { ...m, ...p } : m,
                  ),
                );
              }
            }}
            onPointerUp={() => {
              drag.current = null;
            }}
            onPointerCancel={() => {
              drag.current = null;
            }}
          >
            <AuthenticatedImage
              url={"/base-map/image/" + baseMap.imageId}
              alt={`תמונה אווירית של ${data.settings.baseName}`}
              draggable="false"
              onLoad={(e) =>
                setImageRatio(
                  e.currentTarget.naturalWidth / e.currentTarget.naturalHeight,
                )
              }
            />
            {markers.map((m) => {
              const room = data.rooms.find((r) => r.id === m.roomId),
                meta = baseMap.markers.find((r) => r.roomId === m.roomId),
                name = room?.name || meta?.name;
              return (
                <button
                  type="button"
                  key={m.roomId}
                  className={
                    "map-marker " + (selected === m.roomId ? "selected" : "")
                  }
                  style={{ left: m.x + "%", top: m.y + "%" }}
                  onPointerDown={(e) => {
                    if (!manager) return;
                    e.stopPropagation();
                    setSelected(m.roomId);
                    drag.current = m.roomId;
                    ref.current.setPointerCapture(e.pointerId);
                  }}
                  onClick={() => {
                    if (!manager && room) open("details", { room });
                  }}
                >
                  <span>{name}</span>
                  <b>
                    {room?.metrics.overall.score ?? meta?.score ?? "—"}
                    {(room?.metrics.overall.score ?? meta?.score) != null
                      ? "%"
                      : ""}
                  </b>
                </button>
              );
            })}
          </div>
        )}
      </div>
      <ErrorMessage error={error} />
    </div>
  );
}
