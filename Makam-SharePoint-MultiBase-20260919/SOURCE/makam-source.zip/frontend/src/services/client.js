import { getRuntime } from "../config/runtime.js";
export class ApiError extends Error {
  constructor(message, { status = 0, state = "failed", ...detail } = {}) {
    super(message);
    Object.assign(this, { status, state, ...detail });
  }
}
const mutates = (method) => !["GET", "HEAD", "OPTIONS"].includes(method);
export function createApiClient({
  runtime,
  fetchImpl = globalThis.fetch,
  timeoutMs = 30000,
} = {}) {
  let session = null,
    exchange = null;
  const config = () => runtime || getRuntime();
  const endpoint = (path) => {
    const value = String(path);
    const pathname = value.split("?", 1)[0];
    if (
      !value.startsWith("/") ||
      value.startsWith("//") ||
      /[#\\]/.test(value) ||
      [...value].some((character) => character.charCodeAt(0) < 32) ||
      /\.\.|%/.test(pathname)
    )
      throw new ApiError("נתיב API אינו תקין");
    return config().apiBaseUrl + value;
  };
  async function send(url, options, expected) {
    const method = (options.method || "GET").toUpperCase(),
      controller = new AbortController();
    const abort = () => controller.abort();
    options.signal?.addEventListener("abort", abort, { once: true });
    if (options.signal?.aborted) abort();
    const timer = setTimeout(abort, timeoutMs);
    let response;
    try {
      response = await fetchImpl(url, {
        ...options,
        signal: controller.signal,
      });
      const type = response.headers.get("content-type") || "";
      if (type.includes("text/html"))
        throw new ApiError(
          "השרת או SharePoint החזירו דף HTML. יש לבדוק כתובת API, הזדהות והגדרות IIS.",
          {
            status: response.status,
            state: mutates(method) ? "outcomeUnknown" : "failed",
          },
        );
      if (!response.ok) {
        let data = {};
        if (type.includes("json"))
          try {
            data = await response.json();
          } catch {}
        const state =
          response.status === 401
            ? "authExpired"
            : response.status === 409
              ? "conflict"
              : response.status >= 500 && mutates(method)
                ? "outcomeUnknown"
                : "failed";
        if (response.status === 401) session = null;
        throw new ApiError(data.error || "הבקשה נכשלה", {
          status: response.status,
          state,
          detail: data,
        });
      }
      if (expected === "json" && !type.includes("json"))
        throw new ApiError("התקבלה תשובה בפורמט לא צפוי", {
          status: response.status,
          state: mutates(method) ? "outcomeUnknown" : "failed",
        });
      return response;
    } catch (error) {
      if (error instanceof ApiError) throw error;
      throw new ApiError(
        mutates(method)
          ? "תוצאת השמירה אינה ידועה. יש לרענן ולבדוק אם השינוי נשמר לפני ניסיון נוסף."
          : "לא ניתן לקבל נתונים מהשרת. יש לבדוק חיבור והרשאות.",
        { state: mutates(method) ? "outcomeUnknown" : "failed", cause: error },
      );
    } finally {
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", abort);
    }
  }
  async function authenticate() {
    if (config().authMode !== "iis-session") return;
    exchange ||= (async () => {
      const r = await send(
        endpoint("/auth/session"),
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "text/plain" },
          body: "",
        },
        "json",
      );
      const value = await r.json();
      if (
        !/^[a-f0-9]{64}$/.test(value.token) ||
        !Number.isFinite(Date.parse(value.expiresAt))
      )
        throw new ApiError("תשובת הזדהות אינה תקינה");
      session = { token: value.token, expiresAt: Date.parse(value.expiresAt) };
    })().finally(() => (exchange = null));
    return exchange;
  }
  async function request(path, options = {}, expected) {
    const method = (options.method || "GET").toUpperCase(),
      headers = new Headers(options.headers);
    if (config().authMode === "iis-session") {
      if (!session || session.expiresAt <= Date.now()) {
        session = null;
        if (mutates(method))
          throw new ApiError(
            "תוקף ההזדהות פג. יש לבדוק גישה מחדש לפני שמירה.",
            { status: 401, state: "authExpired" },
          );
        await authenticate();
      }
      headers.set("Authorization", "Bearer " + session.token);
    }
    const baseId = globalThis.sessionStorage?.getItem("makam-active-base");
    if (baseId && !path.startsWith("/auth/")) headers.set("X-Base-Id", baseId);
    if (mutates(method)) headers.set("X-Readiness-Client", "dashboard");
    const r = await send(
      endpoint(path),
      {
        ...options,
        method,
        headers,
        credentials: config().authMode === "iis-session" ? "omit" : "include",
      },
      expected,
    );
    if (path === "/auth/logout") session = null;
    return r;
  }
  const json = async (
    path,
    body,
    method = body !== undefined ? "POST" : "GET",
    requestOptions = {},
  ) => {
    const r = await request(
      path,
      {
        ...requestOptions,
        method,
        headers: { "Content-Type": "application/json" },
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      },
      "json",
    );
    try {
      return await r.json();
    } catch (error) {
      throw new ApiError("תשובת JSON פגומה", {
        status: r.status,
        state: mutates(method) ? "outcomeUnknown" : "failed",
        cause: error,
      });
    }
  };
  return {
    request,
    json,
    authenticate,
    clearSession: () => {
      session = null;
    },
  };
}
export const client = createApiClient();
