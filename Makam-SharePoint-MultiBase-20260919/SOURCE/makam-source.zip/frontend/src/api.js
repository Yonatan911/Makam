import { client } from "./services/client.js";
import { localParts, israelTime } from "../../shared/model.mjs";
export const apiFetch = (url, options) => client.request(url, options);
export const api = (url, body, method, options) =>
  client.json(url, body, method, options);
export const date = (value) =>
  value
    ? new Date(value).toLocaleString("he-IL", {
        timeZone: "Asia/Jerusalem",
        hourCycle: "h23",
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "טרם בוצעה בדיקה";
export const fullDate = (value) =>
  value
    ? new Date(value).toLocaleString("he-IL", {
        timeZone: "Asia/Jerusalem",
        hourCycle: "h23",
      })
    : "—";
export const datetimeInput = (value) => {
  const p = localParts(new Date(value || Date.now() + 86400000));
  return (
    p.year +
    "-" +
    String(p.month).padStart(2, "0") +
    "-" +
    String(p.day).padStart(2, "0") +
    "T" +
    String(p.hour).padStart(2, "0") +
    ":" +
    String(p.minute).padStart(2, "0")
  );
};
export function israelInputToIso(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(value);
  if (!m) throw new Error("מועד אינו תקין");
  const values = m.slice(1).map(Number),
    time = israelTime(...values),
    p = localParts(time);
  if (
    [p.year, p.month, p.day, p.hour, p.minute].some((x, i) => x !== values[i])
  )
    throw new Error("השעה אינה קיימת עקב מעבר לשעון קיץ. יש לבחור שעה אחרת.");
  return new Date(time).toISOString();
}
export function download(blob, name) {
  const url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
