import React, { useId } from "react";

const numbers = (count) =>
  Array.from({ length: count }, (_, n) => String(n).padStart(2, "0"));
export function Time24({
  value = "",
  onChange,
  required,
  disabled,
  label = "שעה",
}) {
  const [hour = "", minute = ""] = value.split(":"),
    id = useId();
  return (
    <div
      className="time24"
      dir="ltr"
      role="group"
      aria-label={`${label} — פורמט 24 שעות`}
    >
      <select
        id={`${id}-hour`}
        aria-label={`${label} — שעות (00–23)`}
        required={required}
        disabled={disabled}
        value={hour}
        onChange={(e) =>
          onChange({ target: { value: `${e.target.value}:${minute || "00"}` } })
        }
      >
        <option value="" disabled>
          שעה
        </option>
        {numbers(24).map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </select>
      <span aria-hidden="true">:</span>
      <select
        id={`${id}-minute`}
        aria-label={`${label} — דקות (00–59)`}
        required={required}
        disabled={disabled}
        value={minute}
        onChange={(e) =>
          onChange({ target: { value: `${hour || "00"}:${e.target.value}` } })
        }
      >
        <option value="" disabled>
          דקות
        </option>
        {numbers(60).map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </select>
    </div>
  );
}
export function DateTime24({
  value = "",
  onChange,
  required,
  disabled,
  label = "מועד",
}) {
  const [date = "", time = "00:00"] = value.split("T");
  return (
    <div className="datetime24" role="group" aria-label={label}>
      <input
        type="date"
        aria-label={`${label} — תאריך`}
        value={date}
        required={required}
        disabled={disabled}
        onChange={(e) =>
          onChange({
            target: {
              value: e.target.value ? `${e.target.value}T${time}` : "",
            },
          })
        }
      />
      <Time24
        label={label}
        value={time}
        required={required}
        disabled={disabled || !date}
        onChange={(e) =>
          onChange({ target: { value: `${date}T${e.target.value}` } })
        }
      />
    </div>
  );
}
Time24.isCompoundField = true;
DateTime24.isCompoundField = true;
