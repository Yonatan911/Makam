import React, { useState, useEffect, useCallback } from "react";
import { useDashboardState } from "./hooks/useDashboardState.js";
import {
  ShieldCheck,
  LayoutDashboard,
  Building2,
  ClipboardCheck,
  Package,
  ChartNoAxesCombined,
  Settings,
  Search,
  Plus,
  Moon,
  Sun,
  RefreshCw,
  Users,
  Map,
  Send,
  SlidersHorizontal,
  LogOut,
} from "lucide-react";
import {
  ROLES,
  isManager,
  aggregate,
  readinessBand,
  sortRooms,
  canEditRoom,
} from "../../shared/model.mjs";
import { api, date } from "./api";
import { getRuntime } from "./config/runtime.js";
// main.jsx validates runtime before rendering; module import must remain side-effect free.
const isLibrary = () =>
  typeof window !== "undefined" && getRuntime().environment === "production";
import { Modal, ErrorMessage, Empty, Field } from "./ui";
import {
  RoomForm,
  AssetForm,
  CheckForm,
  FaultForm,
  UserForm,
  RequestForm,
  ActionForm,
  RoundForm,
} from "./FormsV2";
import {
  MetricGrid,
  RoomCard,
  TypeFilter,
  AssetTable,
  AssetDetails,
  FaultTable,
  RoomDetails,
  Reports,
  RequestsPage,
  Snapshot,
  TYPE_NAMES,
} from "./ViewsV2";
import { BaseMap } from "./features/BaseMap.jsx";
import { SettingsPage, OwnerPanel } from "./ManagementV2";
import { FloorPlan } from "./FloorPlanV2";
import { BrandLogo } from "./BrandLogo";
import {
  BasesPage,
  MultiBaseUserForm,
  chooseBase,
  BaseSelector,
} from "./Bases";
import { APP_NAME, APP_DESCRIPTION } from "../../shared/branding.mjs";
import { CommandOverview } from "./CommandOverview";
import "@fontsource/heebo/400.css";
import "@fontsource/heebo/500.css";
import "@fontsource/heebo/600.css";
import "@fontsource/heebo/700.css";
import "./style.css";
import "./v2.css";
const NAV = [
  ["command", ChartNoAxesCombined, "תמונת מצב פיקודית"],
  ["dashboard", LayoutDashboard, "תמונת מצב"],
  ["rooms", Building2, "מרחבים"],
  ["faults", ClipboardCheck, "מעקב פערים"],
  ["inventory", Package, "מלאי אמצעים"],
  ["requests", Send, "בקשות בדיקה"],
  ["reports", ChartNoAxesCombined, "דוחות ותובנות"],
  ["settings", Settings, "ניהול מערכת"],
  ["bases", Building2, "ניהול בסיסים"],
  ["owner", SlidersHorizontal, "סביבת הבעלים"],
];
function LocalAccounts({ onSelect }) {
  const [list, setList] = useState([]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    api("/auth/local-users")
      .then(setList)
      .catch((e) => setError(e.message));
  }, []);
  return (
    <>
      <div className="callout">
        סביבת בדיקה מקומית. אפשר לעבור בין רמות ההרשאה ללא סיסמה. האפשרות כבויה
        בהתקנה הארגונית.
      </div>
      <ErrorMessage error={error} />
      <div className="account-list">
        {list.map((u) => (
          <button
            disabled={busy}
            key={u.id}
            onClick={async () => {
              setBusy(true);
              try {
                await api("/auth/local-login", { userId: u.id });
                await onSelect();
              } catch (e) {
                setError(e.message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <span className="avatar">{u.name[0]}</span>
            <span>
              <b>{u.name}</b>
              <small>
                {ROLES[u.role]} · <bdi>{u.username}</bdi>
              </small>
            </span>
          </button>
        ))}
      </div>
    </>
  );
}
function Login({ auth, onLogin, error }) {
  return (
    <div className="login v2-login">
      <div className="login-brand">
        <BrandLogo className="login-logo" decorative />
        <h1>{APP_NAME}</h1>
        <p>{APP_DESCRIPTION}</p>
      </div>
      <div className="login-card">
        <ErrorMessage error={error} />
        {auth?.testMode ? (
          <LocalAccounts onSelect={onLogin} />
        ) : (
          <>
            <h2>הזדהות ארגונית</h2>
            <p>
              {isLibrary()
                ? "הממשק נטען מ־SharePoint. החשבון הארגוני מאומת ב־IIS, והגישה נקבעת לפי הרשאה שהוקצתה ידנית במכ״ם."
                : "הגישה נקבעת לפי המשתמש המחובר ל־Windows והרשאה שהוקצתה ידנית."}
            </p>
            <p className="muted">
              {isLibrary() || auth?.authMode === "windows-proxy"
                ? "לא זוהה חשבון מורשה. יש לוודא שהוקצתה הרשאה ל־sAMAccountName שלך."
                : "להתקנה המקומית יש להיכנס מקיצור הדרך בשולחן העבודה."}
            </p>
            <button onClick={onLogin}>בדיקת גישה מחדש</button>
          </>
        )}
      </div>
    </div>
  );
}
export default function App() {
  const { data, setData, auth, error, setError, loading, refresh } =
    useDashboardState();
  const [page, setPage] = useState("dashboard"),
    [type, setType] = useState("all"),
    [search, setSearch] = useState(""),
    [status, setStatus] = useState("all"),
    [band, setBand] = useState("all"),
    [sort, setSort] = useState("name"),
    [modal, setModal] = useState(null),
    [toast, setToast] = useState("");
  useEffect(() => {
    if (!data) return;
    document.documentElement.dataset.theme =
      data.user.preferences?.theme || data.settings.defaultTheme || "light";
    document.documentElement.dataset.density = data.settings.density;
    document.documentElement.style.setProperty(
      "--brand-accent",
      data.settings.accentColor,
    );
    document.title = data.settings.appName + " | " + APP_DESCRIPTION;
  }, [data]);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 5000);
    return () => clearTimeout(id);
  }, [toast]);
  const done = async () => {
      await refresh();
      setModal(null);
      setToast("השינויים נשמרו בהצלחה");
    },
    open = (kind, props = {}) => {
      // Inventory filtering changes only the list, never the room used by an editor.
      const completeRoom = data?.rooms.find((r) => r.id === props.room?.id);
      setModal({
        kind,
        ...props,
        ...(completeRoom ? { room: completeRoom } : {}),
      });
    };
  const switchUser = async () => {
    setData(null);
    setModal(null);
    setPage("dashboard");
    setType("all");
    setSearch("");
    setStatus("all");
    setBand("all");
    setSort("name");
    await refresh();
  };
  if (loading)
    return (
      <div className="loading">
        <BrandLogo className="loading-logo" />
        <p>טוען את תמונת המצב…</p>
      </div>
    );
  if (!data) return <Login auth={auth} error={error} onLogin={switchUser} />;
  if (!data.base)
    return (
      <main className="empty-bases">
        {["owner", "command_admin"].includes(data.user.role) && (
          <CommandOverview />
        )}
        <BasesPage data={data} refresh={refresh} />
      </main>
    );
  const { user, settings } = data,
    manager = isManager(user),
    currentTheme = user.preferences?.theme || settings.defaultTheme || "light",
    scopeRooms = data.rooms.filter((r) => type === "all" || r.type === type),
    query = search.toLowerCase(),
    rooms = sortRooms(
      scopeRooms.filter(
        (r) =>
          (band === "all" || readinessBand(r.metrics.overall.score) === band) &&
          (status === "all" ||
            r.freshness === status ||
            (status === "overdue" && r.schedule.overdue)) &&
          (!query ||
            [
              r.name,
              r.type,
              r.note,
              ...r.assets.flatMap((a) => [
                a.name,
                a.ip,
                a.phone,
                a.network,
                a.note,
                KINDS_SAFE(a.kind),
              ]),
            ]
              .join(" ")
              .toLowerCase()
              .includes(query)),
      ),
      sort,
    ),
    metrics = aggregate(scopeRooms, true, settings),
    hour = +new Intl.DateTimeFormat("en", {
      timeZone: "Asia/Jerusalem",
      hour: "numeric",
      hourCycle: "h23",
    }).format(new Date()),
    greeting = hour < 12 ? "בוקר טוב" : hour < 17 ? "צהריים טובים" : "ערב טוב";
  const nav = NAV.filter(([k]) =>
    k === "command"
      ? ["owner", "command_admin"].includes(user.role)
      : k === "owner"
        ? user.role === "owner"
        : ["reports", "settings", "bases"].includes(k)
          ? manager &&
            (k !== "bases" ||
              data.bases.length > 1 ||
              ["owner", "command_admin"].includes(user.role))
          : k === "requests"
            ? user.role !== "viewer"
            : k === "faults"
              ? user.role !== "viewer"
              : true,
  );
  let modalContent = null,
    title = "";
  if (modal) {
    const { room, asset, fault, request, target } = modal;
    const shared = {
      room,
      done:
        ["asset", "room", "plan", "archive", "asset-check", "fault"].includes(
          modal.kind,
        ) && room
          ? async () => {
              const updated = await refresh();
              const current = updated?.rooms.find((r) => r.id === room.id);
              const currentAsset = current?.assets.find(
                (a) => a.id === (asset?.id || fault?.assetId),
              );
              setModal(
                current
                  ? ["asset-check", "fault"].includes(modal.kind) &&
                    currentAsset
                    ? {
                        kind: "asset-details",
                        room: current,
                        asset: currentAsset,
                      }
                    : { kind: "details", room: current }
                  : null,
              );
              setToast("השינויים נשמרו במרחב");
            }
          : done,
    };
    switch (modal.kind) {
      case "asset-details":
        title = "פרטי אמצעי · " + asset.name;
        modalContent = (
          <AssetDetails room={room} asset={asset} user={user} open={open} />
        );
        break;
      case "asset-check":
        title = "בדיקה ודיווח · " + asset.name;
        modalContent = (
          <CheckForm
            {...shared}
            user={user}
            settings={settings}
            technicians={data.technicians}
            initialAsset={asset}
          />
        );
        break;
      case "details":
        title = room.name;
        modalContent = (
          <RoomDetails
            {...shared}
            user={user}
            settings={settings}
            open={open}
          />
        );
        break;
      case "room":
        title = room ? "עריכת מרחב" : "הוספת מרחב";
        modalContent = <RoomForm {...shared} user={user} />;
        break;
      case "asset":
        title = asset ? "עריכת אמצעי" : "הוספת אמצעים · " + room.name;
        modalContent = (
          <AssetForm {...shared} asset={asset} settings={settings} />
        );
        break;
      case "check":
        title = "בדיקת כשירות · " + room.name;
        modalContent = (
          <CheckForm
            {...shared}
            user={user}
            settings={settings}
            technicians={data.technicians}
            request={request}
          />
        );
        break;
      case "fault":
        title = "עדכון פער";
        modalContent = (
          <FaultForm
            {...shared}
            fault={fault}
            user={user}
            technicians={data.technicians}
          />
        );
        break;
      case "user":
        title = target ? "עריכת הרשאה" : "הקצאת הרשאה ידנית";
        modalContent = (
          <MultiBaseUserForm
            baseId={data.base.id}
            user={user}
            target={target}
            rooms={data.rooms}
            done={done}
          />
        );
        break;
      case "request":
        title = "בקשת בדיקה · " + room.name;
        modalContent = <RequestForm {...shared} />;
        break;
      case "decision":
        title = {
          approved: "אישור בקשת בדיקה",
          rejected: "דחיית בקשת בדיקה",
          cancelled: "ביטול בקשת בדיקה",
        }[modal.decision];
        modalContent = (
          <ActionForm
            done={done}
            description={request.reason + " · " + request.details}
            label={title}
            perform={(note) =>
              api(
                `/rooms/${room.id}/requests/${request.id}`,
                { version: room.version, decision: modal.decision, note },
                "PATCH",
              )
            }
          />
        );
        break;
      case "archive":
        title = "הסרת אמצעי מהמלאי";
        modalContent = (
          <ActionForm
            done={done}
            description={`${asset.name} יועבר לארכיון. פער פתוח ייסגר כהסרה מהמלאי, והתיעוד יישמר בדוחות.`}
            label="העברה לארכיון"
            perform={(reason) =>
              api(
                `/rooms/${room.id}/assets/${asset.id}`,
                { version: room.version, reason },
                "DELETE",
              )
            }
          />
        );
        break;
      case "restore":
        title = "שחזור אמצעי";
        modalContent = (
          <ActionForm
            done={done}
            requireText={false}
            description={`${asset.name} יוחזר למלאי ויידרש לבדיקה. תלות וגיבוי יוגדרו מחדש לפי הצורך.`}
            perform={() =>
              api(`/rooms/${room.id}/assets/${asset.id}/restore`, {
                version: room.version,
              })
            }
          />
        );
        break;
      case "maintenance":
        title =
          asset.status === "maintenance"
            ? "החזרת אמצעי לפעילות"
            : "תחזוקה מתוכננת";
        modalContent = (
          <ActionForm
            done={done}
            description={`${asset.name} · תחזוקה מתוכננת מוחרגת מהציון ונפרדת מפער תפעולי.`}
            perform={(note) =>
              api(`/rooms/${room.id}/assets/${asset.id}/maintenance`, {
                version: room.version,
                note,
                enabled: asset.status !== "maintenance",
              })
            }
          />
        );
        break;
      case "remove-user":
        title = "הסרת הרשאה";
        modalContent = (
          <ActionForm
            done={done}
            description={
              target.localOnly
                ? `ההרשאה של ${target.name} בבסיס הנבחר תוסר. התיעוד יישמר.`
                : `החשבון של ${target.name} יושבת בכל המערכת. התיעוד יישמר.`
            }
            requireText={false}
            label="הסרת הרשאה"
            perform={() =>
              api("/users/" + target.id, { version: target.version }, "DELETE")
            }
          />
        );
        break;
      case "round":
        title = "הפעלת סבב בדיקה";
        modalContent = <RoundForm done={done} />;
        break;
      case "plan":
        title = "עורך שרטוט · " + room.name;
        modalContent = <FloorPlan {...shared} editable />;
        break;
      case "map":
        title = "מפת " + settings.baseName;
        modalContent = (
          <BaseMap
            data={data}
            open={open}
            done={async () => {
              await refresh();
              setModal(null);
              setToast("מפת הבסיס עודכנה");
            }}
          />
        );
        break;
      case "snapshot":
        title = "תמונת מצב · " + room.name;
        modalContent = (
          <Snapshot
            rooms={[room]}
            settings={settings}
            title={title}
            showInventory
          />
        );
        break;
      case "switch":
        title = "החלפת משתמש לבדיקה";
        modalContent = <LocalAccounts onSelect={switchUser} />;
        break;
      case "clear-demo":
        title = "הסרת נתוני הדוגמה";
        modalContent = (
          <ActionForm
            done={done}
            label="הסרת נתוני הדוגמה"
            description="פעולה זו מוחקת את מרחבי הדוגמה בלבד, לרבות התיעוד שנצבר בהם. יש להקליד: מחיקת נתוני דוגמה"
            perform={(confirmation) => api("/demo/clear", { confirmation })}
          />
        );
        break;
    }
  }
  return (
    <div className="shell">
      <a className="skip-link" href="#main-content">
        דילוג לתוכן הראשי
      </a>
      <aside className="sidebar">
        <div className="brand">
          <BrandLogo className="sidebar-logo" decorative />
          <div>
            <b>{settings.appName}</b>
            <small>{APP_DESCRIPTION}</small>
          </div>
        </div>
        <button
          type="button"
          className="base base-link"
          onClick={() => open("map")}
        >
          <Map size={19} />
          <span>
            {settings.baseName}
            <small>פתיחת מפת הבסיס</small>
          </span>
        </button>
        <BaseSelector
          bases={data.bases}
          baseId={data.base.id}
          disabled={!!modal}
        />
        <nav aria-label="ניווט ראשי">
          {nav.map(([k, Icon, label]) => (
            <button
              key={k}
              className={page === k ? "selected" : ""}
              aria-current={page === k ? "page" : undefined}
              onClick={() => {
                setPage(k);
                setSearch("");
              }}
            >
              <Icon size={20} />
              {label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="avatar">{user.name[0]}</div>
          <div>
            <b>{user.name}</b>
            <small>{ROLES[user.role]}</small>
          </div>
        </div>
      </aside>
      <main id="main-content">
        <header className="topbar">
          <span>
            <span className="live-dot" />
            עודכן {date(data.serverTime)}
          </span>
          <div className="actions">
            {data.testMode && (
              <button className="test-switch" onClick={() => open("switch")}>
                <Users size={16} />
                החלפת משתמש
              </button>
            )}
            <button
              className="icon-button"
              aria-label={
                currentTheme === "dark" ? "הפעלת מצב בהיר" : "הפעלת מצב כהה"
              }
              onClick={async () => {
                try {
                  await api(
                    "/preferences",
                    {
                      theme: currentTheme === "dark" ? "light" : "dark",
                    },
                    "PATCH",
                  );
                  await refresh();
                } catch (e) {
                  setError(e.message);
                }
              }}
            >
              {currentTheme === "dark" ? <Sun size={19} /> : <Moon size={19} />}
            </button>
            <button
              className="icon-button"
              aria-label="רענון נתונים"
              onClick={() =>
                refresh()
                  .then(() => setError(""))
                  .catch((e) => setError(e.message))
              }
            >
              <RefreshCw size={18} />
            </button>
            {data.testMode && (
              <button
                className="icon-button"
                aria-label="יציאה"
                onClick={async () => {
                  try {
                    await api("/auth/logout", {});
                    await switchUser();
                  } catch (e) {
                    setError(e.message);
                  }
                }}
              >
                <LogOut size={18} />
              </button>
            )}
          </div>
        </header>
        <div className="content">
          <ErrorMessage error={error} />
          {data.testMode && (
            <div className="test-banner">
              סביבת בדיקה מקומית · {settings.demo ? "כוללת נתוני דוגמה · " : ""}
              השינויים נשמרים במחשב זה
            </div>
          )}
          {["dashboard", "rooms", "inventory", "faults"].includes(page) && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">
                    {greeting}, {user.name}
                  </span>
                  <h1>{NAV.find((n) => n[0] === page)?.[2]}</h1>
                  <p>{TYPE_NAMES[type]} · תמונת מצב של המרחבים שבאחריותך</p>
                </div>
                {manager && (
                  <div className="actions">
                    <button onClick={() => open("round")}>
                      הפעלת סבב בדיקה
                    </button>
                    <button className="primary" onClick={() => open("room")}>
                      <Plus size={17} />
                      הוספת מרחב
                    </button>
                  </div>
                )}
              </div>
              {settings.note && (
                <div className="note">
                  <b>הערכת מנהל מערכת</b>
                  <p>{settings.note}</p>
                </div>
              )}
              {settings.round && (
                <div className="round-progress">
                  <span>
                    <b>{settings.round.name}</b> · {settings.round.completed}/
                    {settings.round.total} מרחבים השלימו בדיקה
                  </span>
                  <progress
                    max={settings.round.total || 1}
                    value={settings.round.completed}
                  />
                </div>
              )}
              <TypeFilter value={type} onChange={setType} />
              {page === "dashboard" && <MetricGrid metrics={metrics} />}
              <div className="toolbar">
                <label className="search-box">
                  <Search size={18} />
                  <input
                    aria-label="חיפוש מרחב או אמצעי"
                    placeholder="שם מרחב, שם מחשב, כתובת IP, טלפון, רשת או הערה…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </label>
                <select
                  aria-label="סינון מצב בדיקה"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option value="all">כל מצבי הבדיקה</option>
                  <option value="fresh">בדיקה בתוקף</option>
                  <option value="aging">בדיקה מתיישנת</option>
                  <option value="expired">נדרשת בדיקה</option>
                  <option value="overdue">חריגה ממועד הבדיקה</option>
                  <option value="planned">השבתה מתוכננת</option>
                </select>
                <select
                  aria-label="סינון לפי אחוז כשירות"
                  value={band}
                  onChange={(e) => setBand(e.target.value)}
                >
                  <option value="all">כל ציוני הכשירות</option>
                  <option value="green">ירוק — מעל 90%</option>
                  <option value="orange">כתום — 70% עד 90%</option>
                  <option value="red">אדום — מתחת ל־70%</option>
                  <option value="unknown">ללא ציון כשירות</option>
                </select>
                <select
                  aria-label="מיון מרחבים"
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                >
                  <option value="name">מיון לפי שם מרחב</option>
                  <option value="score-low">כשירות — מהנמוכה לגבוהה</option>
                  <option value="score-high">כשירות — מהגבוהה לנמוכה</option>
                  <option value="check-oldest">בדיקה — מהישנה לחדשה</option>
                  <option value="check-newest">בדיקה — מהחדשה לישנה</option>
                </select>
              </div>
              {["dashboard", "rooms"].includes(page) && (
                <>
                  <div className="section-heading">
                    <h2>{TYPE_NAMES[type]}</h2>
                    <small>{rooms.length} מרחבים</small>
                  </div>
                  <div className="room-grid">
                    {rooms.map((r) => (
                      <RoomCard
                        key={r.id}
                        room={r}
                        user={user}
                        onOpen={() => open("details", { room: r })}
                        onCheck={() => open("check", { room: r })}
                      />
                    ))}
                  </div>
                  {!rooms.length && <Empty text="אין מרחבים התואמים לבחירה" />}
                </>
              )}
              {page === "inventory" && (
                <>
                  <div className="section-heading">
                    <h2>מלאי פעיל</h2>
                    {(manager || user.role === "technician") && (
                      <Field label="הוספת אמצעי במרחב">
                        <select
                          value=""
                          onChange={(e) => {
                            const r = data.rooms.find(
                              (r) => r.id === e.target.value,
                            );
                            if (r) open("asset", { room: r });
                          }}
                        >
                          <option value="">בחירת מרחב</option>
                          {scopeRooms
                            .filter((r) => canEditRoom(user, r.id))
                            .map((r) => (
                              <option key={r.id} value={r.id}>
                                {r.name}
                              </option>
                            ))}
                        </select>
                      </Field>
                    )}
                  </div>
                  <AssetTable
                    rooms={rooms.map((r) => ({
                      ...r,
                      assets: r.assets.filter(
                        (a) =>
                          !query ||
                          [
                            r.name,
                            a.name,
                            a.network,
                            a.ip,
                            a.phone,
                            a.note,
                            KINDS_SAFE(a.kind),
                          ]
                            .join(" ")
                            .toLowerCase()
                            .includes(query),
                      ),
                    }))}
                    user={user}
                    open={open}
                  />
                </>
              )}
              {page === "faults" && (
                <FaultTable rooms={rooms} user={user} open={open} />
              )}
            </>
          )}
          {page === "requests" && user.role !== "viewer" && (
            <RequestsPage data={data} open={open} />
          )}{" "}
          {page === "command" &&
            ["owner", "command_admin"].includes(user.role) && (
              <CommandOverview />
            )}
          {page === "reports" && manager && <Reports data={data} open={open} />}{" "}
          {page === "bases" && manager && (
            <BasesPage data={data} refresh={refresh} />
          )}
          {page === "settings" && manager && (
            <SettingsPage data={data} refresh={refresh} open={open} />
          )}{" "}
          {page === "owner" && user.role === "owner" && (
            <OwnerPanel
              key={settings.version}
              data={data}
              refresh={refresh}
              open={open}
            />
          )}
        </div>
        <footer className="site-credit">
          © יונתן יוסים בשיתוף צוות אלפא | מדור תפעול ומידע רשתי מקשא"פ ז"י
        </footer>
      </main>
      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}
      {modal && (
        <Modal
          key={modal.kind + (modal.room?.id || "") + (modal.asset?.id || "")}
          title={title}
          workspace={["plan", "map"].includes(modal.kind)}
          wide={
            ![
              "user",
              "room",
              "fault",
              "decision",
              "archive",
              "restore",
              "maintenance",
              "remove-user",
              "round",
              "clear-demo",
              "switch",
            ].includes(modal.kind)
          }
          onClose={() => setModal(null)}
        >
          {modalContent}
        </Modal>
      )}
    </div>
  );
}
import { KINDS } from "../../shared/model.mjs";
const KINDS_SAFE = (k) => KINDS[k] || "";
