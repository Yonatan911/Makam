import { download, fullDate } from "./api";

// A local canvas keeps exports independent of external fonts, services or screenshots.
export async function exportCommandImage(data, dark) {
  await document.fonts.ready;
  const count = data.bases.length,
    columns = Math.max(1, Math.ceil(Math.sqrt(Math.max(count, 1) * 1.5))),
    rows = Math.ceil(Math.max(count, 1) / columns);
  const width = Math.max(1920, columns * 500),
    height = Math.round((width * 9) / 16);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d"),
    scale = width / 1920;
  ctx.scale(scale, scale);
  ctx.direction = "rtl";
  ctx.textAlign = "right";
  const colors = dark
    ? {
        bg: "#111820",
        card: "#1a242f",
        text: "#e4ecf4",
        muted: "#a7b8c9",
        green: "#80d5b0",
        orange: "#edca80",
        red: "#f0a4af",
        unknown: "#a7b8c9",
      }
    : {
        bg: "#f1f5f7",
        card: "#ffffff",
        text: "#243b48",
        muted: "#526a78",
        green: "#18704e",
        orange: "#805912",
        red: "#b13645",
        unknown: "#526a78",
      };
  ctx.fillStyle = colors.bg;
  ctx.fillRect(0, 0, 1920, 1080);
  function text(value, x, y, size = 22, color = colors.text, maxWidth) {
    ctx.fillStyle = color;
    ctx.font = `500 ${size}px Heebo, Arial`;
    ctx.fillText(String(value), x, y, maxWidth);
  }
  const pct = (v) => (v == null ? "—" : `${v}%`);
  text("מכ״ם | תמונת מצב פיקודית", 1875, 64, 36);
  text(
    `עודכן: ${fullDate(data.generatedAt)} · ${count} בסיסים`,
    1875,
    105,
    20,
    colors.muted,
  );
  const t = data.totals;
  text(
    `כשירות ${pct(t.score)}  |  ירוקים ${t.green} · כתומים ${t.orange} · אדומים ${t.red} · ללא נתונים ${t.unknown}  |  בסיסים בחריגת בדיקה ${t.basesWithCheckExceptions}`,
    1875,
    155,
    25,
    colors.text,
    1830,
  );
  text(
    `פערים פתוחים ${t.openFaults}  |  חריגות SLA ${t.slaBreached}  |  עמידה ב־SLA ${pct(t.sla.percent)}  |  ללא יעד SLA ${t.sla.withoutTarget}`,
    1875,
    196,
    24,
    colors.muted,
    1830,
  );
  const gap = 18,
    cw = (1830 - gap * (columns - 1)) / columns,
    ch = (780 - gap * (rows - 1)) / rows;
  data.bases.forEach((b, index) => {
    const x = 45 + (columns - 1 - (index % columns)) * (cw + gap),
      y = 228 + Math.floor(index / columns) * (ch + gap);
    ctx.fillStyle = colors.card;
    ctx.beginPath();
    ctx.roundRect(x, y, cw, ch, 12);
    ctx.fill();
    ctx.fillStyle = colors[b.band];
    ctx.fillRect(x + 12, y, cw - 24, 5);
    const lines = [
      `${b.name}  |  כשירות ${pct(b.score)} · ${{ green: "ירוק", orange: "כתום", red: "אדום", unknown: "ללא נתונים" }[b.band]}`,
      `מחשוב ${pct(b.categories.computing)} · טלפוניה ${pct(b.categories.telephony)}`,
      `תצוגה ${pct(b.categories.display)} · יתירות ${pct(b.categories.power)}`,
      `${b.roomCount} מרחבים · ${b.assetCount} אמצעים · ${b.validChecks} בדיקות בתוקף`,
      `חריגות בדיקה ${b.checkExceptions} · מתקרבות לפקיעה ${b.checks.aging}`,
      `פערים פתוחים ${b.openFaults} · קריטיים ${b.criticalFaults}`,
      `חריגות SLA ${b.sla.breached} (${b.sla.openBreached} פתוחות) · עמידה ${pct(b.sla.percent)}`,
      `ללא יעד SLA ${b.sla.withoutTarget} · טרם נבדקו ${b.checks.never} · יזומות ${b.checks.pending}`,
      `בדיקות שפג תוקפן ${b.checks.expired} · מרחבים בהשבתה מתוכננת ${b.checks.planned}`,
      `בדיקה אחרונה: ${fullDate(b.lastCheckAt)}`,
      b.oldestFault
        ? `הפער הוותיק: ${b.oldestFault.ageDays} ימים · ${b.oldestFault.description}`
        : "אין פערים פתוחים",
      b.trend?.delta == null
        ? "מגמה: טרם נצברה מדידה קודמת"
        : `מגמה: ${b.trend.delta > 0 ? "+" : ""}${b.trend.delta} נקודות לעומת ${fullDate(b.trend.previousAt)}`,
    ];
    const step = (ch - 36) / lines.length,
      size = Math.min(32, step * 0.65, cw / 22);
    lines.forEach((line, i) =>
      text(
        line,
        x + cw - 16,
        y + 20 + step * (i + 0.65),
        i === 0 ? size * 1.18 : size,
        i === 0 ? colors.text : colors.muted,
        cw - 32,
      ),
    );
  });
  if (!count) text("אין בסיסים להצגה", 1875, 280, 30);
  text(
    "הכשירות משוקללת לפי אמצעים פעילים · SLA מצטבר, פתוח וסגור · © יונתן יוסים בשיתוף צוות אלפא | מדור תפעול ומידע רשתי מקשא״פ ז״י",
    1875,
    1050,
    17,
    colors.muted,
    1830,
  );
  const blob = await new Promise((resolve) =>
    canvas.toBlob(resolve, "image/png"),
  );
  if (!blob) throw Error("לא ניתן ליצור את תמונת המצב");
  download(blob, "מכם-תמונת-מצב-פיקודית.png");
}
