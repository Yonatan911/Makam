import React, {
  useState,
  useEffect,
  useLayoutEffect,
  useRef,
  createContext,
  useContext,
  useId,
} from "react";
import {
  X,
  Monitor,
  Server,
  Network,
  Phone,
  PanelsTopLeft,
  Projector,
  Unplug,
  Zap,
  Printer,
  Radio,
  Camera,
  Box,
  Router,
  ShieldCheck,
  AlertTriangle,
  UserRound,
  Clock,
} from "lucide-react";
import { STATUSES } from "../../shared/model.mjs";
import { date } from "./api";
export const icons = {
  computer: Monitor,
  server: Server,
  switch: Network,
  router: Router,
  phone: Phone,
  screen: PanelsTopLeft,
  matrix: PanelsTopLeft,
  projector: Projector,
  ups: Unplug,
  power: Zap,
  printer: Printer,
  radio: Radio,
  camera: Camera,
  other: Box,
};
export const freshnessLabels = {
  fresh: "בדיקה בתוקף",
  aging: "בדיקה מתיישנת",
  expired: "נדרשת בדיקה",
  planned: "השבתה מתוכננת",
};
export function Status({ status }) {
  return (
    <span
      className={
        "badge " +
        (["healthy", "closed"].includes(status)
          ? "success"
          : status === "maintenance"
            ? "planned"
            : status === "faulty"
              ? "danger"
              : "warning")
      }
    >
      {STATUSES[status] || status}
    </span>
  );
}
export function Freshness({ value }) {
  return (
    <span
      className={
        "badge " +
        {
          fresh: "success",
          aging: "warning",
          expired: "neutral",
          planned: "planned",
        }[value]
      }
    >
      {freshnessLabels[value]}
    </span>
  );
}
export function AssetIcon({ kind, ...props }) {
  const Icon = icons[kind] || Box;
  return <Icon size={20} {...props} />;
}
const DismissContext = createContext(() => {});
export function Cancel() {
  const dismiss = useContext(DismissContext);
  return (
    <button type="button" onClick={dismiss}>
      ביטול
    </button>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
  workspace = false,
}) {
  const ref = useRef(),
    dirty = useRef(false),
    [confirm, setConfirm] = useState(false),
    titleId = useId();
  const dismiss = () => (dirty.current ? setConfirm(true) : onClose());
  useEffect(() => {
    const d = ref.current;
    d.showModal();
    const leave = (e) => {
      if (dirty.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", leave);
    return () => {
      d.close();
      window.removeEventListener("beforeunload", leave);
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className={
        "modal " + (wide ? "wide " : "") + (workspace ? "workspace-modal" : "")
      }
      aria-labelledby={titleId}
      onCancel={(e) => {
        e.preventDefault();
        dismiss();
      }}
      onPointerDownCapture={(e) => {
        if (e.target.closest("[data-dirty]")) dirty.current = true;
      }}
      onInputCapture={() => {
        dirty.current = true;
      }}
      onChangeCapture={() => {
        dirty.current = true;
      }}
      onKeyDown={(e) => {
        if (
          e.key === "Enter" &&
          e.target.tagName === "INPUT" &&
          e.target.type !== "checkbox"
        )
          e.preventDefault();
      }}
    >
      <div className="modal-head">
        <h2 id={titleId}>{title}</h2>
        <button
          type="button"
          className="icon-button"
          aria-label="סגירת חלונית"
          onClick={dismiss}
        >
          <X size={20} />
        </button>
      </div>
      {confirm && (
        <div className="discard-prompt" role="alert">
          <b>יש שינויים שטרם נשמרו.</b>
          <p>לסגור את החלונית ולוותר על השינויים?</p>
          <div className="actions">
            <button type="button" autoFocus onClick={() => setConfirm(false)}>
              להמשיך בעריכה
            </button>
            <button type="button" className="danger-button" onClick={onClose}>
              סגירה ללא שמירה
            </button>
          </div>
        </div>
      )}
      <div className="modal-body" inert={confirm ? true : undefined}>
        <DismissContext.Provider value={dismiss}>
          {children}
        </DismissContext.Provider>
      </div>
    </dialog>
  );
}
export function Field({ label, children, help }) {
  if (React.isValidElement(children) && children.type?.isCompoundField)
    return (
      <div className="field">
        <span>{label}</span>
        {children}
        {help && <small>{help}</small>}
      </div>
    );
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {help && <small>{help}</small>}
    </label>
  );
}
export function ErrorMessage({ error }) {
  return error ? (
    <div className="error" role="alert">
      <AlertTriangle size={18} />
      {error}
    </div>
  ) : null;
}
export function Empty({ text = "לא נמצאו תוצאות", children }) {
  return (
    <div className="empty">
      <ShieldCheck size={34} />
      <p>{text}</p>
      {children}
    </div>
  );
}
export function Score({ metric, large = false }) {
  const [open, setOpen] = useState(false),
    uid = useId(),
    anchor = useRef(),
    tip = useRef();
  useLayoutEffect(() => {
    if (!open || !tip.current) return;
    const popup = tip.current;
    const place = () => {
      if (popup.showPopover && !popup.matches(":popover-open"))
        popup.showPopover();
      const r = anchor.current.getBoundingClientRect();
      popup.style.position = "fixed";
      popup.style.margin = "0";
      popup.style.right = "auto";
      popup.style.maxHeight = Math.min(560, window.innerHeight - 32) + "px";
      popup.style.overflowY = "auto";
      const w = popup.offsetWidth,
        h = popup.offsetHeight;
      popup.style.left =
        Math.max(16, Math.min(window.innerWidth - w - 16, r.right - w)) + "px";
      popup.style.top =
        Math.max(
          16,
          r.bottom + h + 12 < window.innerHeight ? r.bottom + 8 : r.top - h - 8,
        ) + "px";
    };
    place();
    window.addEventListener("resize", place);
    return () => {
      window.removeEventListener("resize", place);
      if (popup.hidePopover && popup.matches(":popover-open"))
        popup.hidePopover();
    };
  }, [open]);
  return (
    <span
      className={"score-help " + (large ? "large" : "")}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        type="button"
        className="score-trigger"
        ref={anchor}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            e.preventDefault();
            e.stopPropagation();
            setOpen(false);
          }
        }}
        aria-describedby={open ? uid : undefined}
        aria-label={`הסבר חישוב כשירות ${metric?.score ?? "ללא ציון"}`}
      >
        <strong>
          {metric?.score ?? "—"}
          <small>{metric?.score != null ? "%" : ""}</small>
        </strong>
      </button>
      {open && (
        <span
          ref={tip}
          popover="manual"
          className="score-tooltip detailed"
          role="tooltip"
          id={uid}
        >
          <b>כיצד חושב הציון?</b>
          <span>
            {metric?.assetCount || 0} אמצעים · {metric?.excludedCount || 0}{" "}
            בהשבתה מתוכננת
          </span>
          {metric?.deductions?.length ? (
            <>
              <span>השפעת הפערים על הציון:</span>
              <span className="deductions">
                {metric.deductions.map((d) => (
                  <span key={d.id}>
                    <b>{d.name}</b>
                    <em>−{d.points} נק׳</em>
                    <small>
                      משקל {d.weight} × פגיעה {Math.round(d.impact * 100)}%
                      {d.inherited ? " · עקב תלות" : ""}
                      <br />
                      {d.causes.join(" / ")}
                    </small>
                  </span>
                ))}
              </span>
            </>
          ) : (
            <span>{metric?.explanation || "אין אמצעים לחישוב"}</span>
          )}
          <small>
            הציון = 100 × (1 − הפגיעה המשוקללת / סך המשקלים). לכל אמצעי נספרת
            הפגיעה החזקה ביותר, ללא כפל פגיעה. תחום ללא אמצעים מוחרג. אל־פסק
            אינו חובה.
          </small>
        </span>
      )}
    </span>
  );
}
export function LastCheck({ room }) {
  return (
    <div className="last-check">
      <span>
        <Clock size={14} />
        <time dateTime={room.lastCheck?.at}>{date(room.lastCheck?.at)}</time>
      </span>
      {room.lastCheck?.actor && (
        <span className="checker">
          <UserRound size={14} />
          <b>{room.lastCheck.actor}</b>
          <small>ביצע/ה את הבדיקה</small>
        </span>
      )}
    </div>
  );
}
export function useSubmit(done) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const run = async (fn) => {
    setBusy(true);
    setError("");
    let accepted = false;
    try {
      await fn();
      accepted = true;
      await done?.();
    } catch (e) {
      const prefix =
        {
          conflict: "המידע עודכן בינתיים. הטיוטה לא נשמרה. ",
          authExpired: "תוקף ההזדהות פג; יש לבדוק גישה מחדש. ",
          outcomeUnknown:
            "תוצאת השמירה אינה ידועה. יש לבדוק את הנתונים לפני ניסיון נוסף. ",
        }[e.state] || "";
      setError(
        accepted
          ? "השינוי נשמר, אך רענון הנתונים נכשל. יש לרענן את הדף."
          : prefix + e.message,
      );
    } finally {
      setBusy(false);
    }
  };
  return { error, busy, run };
}
export function FormEnd({ error, busy, label = "שמירת שינויים" }) {
  return (
    <>
      <ErrorMessage error={error} />
      <div className="form-actions">
        <button className="primary" type="submit" disabled={busy}>
          {busy ? "שומר…" : label}
        </button>
        <Cancel />
      </div>
    </>
  );
}
export const Toggle = ({ children, ...props }) => (
  <label className="toggle">
    <input type="checkbox" {...props} />
    <span>{children}</span>
  </label>
);
