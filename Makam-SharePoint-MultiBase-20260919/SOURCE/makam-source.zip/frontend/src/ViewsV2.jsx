import { AuthenticatedImage } from "./components/AuthenticatedImage.jsx";
import React, { useState, useRef, useLayoutEffect, useEffect } from "react";
import { toBlob } from "html-to-image";
import {
  Download,
  Plus,
  Pencil,
  Trash2,
  ArchiveRestore,
  Map,
  ClipboardCheck,
  Send,
  AlertTriangle,
} from "lucide-react";
import {
  CATEGORIES,
  KINDS,
  REQUEST_STATUSES,
  STATUSES,
  isManager,
  aggregate,
  canEditRoom,
  readinessBand,
  dependencyIds,
} from "../../shared/model.mjs";
import { api, apiFetch, date, fullDate, download } from "./api";
import {
  Score,
  Freshness,
  Status,
  AssetIcon,
  LastCheck,
  Empty,
  Field,
  ErrorMessage,
} from "./ui";
import { FloorPlan } from "./FloorPlanV2";
import { BrandLogo } from "./BrandLogo";
export const allowedWrite = (user, room) => canEditRoom(user, room.id);
export const TYPE_NAMES = {
  all: "כל המרחבים",
  "חמ״ל": "חמ״לים",
  "חד״ן": "חד״נים",
};
export function TypeFilter({ value, onChange }) {
  return (
    <div className="type-tabs" role="group" aria-label="סוג מרחב">
      {Object.entries(TYPE_NAMES).map(([k, label]) => (
        <button
          key={k}
          type="button"
          className={value === k ? "active" : ""}
          aria-pressed={value === k}
          onClick={() => onChange(k)}
        >
          {label}
        </button>
      ))}
    </div>
  );
}
export function MetricGrid({ metrics }) {
  return (
    <div className="metrics">
      <section className="metric-card featured">
        <span>כשירות כללית</span>
        <Score metric={metrics.overallMetric} large />
        <small>ציון משוקלל של האמצעים</small>
      </section>
      {Object.entries(CATEGORIES).map(([k, label]) => (
        <section key={k} className="metric-card">
          <span>{label}</span>
          <Score metric={metrics.categoryMetrics[k]} />
          <small>{metrics.categoryMetrics[k].assetCount} אמצעים</small>
        </section>
      ))}
    </div>
  );
}
export function RoomCard({ room, onOpen, onCheck, user }) {
  return (
    <article
      className={"room-card v2-room " + room.freshness}
      data-readiness={readinessBand(room.metrics.overall.score)}
    >
      <div className="room-card-head">
        <span className="eyebrow">{room.type}</span>
        <Freshness value={room.freshness} />
      </div>
      <div className="room-title-row">
        <button
          type="button"
          className="text-button room-title"
          onClick={onOpen}
        >
          {room.name}
        </button>
        <Score metric={room.metrics.overall} />
      </div>
      <div className="mini-domains">
        {Object.entries(CATEGORIES).map(([k, label]) => (
          <span key={k}>
            {label}
            <b>
              {room.metrics.categories[k].score ?? "—"}
              {room.metrics.categories[k].score != null ? "%" : ""}
            </b>
          </span>
        ))}
      </div>
      <LastCheck room={room} />
      {room.schedule.overdue && (
        <p className="overdue">
          <AlertTriangle size={14} />
          חריגה ממועד הבדיקה · {date(room.schedule.dueAt)}
        </p>
      )}
      {room.metrics.warning && (
        <p className="overdue">פגיעה בגיבוי החשמל — סכנה לרציפות בחירום</p>
      )}
      {room.note && <p className="card-assessment">{room.note}</p>}
      <div className="room-card-bottom">
        <small>
          {room.assets.length} אמצעים ·{" "}
          {room.faults.filter((f) => f.status !== "closed").length} פערים פתוחים
        </small>
        {allowedWrite(user, room) && (
          <button
            type="button"
            className="small-button"
            disabled={
              room.maintenance ||
              !room.assets.some((a) => a.status !== "maintenance")
            }
            onClick={onCheck}
          >
            <ClipboardCheck size={15} />
            בדיקת כשירות
          </button>
        )}
      </div>
    </article>
  );
}
export function AssetDetails({ room, asset, user, open }) {
  const metric = room.metrics.assets.find((a) => a.id === asset.id);
  const fault = room.faults.find(
    (f) => f.assetId === asset.id && f.status !== "closed",
  );
  const dependents = room.assets.filter((a) =>
    dependencyIds(a).includes(asset.id),
  );
  return (
    <div className="asset-details">
      <div className="asset-name">
        <AssetIcon kind={asset.kind} />
        <h2>{asset.name}</h2>
        <Status status={asset.status} />
      </div>
      <p>
        {room.name} · {KINDS[asset.kind]} · {CATEGORIES[asset.category]}
      </p>
      <dl className="asset-facts">
        {[
          ["רשת", asset.network],
          ["כתובת IP", asset.ip],
          ["מספר טלפון", asset.phone],
          ["מספר סידורי", asset.serial],
        ]
          .filter(([, v]) => v)
          .map(([label, value]) => (
            <div key={label}>
              <dt>{label}</dt>
              <dd>
                <bdi>{value}</bdi>
              </dd>
            </div>
          ))}
      </dl>
      {metric?.loss > 0 && (
        <p className="callout">הכשירות מושפעת מ־{metric.causes.join(", ")}</p>
      )}
      {fault && <p className="callout">פער פתוח: {fault.description}</p>}
      {dependents.length > 0 && (
        <p>
          אמצעים התלויים באמצעי זה: {dependents.map((a) => a.name).join(", ")}
        </p>
      )}
      {allowedWrite(user, room) && (
        <div className="actions">
          <button
            type="button"
            className="primary"
            disabled={room.maintenance || asset.status === "maintenance"}
            onClick={() => open("asset-check", { room, asset })}
          >
            {fault ? "בדיקה וסגירת פער" : "דיווח פער"}
          </button>
          {fault && (
            <button
              type="button"
              onClick={() => open("fault", { room, fault })}
            >
              עדכון מצב הטיפול
            </button>
          )}
          <button type="button" onClick={() => open("asset", { room, asset })}>
            עריכת פרטי האמצעי
          </button>
        </div>
      )}
    </div>
  );
}
export function AssetTable({ rooms, user, open, archived = false }) {
  const rows = rooms.flatMap((room) =>
    (archived ? room.archivedAssets || [] : room.assets).map((asset) => ({
      room,
      asset,
    })),
  );
  return rows.length ? (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>האמצעי</th>
            <th>מרחב</th>
            <th>תחום / רשת</th>
            <th>פרטים</th>
            <th>{archived ? "תיעוד הסרה" : "מצב"}</th>
            {rooms.some((r) => allowedWrite(user, r)) && <th>פעולות</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map(({ room: r, asset: a }) => {
            const effect = r.metrics.assets.find((x) => x.id === a.id);
            return (
              <tr key={a.id}>
                <td>
                  <span className="asset-name">
                    <AssetIcon kind={a.kind} />
                    {archived ? (
                      <b>{a.name}</b>
                    ) : (
                      <button
                        type="button"
                        className="text-button"
                        onClick={() =>
                          open("asset-details", { room: r, asset: a })
                        }
                      >
                        {a.name}
                      </button>
                    )}
                  </span>
                  <small>
                    {KINDS[a.kind]}
                    {a.critical ? " · קריטי" : ""}
                  </small>
                </td>
                <td>
                  {r.name}
                  <small>{r.type}</small>
                </td>
                <td>
                  {CATEGORIES[a.category]}
                  <small>{a.network || "ללא שיוך לרשת"}</small>
                </td>
                <td>
                  {a.ip && (
                    <div>
                      כתובת IP: <bdi>{a.ip}</bdi>
                    </div>
                  )}
                  {a.phone && (
                    <div>
                      טלפון: <bdi>{a.phone}</bdi>
                    </div>
                  )}
                  {a.serial && <small>מס׳ סידורי: {a.serial}</small>}
                  {a.backupIds?.length > 0 && (
                    <small>
                      מגובה באמצעות:{" "}
                      {a.backupIds
                        .map(
                          (id) =>
                            r.assets.find((x) => x.id === id)?.name ||
                            "אמצעי שהוסר",
                        )
                        .join(", ")}
                    </small>
                  )}
                </td>
                <td>
                  {archived ? (
                    <>
                      <span>{fullDate(a.archivedAt)}</span>
                      <small>
                        {a.archivedBy} · {a.archiveReason}
                      </small>
                    </>
                  ) : (
                    <>
                      <Status status={a.status} />
                      {effect?.inherited ||
                      (effect?.loss > 0 &&
                        ![
                          "faulty",
                          "in_progress",
                          "waiting",
                          "repaired",
                        ].includes(a.status)) ? (
                        <small className="overdue">
                          מושבת עקב {effect.causes.join(", ")}
                        </small>
                      ) : null}
                      {a.note && <small>{a.note}</small>}
                    </>
                  )}
                </td>
                {allowedWrite(user, r) && (
                  <td>
                    <div className="actions">
                      {archived ? (
                        <button
                          type="button"
                          title="שחזור אמצעי למלאי"
                          aria-label={`שחזור ${a.name}`}
                          onClick={() => open("restore", { room: r, asset: a })}
                        >
                          <ArchiveRestore size={16} />
                        </button>
                      ) : (
                        <>
                          <button
                            type="button"
                            className="small-button"
                            disabled={
                              r.maintenance || a.status === "maintenance"
                            }
                            onClick={() =>
                              open("asset-check", { room: r, asset: a })
                            }
                          >
                            {r.faults.some(
                              (f) =>
                                f.assetId === a.id && f.status !== "closed",
                            )
                              ? "בדיקה וסגירת פער"
                              : "דיווח פער"}
                          </button>
                          {r.faults.find(
                            (f) => f.assetId === a.id && f.status !== "closed",
                          ) && (
                            <button
                              type="button"
                              onClick={() =>
                                open("fault", {
                                  room: r,
                                  fault: r.faults.find(
                                    (f) =>
                                      f.assetId === a.id &&
                                      f.status !== "closed",
                                  ),
                                })
                              }
                            >
                              עדכון טיפול
                            </button>
                          )}
                          <button
                            type="button"
                            aria-label={`עריכת ${a.name}`}
                            onClick={() => open("asset", { room: r, asset: a })}
                          >
                            <Pencil size={16} />
                          </button>
                          <button
                            type="button"
                            aria-label={`הסרת ${a.name}`}
                            onClick={() =>
                              open("archive", { room: r, asset: a })
                            }
                          >
                            <Trash2 size={16} />
                          </button>
                          {isManager(user) && (
                            <button
                              type="button"
                              className="small-button"
                              onClick={() =>
                                open("maintenance", { room: r, asset: a })
                              }
                            >
                              {a.status === "maintenance"
                                ? "החזרה לפעילות"
                                : "תחזוקה"}
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  ) : (
    <Empty text={archived ? "אין אמצעים בארכיון" : "טרם נוספו אמצעים"} />
  );
}
export function RoomDetails({ room, user, settings, open }) {
  const [tab, setTab] = useState("assets");
  return (
    <div className="room-detail">
      <div className="detail-summary">
        <Score metric={room.metrics.overall} large />
        <div>
          <Freshness value={room.freshness} />
          <LastCheck room={room} />
          {room.schedule.enabled && (
            <small>
              מועד הבדיקה הנדרש: {date(room.schedule.nextDueAt)}
              {room.schedule.overdue ? " · בחריגה" : ""}
            </small>
          )}
          {room.lastPartialCheck && (
            <small>בדיקה ממוקדת אחרונה: {date(room.lastPartialCheck.at)}</small>
          )}
        </div>
      </div>
      <div className="actions">
        {allowedWrite(user, room) && (
          <button
            type="button"
            className="primary"
            disabled={
              room.maintenance ||
              !room.assets.some((a) => a.status !== "maintenance")
            }
            onClick={() => open("check", { room })}
          >
            ביצוע בדיקת כשירות
          </button>
        )}
        {(isManager(user) || user.role === "commander") && (
          <button type="button" onClick={() => open("request", { room })}>
            בקשת בדיקה
          </button>
        )}
        <button type="button" onClick={() => open("snapshot", { room })}>
          <Download size={16} />
          תמונת מצב המרחב
        </button>
        {allowedWrite(user, room) && (
          <>
            <button type="button" onClick={() => open("room", { room })}>
              עריכת המרחב
            </button>
            <button type="button" onClick={() => open("asset", { room })}>
              <Plus size={16} />
              הוספת אמצעים
            </button>
            <button type="button" onClick={() => open("plan", { room })}>
              עריכת שרטוט
            </button>
          </>
        )}
      </div>
      {room.note && (
        <div className="note">
          <b>הערכת מנהל מערכת</b>
          <p>{room.note}</p>
        </div>
      )}
      <div className="type-tabs" role="group" aria-label="תוכן המרחב">
        {[
          ["assets", "מלאי אמצעים"],
          ["plan", "שרטוט מרחב"],
          ["faults", "פערים פעילים"],
          ...(["commander", "admin", "command_admin", "owner"].includes(
            user.role,
          )
            ? [["checks", "תיעוד בדיקות"]]
            : []),
        ].map(([k, l]) => (
          <button
            key={k}
            type="button"
            aria-pressed={tab === k}
            className={tab === k ? "active" : ""}
            onClick={() => setTab(k)}
          >
            {l}
          </button>
        ))}
      </div>
      {tab === "assets" && (
        <AssetTable rooms={[room]} user={user} open={open} />
      )}{" "}
      {tab === "plan" && (
        <FloorPlan
          room={room}
          onAssetSelect={(asset) => open("asset-details", { room, asset })}
        />
      )}{" "}
      {tab === "faults" && (
        <FaultTable rooms={[room]} user={user} open={open} />
      )}{" "}
      {tab === "checks" && (
        <AuditTable
          logs={
            room.checks ||
            room.audit?.filter((a) =>
              ["בדיקת כשירות", "בדיקה ממוקדת"].includes(a.action),
            ) ||
            []
          }
        />
      )}
    </div>
  );
}
export function FaultTable({ rooms, user, open, history = false }) {
  const rows = rooms
    .flatMap((room) =>
      room.faults
        .filter((f) => history || f.status !== "closed")
        .map((f) => ({ room, f })),
    )
    .sort((a, b) => (a.f.status === "closed") - (b.f.status === "closed"));
  return rows.length ? (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>אמצעי / מרחב</th>
            <th>תיאור הפער</th>
            <th>מצב</th>
            <th>יעד לטיפול</th>
            {isManager(user) && <th>תיעוד</th>}
            <th>פעולה</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(({ room, f }) => (
            <tr key={f.id}>
              <td>
                <b>
                  {[...room.assets, ...(room.archivedAssets || [])].find(
                    (a) => a.id === f.assetId,
                  )?.name ||
                    f.assetName ||
                    "אמצעי שהוסר"}
                </b>
                <small>{room.name}</small>
              </td>
              <td>
                {f.description}
                {f.assigneeText && <small>פרטי המטפל: {f.assigneeText}</small>}
                {f.closureNote && <small>הערת סגירה: {f.closureNote}</small>}
              </td>
              <td>
                <Status status={f.status} />
              </td>
              <td>
                {f.slaAt ? date(f.slaAt) : "—"}
                {f.slaAt &&
                  new Date(f.slaAt) < new Date() &&
                  f.status !== "closed" && (
                    <small className="overdue">חריגה מיעד הטיפול</small>
                  )}
              </td>
              {isManager(user) && (
                <td>
                  <small>נפתח: {date(f.openedAt)}</small>
                  <small>{f.openedBy}</small>
                  {f.closedAt && (
                    <small>
                      נסגר: {date(f.closedAt)} · {f.closedBy}
                    </small>
                  )}
                  {f.closureMode === "direct_admin" && (
                    <span className="badge planned">
                      סגירה ישירה של מנהל מערכת
                    </span>
                  )}
                </td>
              )}
              <td>
                {f.status !== "closed" && allowedWrite(user, room) && (
                  <button
                    type="button"
                    onClick={() => open("fault", { room, fault: f })}
                  >
                    עדכון / סגירה
                  </button>
                )}
                {isManager(user) && (
                  <details>
                    <summary>מעברי סטטוס</summary>
                    {f.history?.map((h, i) => (
                      <p key={i}>
                        {date(h.at)} · {h.actor} · {STATUSES[h.status]}
                        <small>{h.note}</small>
                      </p>
                    ))}
                  </details>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ) : (
    <Empty text="אין פערים להצגה" />
  );
}
export function AuditTable({ logs }) {
  return logs.length ? (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>מועד</th>
            <th>מבצע/ת</th>
            <th>פעולה</th>
            <th>פירוט</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((a, i) => (
            <tr key={a.id || i}>
              <td>{fullDate(a.at)}</td>
              <td>{a.actor}</td>
              <td>{a.action}</td>
              <td>{a.detail}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ) : (
    <Empty text="אין תיעוד להצגה" />
  );
}
export function RequestsPage({ data, open }) {
  const entries = data.rooms
      .flatMap((room) => room.requests.map((r) => ({ room, r })))
      .sort((a, b) => b.r.createdAt.localeCompare(a.r.createdAt)),
    [filter, setFilter] = useState("active"),
    visible = entries.filter(
      ({ r }) => filter === "all" || ["pending", "approved"].includes(r.status),
    );
  return (
    <>
      <div className="page-heading">
        <div>
          <h1>בקשות בדיקה</h1>
          <p>בקשה ממוקדת, אישור ותיעוד הביצוע</p>
        </div>
        {(isManager(data.user) || data.user.role === "commander") && (
          <Field label="בקשה חדשה עבור">
            <select
              value=""
              onChange={(e) => {
                const room = data.rooms.find((r) => r.id === e.target.value);
                if (room) open("request", { room });
              }}
            >
              <option value="">בחירת מרחב</option>
              {data.rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
          </Field>
        )}
      </div>
      <div className="type-tabs">
        <button
          onClick={() => setFilter("active")}
          className={filter === "active" ? "active" : ""}
        >
          בקשות פעילות
        </button>
        <button
          onClick={() => setFilter("all")}
          className={filter === "all" ? "active" : ""}
        >
          כל הבקשות
        </button>
      </div>
      {!visible.length && <Empty text="אין בקשות להצגה" />}
      <div className="request-grid">
        {visible.map(({ room, r }) => (
          <article className="panel request-card" key={r.id}>
            <div className="section-heading">
              <b>{room.name}</b>
              <span
                className={
                  "badge " +
                  (r.status === "approved"
                    ? "warning"
                    : r.status === "completed"
                      ? "success"
                      : "neutral")
                }
              >
                {REQUEST_STATUSES[r.status]}
              </span>
            </div>
            <h3>{r.reason}</h3>
            <p>{r.details}</p>
            <div className="request-meta">
              <span>
                מועד מבוקש: <b>{fullDate(r.requestedFor)}</b>
              </span>
              <span>מבקש/ת: {r.requestedBy}</span>
              <span>
                היקף:{" "}
                {r.scope === "full"
                  ? "בדיקה מלאה"
                  : r.assetIds
                      .map(
                        (id) =>
                          room.assets.find((a) => a.id === id)?.name ||
                          "אמצעי שהוסר",
                      )
                      .join(", ")}
              </span>
            </div>
            {r.reviewNote && (
              <p className="note">
                {r.reviewedBy}: {r.reviewNote}
              </p>
            )}
            <div className="actions">
              {r.status === "pending" && isManager(data.user) && (
                <>
                  <button
                    className="primary"
                    onClick={() =>
                      open("decision", {
                        room,
                        request: r,
                        decision: "approved",
                      })
                    }
                  >
                    אישור הבקשה
                  </button>
                  <button
                    onClick={() =>
                      open("decision", {
                        room,
                        request: r,
                        decision: "rejected",
                      })
                    }
                  >
                    דחיית הבקשה
                  </button>
                </>
              )}
              {r.status === "approved" && allowedWrite(data.user, room) && (
                <button
                  className="primary"
                  disabled={room.maintenance}
                  onClick={() => open("check", { room, request: r })}
                >
                  ביצוע הבדיקה
                </button>
              )}
              {["pending", "approved"].includes(r.status) &&
                (isManager(data.user) ||
                  (r.status === "pending" &&
                    r.requestedById === data.user.id)) && (
                  <button
                    onClick={() =>
                      open("decision", {
                        room,
                        request: r,
                        decision: "cancelled",
                      })
                    }
                  >
                    ביטול בקשה
                  </button>
                )}
            </div>
            {r.history && (
              <details>
                <summary>תיעוד הבקשה</summary>
                {r.history.map((h, i) => (
                  <p key={i}>
                    <span>
                      {fullDate(h.at)} · {h.actor} ·{" "}
                      {REQUEST_STATUSES[h.status]}
                    </span>{" "}
                    <small className="request-history-note">{h.note}</small>
                  </p>
                ))}
              </details>
            )}
          </article>
        ))}
      </div>
    </>
  );
}
export async function saveSnapshot(node, name) {
  await document.fonts.ready;
  const blob = await toBlob(node, {
    pixelRatio: 2,
    cacheBust: false,
    backgroundColor: getComputedStyle(document.documentElement)
      .getPropertyValue("--surface")
      .trim(),
    filter: (el) => !el.classList?.contains("no-capture"),
  });
  if (!blob) throw new Error("לא ניתן היה ליצור תמונת מצב");
  download(blob, name + ".png");
}
function SnapshotFrame({ presentation, captureRef, children, count }) {
  const preview = useRef(),
    sheet = useRef(),
    stage = useRef();
  useLayoutEffect(() => {
    if (!presentation) return;
    let disposed = false;
    const fit = () => {
      if (disposed) return;
      const content = sheet.current;
      // Measure all text at its actual wrapped width; never truncate report data.
      content.style.minHeight = "0";
      const fits = (scale) => {
        content.style.width = `${1600 / scale}px`;
        return content.scrollHeight * scale <= 900;
      };
      let scale = 1;
      if (!fits(scale)) {
        let low = 0.01,
          high = 1;
        for (let i = 0; i < 16; i++) {
          const mid = (low + high) / 2;
          if (fits(mid)) low = mid;
          else high = mid;
        }
        scale = low;
      }
      content.style.width = `${1600 / scale}px`;
      content.style.minHeight = `${900 / scale}px`;
      content.style.transform = `scale(${scale})`;
    };
    const fitPreview = () => {
      const scale = Math.min(
        1,
        preview.current.clientWidth / 1600,
        Math.max(220, window.innerHeight - 260) / 900,
      );
      stage.current.style.transform = `scale(${scale})`;
      preview.current.style.height = `${900 * scale}px`;
      preview.current.style.setProperty("--preview-width", `${1600 * scale}px`);
    };
    fit();
    fitPreview();
    const observer = new ResizeObserver(fitPreview);
    observer.observe(preview.current);
    window.addEventListener("resize", fitPreview);
    document.fonts.ready.then(() => {
      if (!disposed) fit();
    });
    return () => {
      disposed = true;
      observer.disconnect();
      window.removeEventListener("resize", fitPreview);
    };
  }, [presentation, children]);
  if (!presentation)
    return (
      <div className="snapshot-preview">
        <div ref={captureRef} className="snapshot">
          {children}
        </div>
      </div>
    );
  const columns = Math.min(6, Math.max(1, Math.ceil(Math.sqrt(count * 1.6))));
  return (
    <div ref={preview} className="snapshot-preview-fit">
      <div ref={stage} className="snapshot-stage">
        <div ref={captureRef} className="snapshot presentation-snapshot">
          <div
            ref={sheet}
            className="snapshot-sheet"
            style={{ "--snapshot-columns": Math.min(count || 1, columns) }}
          >
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
export function Snapshot({
  rooms,
  settings,
  title,
  summaryOnly = false,
  showInventory = false,
  presentation = false,
}) {
  const metrics = aggregate(rooms, true, settings),
    active = rooms.flatMap((r) => r.assets),
    faults = rooms.flatMap((r) =>
      r.faults.filter((f) => f.status !== "closed"),
    ),
    ref = useRef(),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <>
      <div className="actions no-capture">
        <button
          disabled={busy}
          type="button"
          onClick={async () => {
            setError("");
            setBusy(true);
            try {
              await saveSnapshot(ref.current, title);
            } catch (e) {
              setError(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <Download size={16} />
          {busy
            ? "מכין תמונה…"
            : presentation
              ? "שמירת תמונת מצב למצגת"
              : "שמירת תמונת מצב"}
        </button>
        {presentation && (
          <span role="status">{rooms.length} מרחבים · תמונה אחת מלאה</span>
        )}
      </div>
      <ErrorMessage error={error} />
      <SnapshotFrame
        presentation={presentation}
        captureRef={ref}
        count={rooms.length}
      >
        <div className="snapshot-head">
          <BrandLogo className="snapshot-logo" />
          <div>
            <span className="eyebrow">
              {settings.appName} · {settings.baseName}
            </span>
            <h2>{title}</h2>
          </div>
          <time>{fullDate(new Date().toISOString())}</time>
        </div>
        {settings.note && (
          <div className="note">
            <b>הערכת מנהל מערכת</b>
            <p>{settings.note}</p>
          </div>
        )}
        <div className="snapshot-metrics">
          <div>
            <strong>
              {metrics.overall ?? "—"}
              {metrics.overall != null ? "%" : ""}
            </strong>
            <span>כשירות כללית</span>
          </div>
          {Object.entries(CATEGORIES).map(([k, t]) => (
            <div key={k}>
              <b>
                {metrics.categories[k] ?? "—"}
                {metrics.categories[k] != null ? "%" : ""}
              </b>
              <span>{t}</span>
            </div>
          ))}
        </div>
        <div className="snapshot-counts">
          <span>
            <b>{rooms.length}</b> מרחבים
          </span>
          <span>
            <b>{active.length}</b> אמצעים פעילים
          </span>
          <span>
            <b>{faults.length}</b> פערים פתוחים
          </span>
          <span>
            <b>{rooms.filter((r) => r.freshness === "fresh").length}</b> בדיקות
            בתוקף
          </span>
          <span>
            <b>{rooms.filter((r) => r.freshness === "aging").length}</b> בדיקות
            מתיישנות
          </span>
          <span>
            <b>{rooms.filter((r) => r.freshness === "expired").length}</b>{" "}
            דורשים בדיקה
          </span>
          <span>
            <b>{rooms.filter((r) => r.schedule.overdue).length}</b> בחריגה
            מהמועד
          </span>
          <span>
            <b>{rooms.filter((r) => r.maintenance).length}</b> בהשבתה מתוכננת
          </span>
          <span>
            <b>
              {
                faults.filter((f) => f.slaAt && new Date(f.slaAt) < new Date())
                  .length
              }
            </b>{" "}
            פערים בחריגת טיפול
          </span>
        </div>
        {summaryOnly ? (
          <>
            <div className="snapshot-breakdown">
              {Object.entries(STATUSES)
                .filter(
                  ([k]) => !["healthy", "closed", "maintenance"].includes(k),
                )
                .map(([k, t]) => (
                  <span key={k}>
                    {t}
                    <b>{faults.filter((f) => f.status === k).length}</b>
                  </span>
                ))}
            </div>
            <p className="muted">
              הציון מחושב לפי משקל האמצעי, חומרת הפגיעה ותלות משביתה. אמצעים
              בתחזוקה מוחרגים. תוקף הבדיקה מוצג בנפרד מהציון. אל־פסק אינו חובה.
            </p>
          </>
        ) : (
          <div className={presentation ? "snapshot-cards" : "snapshot-rooms"}>
            {rooms.map((r) => (
              <section
                className="snapshot-room"
                key={r.id}
                data-readiness={readinessBand(r.metrics.overall.score)}
              >
                <div className="section-heading">
                  <h3>{r.name}</h3>
                  <b className="snapshot-room-score">
                    {r.metrics.overall.score ?? "—"}
                    {r.metrics.overall.score != null ? "%" : ""}
                  </b>
                  <Freshness value={r.freshness} />
                </div>
                <LastCheck room={r} />
                <div className="mini-domains">
                  {Object.entries(CATEGORIES).map(([k, t]) => (
                    <span key={k}>
                      {t}
                      <b>
                        {r.metrics.categories[k].score ?? "—"}
                        {r.metrics.categories[k].score != null ? "%" : ""}
                      </b>
                    </span>
                  ))}
                </div>
                <p>
                  {r.assets.length} אמצעים · {r.metrics.impacted} אמצעים מושפעים
                  · {r.metrics.planned} בהשבתה מתוכננת
                </p>
                {r.schedule.enabled && (
                  <p>
                    בדיקה נדרשת עד {date(r.schedule.nextDueAt)}
                    {r.schedule.overdue ? " · חריגה ממועד הבדיקה" : ""}
                  </p>
                )}
                {r.note && <p>הערכת מנהל מערכת: {r.note}</p>}
                {r.metrics.warning && (
                  <p className="overdue">
                    פגיעה בגיבוי החשמל — סכנה לרציפות בחירום
                  </p>
                )}
                {r.faults
                  .filter((f) => f.status !== "closed")
                  .map((f) => (
                    <p className="snapshot-fault" key={f.id}>
                      <b>
                        {r.assets.find((a) => a.id === f.assetId)?.name ||
                          f.assetName}
                      </b>{" "}
                      · {STATUSES[f.status]} · {f.description}
                      {f.slaAt && <> · יעד: {date(f.slaAt)}</>}
                    </p>
                  ))}
                {showInventory && (
                  <div className="snapshot-inventory">
                    {r.assets.map((a) => (
                      <div key={a.id}>
                        <AssetIcon kind={a.kind} />
                        <b>{a.name}</b>
                        <span>{a.network}</span>
                        <Status status={a.status} />
                        {a.ip && <bdi>{a.ip}</bdi>}
                        {a.phone && <bdi>{a.phone}</bdi>}
                      </div>
                    ))}
                  </div>
                )}
              </section>
            ))}
          </div>
        )}
        <footer className="snapshot-footer">
          נתוני המערכת במועד ההפקה · {settings.appName}
          {presentation && <> · כל {rooms.length} המרחבים בחתך</>}
        </footer>
      </SnapshotFrame>
    </>
  );
}
export function Reports({ data, open }) {
  const [tab, setTab] = useState("overall"),
    [search, setSearch] = useState(""),
    [error, setError] = useState(""),
    [from, setFrom] = useState(""),
    [to, setTo] = useState("");
  const logs = data.rooms
    .flatMap((r) =>
      (r.audit || []).map((a) => ({ ...a, detail: r.name + " · " + a.detail })),
    )
    .filter(
      (a) =>
        (a.actor + " " + a.detail + " " + a.action).includes(search) &&
        (!from || a.at.slice(0, 10) >= from) &&
        (!to || a.at.slice(0, 10) <= to),
    )
    .sort((a, b) => b.at.localeCompare(a.at));
  return (
    <>
      <div className="page-heading">
        <div>
          <h1>דוחות ותובנות</h1>
          <p>כשירות, חריגות ותיעוד מלא — לפי המידע העדכני במערכת</p>
        </div>
        <button
          className="primary"
          onClick={async () => {
            try {
              const r = await apiFetch("/export", {
                credentials: "same-origin",
              });
              if (!r.ok) throw new Error("ייצוא הדוח נכשל");
              download(await r.blob(), "דוח-כשירות-ומלאי.xlsx");
            } catch (e) {
              setError(e.message);
            }
          }}
        >
          <Download size={17} />
          ייצוא דוח Excel מלא
        </button>
      </div>
      <ErrorMessage error={error} />
      <div className="report-nav">
        {[
          ["overall", "כשירות כללית"],
          ["hamal", "תמונת מצב חמ״לים"],
          ["hadan", "תמונת מצב חד״נים"],
          ["faults", "היסטוריית פערים"],
          ["archive", "ארכיון אמצעים"],
          ["audit", "בדיקות ופעילות"],
        ].map(([k, t]) => (
          <button
            className={tab === k ? "active" : ""}
            key={k}
            onClick={() => setTab(k)}
          >
            {t}
          </button>
        ))}
      </div>
      {["overall", "hamal", "hadan"].includes(tab) && (
        <Snapshot
          key={tab}
          presentation={tab !== "overall"}
          rooms={data.rooms.filter(
            (r) =>
              tab === "overall" ||
              r.type === (tab === "hamal" ? "חמ״ל" : "חד״ן"),
          )}
          settings={data.settings}
          title={
            tab === "overall"
              ? "סטטוס כשירות כללי"
              : tab === "hamal"
                ? "תמונת מצב חמ״לים"
                : "תמונת מצב חד״נים"
          }
          summaryOnly={tab === "overall"}
        />
      )}{" "}
      {tab === "faults" && (
        <FaultTable rooms={data.rooms} user={data.user} open={open} history />
      )}
      {tab === "archive" && (
        <>
          <p className="muted">
            אמצעים שהוסרו אינם נכללים בציון. המלאי, סיבת ההסרה והיסטוריית הטיפול
            נשמרים.
          </p>
          <AssetTable
            rooms={data.rooms}
            user={data.user}
            open={open}
            archived
          />
        </>
      )}
      {tab === "audit" && (
        <>
          <div className="form-grid">
            <Field label="חיפוש מבצע/ת, מרחב או פעולה">
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </Field>
            <Field label="מתאריך">
              <input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
              />
            </Field>
            <Field label="עד תאריך">
              <input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
            </Field>
          </div>
          <AuditTable logs={logs} />
        </>
      )}
    </>
  );
}
export { BaseMap } from "./features/BaseMap.jsx";
