import React, { useState, useEffect } from "react";
import { Plus, Pencil, ShieldCheck, Settings2 } from "lucide-react";
import { api, date } from "./api";
import { ROLES, WEEKDAYS } from "../../shared/model.mjs";
import { Field, Toggle, ErrorMessage, useSubmit, Empty } from "./ui";
import { ScheduleFields } from "./FormsV2";
import { Time24 } from "./DateTime24";
export function SettingsPage({ data, open, refresh }) {
  const [tab, setTab] = useState("general"),
    [users, setUsers] = useState([]),
    [mail, setMail] = useState([]),
    [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    Promise.all([api("/users"), api("/notifications")])
      .then(([u, m]) => {
        if (active) {
          setUsers(u);
          setMail(m);
        }
      })
      .catch((e) => active && setError(e.message));
    return () => {
      active = false;
    };
  }, [data]);
  return (
    <>
      <div className="page-heading">
        <div>
          <h1>ניהול מערכת</h1>
          <p>הרשאות ידניות, מועדי בדיקה ותפעול שוטף</p>
        </div>
      </div>
      <div className="report-nav">
        {[
          ["general", "הגדרות ובדיקות"],
          ["users", "משתמשים והרשאות"],
          ["mail", "עדכוני דוא״ל"],
        ].map(([k, t]) => (
          <button
            key={k}
            className={tab === k ? "active" : ""}
            onClick={() => setTab(k)}
          >
            {t}
          </button>
        ))}
      </div>
      <ErrorMessage error={error} />
      {tab === "general" && (
        <GeneralSettings data={data} refresh={refresh} />
      )}{" "}
      {tab === "users" && (
        <>
          <div className="section-heading">
            <p>ההרשאות נקבעות רק במערכת. אין הקצאה אוטומטית לפי קבוצות AD.</p>
            <button className="primary" onClick={() => open("user")}>
              <Plus size={16} />
              הקצאת הרשאה
            </button>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>משתמש</th>
                  <th>הרשאה</th>
                  <th>
                    {["owner", "command_admin"].includes(data.user.role)
                      ? "הרשאות לפי בסיס"
                      : "מרחבים בבסיס"}
                  </th>
                  <th>מצב</th>
                  <th>עריכה</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td>
                      <b>{u.name}</b>
                      <small dir="ltr">{u.username}</small>
                      <small>{u.email}</small>
                    </td>
                    <td>
                      {u.grants?.length &&
                      !["owner", "command_admin"].includes(u.role)
                        ? "הרשאות לפי בסיס"
                        : ROLES[u.role]}
                      {u.role === "owner" && <small>חשבון מוגן</small>}
                    </td>
                    <td>
                      {["owner", "command_admin"].includes(u.role)
                        ? "כל הבסיסים — כולל בסיסים חדשים"
                        : u.grants
                          ? u.grants.map((g) => (
                              <small key={g.baseId}>
                                {data.bases.find((b) => b.id === g.baseId)
                                  ?.name || "בסיס שהוסר"}{" "}
                                · {ROLES[g.role]} ·{" "}
                                {g.active ? "פעיל" : "מושבת"}
                              </small>
                            ))
                          : u.role === "admin" || u.allRooms
                            ? "כל המרחבים בבסיס"
                            : (u.roomIds || [])
                                .map(
                                  (id) =>
                                    data.rooms.find((r) => r.id === id)?.name,
                                )
                                .filter(Boolean)
                                .join(", ")}
                    </td>
                    <td>
                      {u.active ? "פעיל" : "הרשאה הוסרה"}
                      {u.testAccount && <small>משתמש בדיקה מקומי</small>}
                    </td>
                    <td>
                      {!u.canManage && (
                        <small>מנוהל בידי מנהל פיקודי או בעלים</small>
                      )}
                      {u.canManage && (
                        <div className="actions">
                          <button
                            aria-label={`עריכת ${u.name}`}
                            onClick={() => open("user", { target: u })}
                          >
                            <Pencil size={16} />
                          </button>
                          {u.role !== "owner" &&
                            u.id !== data.user.id &&
                            u.active && (
                              <button
                                onClick={() =>
                                  open("remove-user", { target: u })
                                }
                              >
                                הסרת הרשאה
                              </button>
                            )}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {tab === "mail" && (
        <>
          <div className="callout">
            {data.settings.smtpConfigured
              ? "שרת SMTP פנימי מוגדר."
              : "לא הוגדר שרת דוא״ל פנימי. הודעות ממתינות בתור ולא נשלחו."}{" "}
            סטטוס ״נשלח״ מוצג רק לאחר אישור שרת הדוא״ל.
          </div>
          {!mail.length ? (
            <Empty text="אין הודעות בתור" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>מועד</th>
                    <th>נושא</th>
                    <th>מצב</th>
                    <th>פעולה</th>
                  </tr>
                </thead>
                <tbody>
                  {mail.map((m) => (
                    <tr key={m.id}>
                      <td>{date(m.createdAt)}</td>
                      <td>{m.subject}</td>
                      <td>
                        {{
                          pending: "ממתין לשליחה",
                          sending: "הועבר לשליחה — ממתין לתוצאה",
                          sent: "נשלח",
                          partial: "נשלח לחלק מהנמענים",
                          failed: "השליחה נכשלה",
                          waiting_configuration: "ממתין להגדרות דוא״ל",
                          no_recipients: "לא נמצאו נמענים",
                        }[m.status] || m.status}
                        {m.sentAt && <small>{date(m.sentAt)}</small>}
                        {m.lastError && <small>{m.lastError}</small>}
                      </td>
                      <td>
                        {[
                          "failed",
                          "waiting_configuration",
                          "no_recipients",
                        ].includes(m.status) && (
                          <button
                            onClick={async () => {
                              try {
                                await api(
                                  "/notifications/" + m.id + "/retry",
                                  {},
                                );
                                await refresh();
                              } catch (e) {
                                setError(e.message);
                              }
                            }}
                          >
                            ניסיון חוזר
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  );
}
function GeneralSettings({ data, refresh }) {
  const g = data.settings,
    [v, set] = useState({
      version: g.version,
      baseName: g.baseName,
      freshnessDays: g.freshnessDays,
      note: g.note,
      schedule: g.schedule,
      remindersEnabled: g.remindersEnabled,
      reminderDay: g.reminderDay,
      reminderTime: g.reminderTime,
      requestMailEnabled: g.requestMailEnabled,
      recipients: g.recipients || [],
    }),
    [recipients, setRecipients] = useState((g.recipients || []).join("\n")),
    [saved, setSaved] = useState(false),
    s = useSubmit(async () => {
      await refresh();
      setSaved(true);
    });
  return (
    <form
      className="panel settings-form"
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() =>
          api(
            "/settings",
            {
              ...v,
              recipients: recipients
                .split(/[\n,;]+/)
                .map((x) => x.trim())
                .filter(Boolean),
            },
            "PATCH",
          ),
        );
      }}
    >
      {v.version !== data.settings.version && (
        <div role="alert" className="callout">
          ההגדרות השתנו בזמן העריכה. הטיוטה נשמרה ומבוססת על גרסה קודמת. יש
          לטעון מחדש לפני שמירה.
          <button type="button" onClick={() => location.reload()}>
            טעינה מחדש וביטול הטיוטה
          </button>
        </div>
      )}
      <h2>פרטי המערכת ותוקף בדיקה</h2>
      <div className="form-grid">
        <Field label="שם הבסיס">
          <input
            required
            maxLength={120}
            value={v.baseName}
            onChange={(e) => set({ ...v, baseName: e.target.value })}
          />
        </Field>
        <Field label="תוקף בדיקה (ימים)">
          <input
            type="number"
            required
            min="1"
            max="90"
            value={v.freshnessDays}
            onChange={(e) => set({ ...v, freshnessDays: +e.target.value })}
          />
        </Field>
      </div>
      <Field label="הערכת מנהל מערכת — לכל הבסיס">
        <textarea
          maxLength={2000}
          value={v.note}
          onChange={(e) => set({ ...v, note: e.target.value })}
        />
      </Field>
      <h2>מועד בדיקת כשירות</h2>
      <ScheduleFields
        value={v.schedule}
        onChange={(x) => set({ ...v, schedule: x })}
      />
      <p className="muted">
        הבדיקה המלאה צריכה להתבצע ביום שהוגדר, עד השעה שנבחרה. מרחב שלא נבדק
        מהתחלת אותו יום יוצג בחריגה לאחר המועד. ניתן להגדיר מועד נפרד בעריכת
        מרחב.
      </p>
      <h2>תזכורות ועדכונים בדוא״ל פנימי</h2>
      <Toggle
        checked={v.remindersEnabled}
        onChange={(e) => set({ ...v, remindersEnabled: e.target.checked })}
      >
        תזכורת שבועית לביצוע בדיקה
      </Toggle>
      <div className="form-grid">
        <Field label="יום התזכורת">
          <select
            value={v.reminderDay}
            onChange={(e) => set({ ...v, reminderDay: +e.target.value })}
          >
            {WEEKDAYS.map((d, i) => (
              <option key={d} value={i}>
                יום {d}
              </option>
            ))}
          </select>
        </Field>
        <Field label="שעת התזכורת (שעון ישראל)">
          <Time24
            label="שעת התזכורת"
            required
            value={v.reminderTime}
            onChange={(e) => set({ ...v, reminderTime: e.target.value })}
          />
        </Field>
      </div>
      <Field label="נמעני תזכורת (כתובת בכל שורה)">
        <textarea
          dir="ltr"
          value={recipients}
          onChange={(e) => setRecipients(e.target.value)}
        />
      </Field>
      <Toggle
        checked={v.requestMailEnabled}
        onChange={(e) => set({ ...v, requestMailEnabled: e.target.checked })}
      >
        שליחת עדכונים על פתיחה, אישור, דחייה, ביטול והשלמת בקשת בדיקה
      </Toggle>
      <p className="muted">
        בקשה חדשה נשלחת למנהלי המערכת. החלטות ותוצאות נשלחות גם למבקש ולטכנאים
        המשויכים למרחב. נדרשים SMTP פנימי וכתובות דוא״ל בכרטיסי המשתמשים.
      </p>
      <ErrorMessage error={s.error} />
      {saved && <p role="status">ההגדרות נשמרו</p>}
      <button className="primary" disabled={s.busy}>
        שמירת הגדרות
      </button>
    </form>
  );
}
export function OwnerPanel({ data, refresh, open }) {
  const g = data.settings,
    [v, set] = useState({
      version: g.version,
      appName: g.appName,
      accentColor: g.accentColor,
      defaultTheme: g.defaultTheme,
      density: g.density,
      networks: g.networks,
      defaultSlaHours: g.defaultSlaHours,
      scoring: g.scoring,
    }),
    [networks, setNetworks] = useState(g.networks.join("\n")),
    [diagnostics, setDiagnostics] = useState(null),
    [error, setError] = useState(""),
    s = useSubmit(refresh);
  useEffect(() => {
    api("/owner/diagnostics")
      .then(setDiagnostics)
      .catch((e) => setError(e.message));
  }, [data]);
  return (
    <>
      <div className="page-heading">
        <div>
          <h1>סביבת הבעלים</h1>
          <p>שליטה במנהלי המערכת, בחישוב הכשירות ובהתאמה האישית</p>
        </div>
        <ShieldCheck size={32} />
      </div>
      <form
        className="panel settings-form"
        onSubmit={(e) => {
          e.preventDefault();
          s.run(() =>
            api(
              "/owner/settings",
              {
                ...v,
                networks: [
                  ...new Set(
                    networks
                      .split("\n")
                      .map((x) => x.trim())
                      .filter(Boolean),
                  ),
                ],
              },
              "PATCH",
            ),
          );
        }}
      >
        {v.version !== data.settings.version && (
          <div role="alert" className="callout">
            ההגדרות השתנו. הטיוטה לא נדרסת; יש לטעון מחדש לפני שמירה.
            <button type="button" onClick={() => location.reload()}>
              טעינה מחדש וביטול הטיוטה
            </button>
          </div>
        )}
        <h2>זהות ותצוגה</h2>
        <div className="form-grid">
          <Field label="שם המערכת">
            <input
              required
              maxLength={120}
              value={v.appName}
              onChange={(e) => set({ ...v, appName: e.target.value })}
            />
          </Field>
          <Field label="צבע המותג">
            <input
              type="color"
              value={v.accentColor}
              onChange={(e) => set({ ...v, accentColor: e.target.value })}
            />
          </Field>
          <Field label="תצוגת ברירת מחדל למשתמש חדש">
            <select
              value={v.defaultTheme}
              onChange={(e) => set({ ...v, defaultTheme: e.target.value })}
            >
              <option value="dark">כהה</option>
              <option value="light">בהירה</option>
            </select>
          </Field>
          <Field label="צפיפות הממשק">
            <select
              value={v.density}
              onChange={(e) => set({ ...v, density: e.target.value })}
            >
              <option value="comfortable">מרווחת</option>
              <option value="compact">קומפקטית</option>
            </select>
          </Field>
          <Field label="יעד טיפול ראשוני לפער חדש (שעות)">
            <input
              type="number"
              required
              min="1"
              max="720"
              value={v.defaultSlaHours}
              onChange={(e) => set({ ...v, defaultSlaHours: +e.target.value })}
            />
          </Field>
        </div>
        <Field label="רשתות לבחירה (שם רשת בכל שורה)">
          <textarea
            required
            value={networks}
            onChange={(e) => setNetworks(e.target.value)}
          />
        </Field>
        <h2>מדיניות חישוב הכשירות</h2>
        <p className="muted">
          שינוי המשקלים מחשב מחדש את הציונים. חומרה נמדדת בין 0.01 ל־1; ערך 1
          פירושו פגיעה מלאה באמצעי.
        </p>
        <div className="form-grid">
          {Object.entries({
            critical: "משקל אמצעי קריטי",
            regular: "משקל אמצעי רגיל",
            low: "מקדם חומרה נמוכה",
            medium: "מקדם חומרה בינונית",
            high: "מקדם חומרה גבוהה",
          }).map(([k, t]) => (
            <Field key={k} label={t}>
              <input
                type="number"
                required
                step="0.01"
                min={k === "critical" ? 1 : k === "regular" ? 0.1 : 0.01}
                max={k === "critical" ? 20 : k === "regular" ? 10 : 1}
                value={v.scoring[k]}
                onChange={(e) =>
                  set({ ...v, scoring: { ...v.scoring, [k]: +e.target.value } })
                }
              />
            </Field>
          ))}
        </div>
        <ErrorMessage error={s.error} />
        <button className="primary" disabled={s.busy}>
          שמירת התאמות הבעלים
        </button>
      </form>
      <section className="panel">
        <h2>מצב ההתקנה</h2>
        <ErrorMessage error={error} />
        {diagnostics && (
          <div className="diagnostic-grid">
            {[
              ["גרסת המערכת", diagnostics.version],
              ["Node.js", diagnostics.node],
              ["MongoDB", diagnostics.mongodb],
              ["הזדהות", diagnostics.authentication],
              ["סביבת בדיקות", diagnostics.testMode ? "מופעלת" : "כבויה"],
              [
                "SMTP פנימי",
                diagnostics.smtpConfigured ? "מוגדר" : "טרם הוגדר",
              ],
              ["AD / LDAP", diagnostics.ldapConfigured ? "מוגדר" : "טרם הוגדר"],
              [
                "מקור SharePoint",
                diagnostics.sharepointOriginConfigured ? "מוגדר" : "טרם הוגדר",
              ],
              ["משאבי הממשק", "מקומיים — ללא CDN"],
            ].map(([k, t]) => (
              <div key={k}>
                <small>{k}</small>
                <b>{t}</b>
              </div>
            ))}
          </div>
        )}
        <div className="actions">
          <button onClick={() => open("user", { target: data.user })}>
            עריכת פרטי הבעלים
          </button>
          {g.demo && (
            <button
              className="danger-button"
              onClick={() => open("clear-demo")}
            >
              הסרת נתוני הדוגמה
            </button>
          )}
        </div>
        <p className="muted">
          רק הבעלים יכול למנות מנהלי מערכת ולהסיר את הרשאתם. לא ניתן להסיר או
          להשבית את חשבון הבעלים.
        </p>
      </section>
    </>
  );
}
