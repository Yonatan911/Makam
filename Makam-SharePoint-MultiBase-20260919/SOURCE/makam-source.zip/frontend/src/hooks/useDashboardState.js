import { useCallback, useEffect, useRef, useState } from "react";
import { client } from "../services/client.js";
export function useDashboardState() {
  const [data, setData] = useState(null),
    [auth, setAuth] = useState(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    dataBase = useRef(null),
    alive = useRef(false),
    pending = useRef(null),
    controller = useRef(null);
  const refresh = useCallback(() => {
    if (pending.current) return pending.current;
    const abort = new AbortController();
    controller.current = abort;
    pending.current = (async () => {
      try {
        const a = await client.json("/auth/me", undefined, "GET", {
          signal: abort.signal,
        });
        if (!alive.current) return;
        setAuth(a);
        if (!a.user) {
          setData(null);
          return;
        }
        const bases = await client.json("/bases", undefined, "GET", {
          signal: abort.signal,
        });
        const selected = sessionStorage.getItem("makam-active-base");
        if (!bases.some((b) => b.id === selected)) {
          if (bases.length)
            sessionStorage.setItem("makam-active-base", bases[0].id);
          else sessionStorage.removeItem("makam-active-base");
          if (dataBase.current && dataBase.current !== bases[0]?.id) {
            location.reload();
            return;
          }
        }
        const state = await client.json("/state", undefined, "GET", {
          signal: abort.signal,
        });
        if (alive.current) {
          dataBase.current = state.base?.id || null;
          setData(state);
          setError("");
        }
        return state;
      } catch (e) {
        if (alive.current) {
          setError(e.message);
          if (e.status === 401) {
            setData(null);
            setAuth(null);
          }
        }
        throw e;
      } finally {
        pending.current = null;
        controller.current = null;
      }
    })();
    return pending.current;
  }, []);
  useEffect(() => {
    alive.current = true;
    let timer;
    const poll = async () => {
      try {
        await refresh();
      } catch {
      } finally {
        if (alive.current) {
          setLoading(false);
          timer = setTimeout(poll, 30000);
        }
      }
    };
    (async () => {
      try {
        const linked = new URLSearchParams(window.parent.location.search).get(
          "makamBase",
        );
        if (/^[a-f0-9-]{36}$/.test(linked || ""))
          sessionStorage.setItem("makam-active-base", linked);
      } catch {}
      const launch = new URLSearchParams(location.hash.slice(1)).get("launch");
      if (launch) {
        history.replaceState(null, "", location.pathname);
        try {
          await client.json("/auth/launch", { key: launch });
        } catch (e) {
          if (alive.current) setError(e.message);
        }
      }
      if (alive.current) poll();
    })();
    return () => {
      alive.current = false;
      clearTimeout(timer);
      controller.current?.abort();
    };
  }, [refresh]);
  return { data, setData, auth, error, setError, loading, refresh };
}
