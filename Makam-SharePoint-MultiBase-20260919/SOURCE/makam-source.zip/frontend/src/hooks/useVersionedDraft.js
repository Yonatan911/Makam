import { useEffect, useRef, useState } from "react";
export function createDraft(value, version) {
  return { value: structuredClone(value), version, dirty: false };
}
export function editDraft(draft, update) {
  return {
    ...draft,
    value: typeof update === "function" ? update(draft.value) : update,
    dirty: true,
  };
}
export function receiveDraft(draft, value, version) {
  return draft.dirty || draft.version === version
    ? draft
    : createDraft(value, version);
}
export function useVersionedDraft(value, version) {
  const [draft, setDraft] = useState(() => createDraft(value, version)),
    latest = useRef({ value, version });
  latest.current = { value, version };
  useEffect(() => {
    setDraft((d) => receiveDraft(d, value, version));
  }, [value, version]);
  return {
    value: draft.value,
    version: draft.version,
    dirty: draft.dirty,
    conflict: draft.dirty && draft.version !== version,
    set: (update) => setDraft((d) => editDraft(d, update)),
    reload: () =>
      setDraft(createDraft(latest.current.value, latest.current.version)),
  };
}
