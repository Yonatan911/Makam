import React, { useEffect, useState, useCallback } from "react";
import { api, apiFetch, download, fullDate } from "./api";
import { Modal, ErrorMessage } from "./ui";
import { CATEGORIES, STATUSES } from "../../shared/model.mjs";
import { chooseBase } from "./Bases";
import { exportCommandImage } from "./command-image";
import "./command.css";

const bands = {
  green: "ירוק",
  orange: "כתום",
  red: "אדום",
  unknown: "אין נתוני כשירות",
};
const checks = {
  fresh: "בתוקף",
  aging: "מתקרבת לפקיעה",
  expired: "פג תוקף / חריגה ממועד",
  never: "טרם נבדק",
  pending: "בדיקה יזומה ממתינה",
  planned: "השבתה מתוכננת",
};
const percent = (v) => (v == null ? "—" : `${v}%`);
const categoryName = (key) =>
  key === "power" ? "יתירות" : CATEGORIES[key] || "אחר";
export function CommandScore({ base }) {
  return (
    <div className="command-score">
      <button
        className="command-score-trigger"
        aria-label={`כשירות ${base.name}: ${percent(base.score)}. הסבר החישוב`}
      >
        <strong>{percent(base.score)}</strong>
        <span>{bands[base.band]} · פירוט החישוב</span>
      </button>
      <div className="command-tooltip" role="note">
        <b>הסבר הכשירות — {base.name}</b>
        <p>
          {base.assetCount} אמצעים · {base.excludedCount} מוחרגים
        </p>
        <p>
          הציון משקלל חשיבות אמצעי, חומרת פער ותלות משביתה. השבתה מתוכננת
          ואמצעים שהוסרו אינם נכללים.
        </p>
        <p>
          {Object.entries(base.categories)
            .map(([k, v]) => `${categoryName(k)}: ${percent(v)}`)
            .join(" | ")}
        </p>
        <p className="command-explanation">{base.explanation}</p>
        <p>תוקף הבדיקה מוצג בנפרד ואינו משנה את ציון תקינות האמצעים.</p>
      </div>
    </div>
  );
}
function Trend({ trend }) {
  if (trend?.delta == null)
    return <span className="muted">מגמה: טרם נצברה מדידה קודמת</span>;
  return (
    <span title={`בהשוואה ל־${fullDate(trend.previousAt)}`}>
      מגמה:{" "}
      {trend.delta > 0
        ? "↑ עלייה"
        : trend.delta < 0
          ? "↓ ירידה"
          : "← ללא שינוי"}{" "}
      {Math.abs(trend.delta)} נק׳
    </span>
  );
}
export function CommandCard({ base, onOpen }) {
  return (
    <article className={`command-card band-${base.band}`}>
      <header>
        <h2>
          <button className="command-base-name" onClick={() => onOpen(base.id)}>
            {base.name}
          </button>
        </h2>
        <CommandScore base={base} />
      </header>
      <div className="command-categories">
        {Object.entries(base.categories).map(([key, score]) => (
          <span key={key}>
            {categoryName(key)} <b>{percent(score)}</b>
          </span>
        ))}
      </div>
      <dl className="command-facts">
        <div>
          <dt>מרחבים</dt>
          <dd>{base.roomCount}</dd>
        </div>
        <div>
          <dt>בדיקות בתוקף</dt>
          <dd>{base.validChecks}</dd>
        </div>
        <div>
          <dt>חריגות בדיקה</dt>
          <dd className={base.checkExceptions ? "command-alert" : ""}>
            {base.checkExceptions}
          </dd>
        </div>
        <div>
          <dt>פערים פתוחים</dt>
          <dd>{base.openFaults}</dd>
        </div>
        <div>
          <dt>פערים קריטיים</dt>
          <dd>{base.criticalFaults}</dd>
        </div>
        <div>
          <dt>עמידה ב־SLA</dt>
          <dd>{percent(base.sla.percent)}</dd>
        </div>
      </dl>
      <p className="command-note">
        חריגות SLA: <b>{base.sla.breached}</b> · מתוכן פתוחות:{" "}
        <b>{base.sla.openBreached}</b> · ללא יעד: {base.sla.withoutTarget}
      </p>
      <p className="command-note">
        בדיקה אחרונה במרחב בבסיס: <bdi>{fullDate(base.lastCheckAt)}</bdi>
      </p>
      <p className="command-oldest" title={base.oldestFault?.description}>
        הפער הוותיק:{" "}
        {base.oldestFault
          ? `${base.oldestFault.ageDays} ימים · ${base.oldestFault.roomName} · ${base.oldestFault.description}`
          : "אין פערים פתוחים"}
      </p>
      <footer>
        <Trend trend={base.trend} />
        <button onClick={() => onOpen(base.id)}>פירוט הבסיס ←</button>
      </footer>
    </article>
  );
}
function Detail({ data, onClose }) {
  const base = data.summary;
  return (
    <Modal title={`תמונת מצב — ${base.name}`} onClose={onClose} wide>
      <div className="command-detail">
        <CommandCard base={base} onOpen={() => chooseBase(base.id)} />
        <button onClick={() => chooseBase(base.id)}>
          מעבר לתמונת המצב המלאה של הבסיס
        </button>
        <h3>בדיקות כשירות</h3>
        <div className="command-checks">
          {Object.entries(checks).map(([key, label]) => (
            <span key={key}>
              {label}: <b>{base.checks[key]}</b>
            </span>
          ))}
        </div>
        <p className="muted">
          חריגות כוללות בדיקות שפג תוקפן, מרחבים שלא נבדקו ובדיקות יזומות שטרם
          הושלמו. מרחבים מושבתים מתוכננים מוחרגים.
        </p>
        {["חמ״ל", "חד״ן"].map((type) => (
          <section key={type}>
            <h3>
              {type === "חמ״ל" ? "חמ״לים" : "חד״נים"} — מהכשירות הנמוכה לגבוהה
            </h3>
            <div className="command-room-list">
              {data.rooms
                .filter((r) => r.type === type)
                .map((r) => (
                  <div key={r.id}>
                    <b>{r.name}</b>
                    <span>
                      {percent(r.score)} · {checks[r.check]}
                      {r.scheduleOverdue ? " · חריגה מלוח הבדיקות" : ""}
                    </span>
                    <small>בדיקה אחרונה: {fullDate(r.lastCheckAt)}</small>
                  </div>
                ))}
            </div>
            {!data.rooms.some((r) => r.type === type) && (
              <p className="muted">אין מרחבים מסוג זה</p>
            )}
          </section>
        ))}
        <h3>פערים פתוחים ({data.faults.length})</h3>
        <div className="command-room-list">
          {data.faults.map((f) => (
            <div key={f.id} className={f.slaBreached ? "command-late" : ""}>
              <b>
                {f.roomName} · {f.assetName}
              </b>
              <p>{f.description}</p>
              <span>
                {categoryName(f.category)} · חומרה:{" "}
                {{ high: "גבוהה", medium: "בינונית", low: "נמוכה" }[
                  f.severity
                ] || "לא הוגדרה"}{" "}
                · {STATUSES[f.status]}
              </span>
              <span>
                מטפל: {f.assignee}
                {f.assigneeText ? ` · ${f.assigneeText}` : ""}
              </span>
              <small>
                יעד טיפול: {fullDate(f.slaAt)}{" "}
                {f.slaBreached ? " · חריגת SLA" : ""}
              </small>
            </div>
          ))}
        </div>
        {!data.faults.length && <p>אין פערים פתוחים</p>}
        <h3>מגמת כשירות לאורך זמן</h3>
        <p className="muted">
          עד 48 נקודות המדידה האחרונות; נשמרת מדידה אחת בשעה בעת צפייה או ייצוא.
          אין השלמה של נתוני עבר.
        </p>
        {data.trend.length < 2 ? (
          <p>טרם נצברו מספיק מדידות להשוואה.</p>
        ) : (
          <div className="command-history">
            {data.trend.map((point) => (
              <div key={point.at}>
                <time>{fullDate(point.at)}</time>
                <span>
                  <i style={{ width: `${point.score || 0}%` }} />
                </span>
                <b>{percent(point.score)}</b>
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
}
export function CommandOverview() {
  const [data, setData] = useState(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [detail, setDetail] = useState(null);
  const [search, setSearch] = useState(""),
    [band, setBand] = useState("all"),
    [exception, setException] = useState("all"),
    [sort, setSort] = useState("score"),
    [view, setView] = useState("cards");
  const refresh = useCallback(async () => {
    try {
      setData(await api("/command-overview"));
      setError("");
    } catch (e) {
      setData(null);
      setDetail(null);
      setError(e.message);
    }
  }, []);
  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 60000);
    return () => clearInterval(timer);
  }, [refresh]);
  const open = async (id) => {
    setBusy(true);
    try {
      setDetail(await api(`/command-overview/${encodeURIComponent(id)}`));
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const exporting = async (kind) => {
    setBusy(true);
    setError("");
    try {
      const dark = document.documentElement.dataset.theme === "dark";
      if (kind === "image")
        await exportCommandImage(await api("/command-overview"), dark);
      else {
        const response = await apiFetch(
          `/command-overview/export?theme=${dark ? "dark" : "light"}`,
        );
        if (!response.ok)
          throw Error("ייצוא הדוח נכשל. יש לבדוק את הרשאת הגישה ולנסות שוב.");
        download(await response.blob(), "מכם-תמונת-מצב-פיקודית.xlsx");
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const rows = (data?.bases || [])
    .filter(
      (b) =>
        b.name.includes(search.trim()) &&
        (band === "all" || b.band === band) &&
        (exception === "all" ||
          (exception === "checks" && b.checkExceptions > 0) ||
          (exception === "sla" && b.sla.breached > 0) ||
          (exception === "critical" && b.criticalFaults > 0)),
    )
    .sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name, "he");
      if (sort === "score") return (a.score ?? 101) - (b.score ?? 101);
      if (sort === "sla")
        return (a.sla.percent ?? 101) - (b.sla.percent ?? 101);
      if (sort === "lastCheck")
        return (
          (Date.parse(a.lastCheckAt) || 0) - (Date.parse(b.lastCheckAt) || 0)
        );
      return b[sort] - a[sort];
    });
  const totals = data?.totals;
  return (
    <section
      className="command-overview"
      dir="rtl"
      aria-label="תמונת מצב פיקודית"
      aria-busy={busy}
    >
      <div className="command-heading">
        <div>
          <h2>כל הבסיסים. תמונת מצב אחת.</h2>
          <p className="muted">
            עודכן: {fullDate(data?.generatedAt)} · רענון אוטומטי בכל דקה
          </p>
        </div>
        <div className="command-actions">
          <button disabled={busy} onClick={refresh}>
            רענון
          </button>
          <button disabled={busy || !data} onClick={() => exporting("image")}>
            שמירת תמונת מצב
          </button>
          <button disabled={busy || !data} onClick={() => exporting("excel")}>
            ייצוא Excel
          </button>
        </div>
      </div>
      <ErrorMessage error={error} />
      {!data && !error && <p role="status">טוען תמונת מצב פיקודית…</p>}
      {totals && (
        <>
          <div className="command-totals">
            {[
              ["כשירות משוקללת", percent(totals.score)],
              ["בסיסים", totals.baseCount],
              ["ירוקים", totals.green],
              ["כתומים", totals.orange],
              ["אדומים", totals.red],
              ["בסיסים עם חריגות בדיקה", totals.basesWithCheckExceptions],
              ["פערים פתוחים", totals.openFaults],
              ["חריגות SLA", totals.slaBreached],
              ["עמידה ב־SLA", percent(totals.sla.percent)],
            ].map(([label, value]) => (
              <div key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
              </div>
            ))}
          </div>
          <p className="command-note">
            הכשירות משוקללת לפי מספר האמצעים הפעילים. {totals.unknown} בסיסים
            ללא נתוני כשירות. SLA כולל פערים פתוחים וסגורים בעלי יעד טיפול;{" "}
            {totals.sla.withoutTarget} ללא יעד, {totals.sla.unknownClosure} ללא
            תאריך סגירה. ללא הגבלת תקופה.
          </p>
          <div className="command-filters">
            <label>
              חיפוש בסיס
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="שם הבסיס"
              />
            </label>
            <label>
              כשירות
              <select value={band} onChange={(e) => setBand(e.target.value)}>
                <option value="all">כל רמות הכשירות</option>
                {Object.entries(bands).map(([k, label]) => (
                  <option key={k} value={k}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              מיקוד
              <select
                value={exception}
                onChange={(e) => setException(e.target.value)}
              >
                <option value="all">כל הבסיסים</option>
                <option value="checks">חריגות בדיקה</option>
                <option value="sla">חריגות SLA</option>
                <option value="critical">פערים קריטיים</option>
              </select>
            </label>
            <label>
              מיון
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                {[
                  ["score", "כשירות — מהנמוכה"],
                  ["openFaults", "פערים — מהמרובים"],
                  ["checkExceptions", "חריגות בדיקה — מהמרובות"],
                  ["sla", "עמידה ב־SLA — מהנמוכה"],
                  ["name", "שם בסיס"],
                  ["lastCheck", "בדיקה — מהישנה"],
                ].map(([k, label]) => (
                  <option key={k} value={k}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <div className="command-actions">
              <button
                aria-pressed={view === "cards"}
                onClick={() => setView("cards")}
              >
                כרטיסים
              </button>
              <button
                aria-pressed={view === "table"}
                onClick={() => setView("table")}
              >
                טבלה
              </button>
            </div>
          </div>
          <p className="muted">
            מציג {rows.length} מתוך {data.bases.length} בסיסים. הייצוא כולל את
            כל הבסיסים המורשים, ללא הסינון הנוכחי.
          </p>
          {!rows.length && (
            <div className="empty">אין בסיסים להצגה בחתך הנבחר.</div>
          )}
          {view === "cards" ? (
            <div className="command-grid">
              {rows.map((b) => (
                <CommandCard key={b.id} base={b} onOpen={open} />
              ))}
            </div>
          ) : (
            <div className="command-table">
              <table>
                <thead>
                  <tr>
                    {[
                      "בסיס",
                      "כשירות",
                      "מרחבים",
                      "בדיקות בתוקף",
                      "חריגות בדיקה",
                      "פערים פתוחים",
                      "חריגות SLA",
                      "עמידה ב־SLA",
                      "בדיקה אחרונה",
                    ].map((h) => (
                      <th key={h}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((b) => (
                    <tr key={b.id}>
                      <td>
                        <button onClick={() => open(b.id)}>{b.name}</button>
                      </td>
                      <td>
                        {percent(b.score)} · {bands[b.band]}
                      </td>
                      <td>{b.roomCount}</td>
                      <td>{b.validChecks}</td>
                      <td>{b.checkExceptions}</td>
                      <td>{b.openFaults}</td>
                      <td>{b.sla.breached}</td>
                      <td>{percent(b.sla.percent)}</td>
                      <td>{fullDate(b.lastCheckAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
      {detail && <Detail data={detail} onClose={() => setDetail(null)} />}
    </section>
  );
}
