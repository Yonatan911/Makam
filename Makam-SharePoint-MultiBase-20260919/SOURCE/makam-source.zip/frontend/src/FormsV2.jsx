import React, { useState } from "react";
import { api, datetimeInput, israelInputToIso } from "./api";
import { Time24, DateTime24 } from "./DateTime24";
import { Field, FormEnd, Toggle, useSubmit, Status, AssetIcon } from "./ui";
import {
  KINDS,
  CATEGORIES,
  ROLES,
  ROOM_TYPES,
  STATUSES,
  TRANSITIONS,
  WEEKDAYS,
  isManager,
  assetProfile,
  dependencyIds,
  readiness,
  hasRoomAccess,
} from "../../shared/model.mjs";
export function ScheduleFields({ value, onChange }) {
  return (
    <div className="schedule-fields">
      <Toggle
        checked={value.enabled}
        onChange={(e) => onChange({ ...value, enabled: e.target.checked })}
      >
        בדיקת כשירות שבועית מחייבת
      </Toggle>
      {value.enabled && (
        <div className="form-grid">
          <Field label="יום הבדיקה">
            <select
              value={value.day}
              onChange={(e) => onChange({ ...value, day: +e.target.value })}
            >
              {WEEKDAYS.map((d, i) => (
                <option key={d} value={i}>
                  יום {d}
                </option>
              ))}
            </select>
          </Field>
          <Field label="שעת סיום נדרשת (שעון ישראל)">
            <Time24
              label="שעת סיום נדרשת"
              required
              value={value.time}
              onChange={(e) => onChange({ ...value, time: e.target.value })}
            />
          </Field>
        </div>
      )}
    </div>
  );
}
export function RoomForm({ room, user, done }) {
  const [v, set] = useState({
      name: room?.name || "",
      type: room?.type || ROOM_TYPES[0],
      note: room?.note || "",
      maintenance: room?.maintenance || false,
      scheduleOverride: room?.scheduleOverride || null,
    }),
    s = useSubmit(done),
    put = (k, x) => set({ ...v, [k]: x });
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() =>
          api(
            "/rooms" + (room ? "/" + room.id : ""),
            room
              ? {
                  ...(isManager(user) ? v : { name: v.name, type: v.type }),
                  version: room.version,
                }
              : { name: v.name, type: v.type },
            room ? "PATCH" : "POST",
          ),
        );
      }}
    >
      <div className="form-grid">
        <Field label="שם המרחב">
          <input
            required
            maxLength={120}
            value={v.name}
            onChange={(e) => put("name", e.target.value)}
          />
        </Field>
        <Field label="סוג המרחב">
          <select value={v.type} onChange={(e) => put("type", e.target.value)}>
            {ROOM_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
      </div>
      {room && isManager(user) && (
        <>
          <Field label="הערכת מנהל מערכת">
            <textarea
              maxLength={2000}
              value={v.note}
              onChange={(e) => put("note", e.target.value)}
            />
          </Field>
          <Toggle
            checked={v.maintenance}
            onChange={(e) => put("maintenance", e.target.checked)}
          >
            השבתה מתוכננת של המרחב (מוחרגת מהציון)
          </Toggle>
          <Toggle
            checked={!!v.scheduleOverride}
            onChange={(e) =>
              put(
                "scheduleOverride",
                e.target.checked
                  ? { enabled: true, day: 4, time: "17:00" }
                  : null,
              )
            }
          >
            מועד בדיקה נפרד למרחב זה
          </Toggle>
          {v.scheduleOverride && (
            <ScheduleFields
              value={v.scheduleOverride}
              onChange={(x) => put("scheduleOverride", x)}
            />
          )}
        </>
      )}
      <FormEnd {...s} />
    </form>
  );
}
export function AssetForm({ room, asset, settings, done }) {
  const [v, set] = useState({
      name: asset?.name || "",
      kind: asset?.kind || "computer",
      category: asset?.category || "computing",
      critical: asset?.critical || false,
      network: asset?.network || settings.networks[0] || "",
      ip: asset?.ip || "",
      phone: asset?.phone || "",
      serial: asset?.serial || "",
      parentId: asset?.parentId || null,
      parentIds: asset ? dependencyIds(asset) : [],
      dependentIds: asset
        ? room.assets
            .filter((a) => dependencyIds(a).includes(asset.id))
            .map((a) => a.id)
        : [],
      dependency: asset?.dependency || "none",
      backupIds: asset?.backupIds || [],
      x: asset?.x || 50,
      y: asset?.y || 50,
      rotation: asset?.rotation || 0,
    }),
    [queue, setQueue] = useState([]),
    s = useSubmit(done),
    p = assetProfile(v.kind),
    put = (k, x) => set({ ...v, [k]: x });
  const ancestors = new Set();
  const collect = (a) => {
    for (const id of dependencyIds(a)) {
      if (ancestors.has(id)) continue;
      ancestors.add(id);
      const parent = room.assets.find((p) => p.id === id);
      if (parent) collect(parent);
    }
  };
  if (asset) collect(asset);
  const dependents = room.assets.filter(
    (a) => a.id !== asset?.id && !ancestors.has(a.id),
  );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!asset) {
          setQueue((q) => [...q, { ...v }]);
          set({ ...v, name: "", ip: "", phone: "", serial: "" });
          return;
        }
        s.run(() =>
          api(
            `/rooms/${room.id}/assets${asset ? "/" + asset.id : ""}`,
            { asset: v, version: room.version },
            asset ? "PATCH" : "POST",
          ),
        );
      }}
    >
      {!asset && (
        <section className="asset-batch" aria-label="אמצעים להוספה">
          <p>
            הוספת אמצעים למרחב <b>{room.name}</b>. ניתן להכין מספר אמצעים ולשמור
            את כולם יחד.
          </p>
          {queue.length > 0 && (
            <>
              <h3>{queue.length} אמצעים מוכנים לשמירה</h3>
              <ul>
                {queue.map((a, i) => (
                  <li key={i}>
                    <span>
                      {a.name} · {KINDS[a.kind]}
                      {a.ip ? ` · ${a.ip}` : ""}
                    </span>
                    <button
                      type="button"
                      disabled={s.busy}
                      onClick={() =>
                        setQueue((q) => q.filter((_, index) => index !== i))
                      }
                      aria-label={`הסרת ${a.name} מהרשימה`}
                    >
                      הסרה מהרשימה
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>
      )}
      <div className="form-grid">
        <Field label="סוג אמצעי">
          <select
            value={v.kind}
            onChange={(e) => {
              const kind = e.target.value;
              set({
                ...v,
                kind,
                dependentIds: kind === "ups" ? [] : v.dependentIds,
                category: assetProfile(kind).defaultCategory,
                ip: "",
                phone: "",
                network: assetProfile(kind).network ? v.network : "",
              });
            }}
          >
            {Object.entries(KINDS).map(([k, t]) => (
              <option key={k} value={k}>
                {t}
              </option>
            ))}
          </select>
        </Field>
        <Field label={p.nameLabel}>
          <input
            required
            maxLength={120}
            value={v.name}
            onChange={(e) => put("name", e.target.value)}
          />
        </Field>
        <Field label="תחום כשירות">
          <select
            value={v.category}
            onChange={(e) => put("category", e.target.value)}
          >
            {Object.entries(CATEGORIES).map(([k, t]) => (
              <option key={k} value={k}>
                {t}
              </option>
            ))}
          </select>
        </Field>
        {p.network && (
          <Field label="רשת">
            <select
              value={v.network}
              onChange={(e) => put("network", e.target.value)}
            >
              <option value="">ללא שיוך לרשת</option>
              {[
                ...new Set([...settings.networks, v.network].filter(Boolean)),
              ].map((n) => (
                <option key={n}>{n}</option>
              ))}
            </select>
          </Field>
        )}
        {p.ip && (
          <Field label="כתובת IP">
            <input
              dir="ltr"
              value={v.ip}
              maxLength={100}
              onChange={(e) => put("ip", e.target.value)}
              placeholder="192.168.1.10"
            />
          </Field>
        )}
        {p.phone && (
          <Field label="מספר טלפון">
            <input
              dir="ltr"
              type="tel"
              maxLength={80}
              value={v.phone}
              onChange={(e) => put("phone", e.target.value)}
            />
          </Field>
        )}
        <Field label="מספר סידורי / מספר מלאי (רשות)">
          <input
            dir="ltr"
            maxLength={120}
            value={v.serial}
            onChange={(e) => put("serial", e.target.value)}
          />
        </Field>
      </div>
      <Toggle
        checked={v.critical}
        onChange={(e) => put("critical", e.target.checked)}
      >
        אמצעי קריטי
      </Toggle>
      {v.kind !== "ups" && (
        <fieldset>
          <legend>אמצעים התלויים באמצעי זה (תלות משביתה)</legend>
          <p className="muted">
            בחרו אילו אמצעים מושפעים מתקלה באמצעי הנוכחי. לדוגמה: בעריכת מטריצה
            בוחרים את המסכים שהיא מזינה. שיוך לרכיבים מזינים אחרים נשמר.
          </p>
          <div className="actions">
            <button
              type="button"
              disabled={!dependents.length}
              onClick={() =>
                put(
                  "dependentIds",
                  dependents.map((a) => a.id),
                )
              }
            >
              בחירת כל האמצעים האפשריים
            </button>
            <button type="button" onClick={() => put("dependentIds", [])}>
              ניקוי הבחירה
            </button>
          </div>
          <div className="dependency-options">
            {dependents.map((a) => (
              <Toggle
                key={a.id}
                checked={v.dependentIds.includes(a.id)}
                onChange={(e) =>
                  put(
                    "dependentIds",
                    e.target.checked
                      ? [...v.dependentIds, a.id]
                      : v.dependentIds.filter((id) => id !== a.id),
                  )
                }
              >
                {a.name} · {KINDS[a.kind]}
              </Toggle>
            ))}
          </div>
          {!dependents.length && (
            <p className="muted">
              אין אמצעים זמינים לשיוך. אפשר להגדיר תלות לאחר הוספת האמצעים.
            </p>
          )}
        </fieldset>
      )}
      {v.kind !== "ups" && (
        <fieldset>
          <legend>גיבוי באמצעות אל־פסק (רשות)</legend>
          <p className="muted">
            אין חובה להתקין אל־פסק. היעדרו אינו מפחית את הציון. תקלה בגיבוי קיים
            אינה משביתה את המחשב.
          </p>
          {room.assets
            .filter((a) => a.kind === "ups" && a.id !== asset?.id)
            .map((a) => (
              <Toggle
                key={a.id}
                checked={v.backupIds.includes(a.id)}
                onChange={(e) =>
                  put(
                    "backupIds",
                    e.target.checked
                      ? [...v.backupIds, a.id]
                      : v.backupIds.filter((x) => x !== a.id),
                  )
                }
              >
                {a.name}
              </Toggle>
            ))}
        </fieldset>
      )}
      <FormEnd
        {...s}
        label={asset ? "שמירת האמצעי" : "הוספה לרשימה והכנת אמצעי נוסף"}
      />
      {!asset && (
        <button
          type="button"
          className="primary batch-save"
          disabled={s.busy || (!queue.length && !v.name.trim())}
          onClick={(e) => {
            const hasDraft = !!v.name.trim();
            if (hasDraft && !e.currentTarget.form.reportValidity()) return;
            s.run(() =>
              api(`/rooms/${room.id}/assets/bulk`, {
                version: room.version,
                assets: [...queue, ...(hasDraft ? [v] : [])],
              }),
            );
          }}
        >
          שמירת {queue.length + (v.name.trim() ? 1 : 0)} אמצעים במרחב
        </button>
      )}
    </form>
  );
}
export function CheckForm({
  room,
  user,
  settings,
  technicians,
  request,
  initialAsset,
  done,
}) {
  const assets = room.assets.filter(
      (a) =>
        a.status !== "maintenance" &&
        (!initialAsset || a.id === initialAsset.id),
    ),
    open = (a) =>
      room.faults.find((f) => f.assetId === a.id && f.status !== "closed");
  const [scope, setScope] = useState(
      initialAsset ? "selected" : request?.scope || "full",
    ),
    [rows, setRows] = useState(
      assets.map((a) => ({
        assetId: a.id,
        selected: initialAsset
          ? a.id === initialAsset.id
          : request?.scope === "selected"
            ? request.assetIds.includes(a.id)
            : true,
        marked: false,
        action:
          initialAsset?.id === a.id && !open(a)
            ? "fault"
            : open(a) ||
                room.metrics.assets.find((m) => m.id === a.id)?.loss > 0
              ? "keep"
              : "pass",
        note: "",
        severity: a.severity || "high",
        status: open(a)?.status === "waiting" ? "waiting" : "faulty",
        assigneeId: open(a)?.assigneeId || "",
        assigneeText: open(a)?.assigneeText || "",
        slaAt: datetimeInput(
          open(a)?.slaAt || Date.now() + settings.defaultSlaHours * 3600000,
        ),
        verified: false,
      })),
    ),
    [batch, setBatch] = useState({
      action: "close",
      note: "",
      severity: "high",
      status: "faulty",
      assigneeId: "",
      assigneeText: "",
    }),
    s = useSubmit(done);
  const patch = (id, values) =>
      setRows((rs) =>
        rs.map((r) => (r.assetId === id ? { ...r, ...values } : r)),
      ),
    active = rows.filter((r) => r.selected),
    marked = rows.filter((r) => r.marked && r.selected);
  const preview = readiness(
    {
      ...room,
      assets: room.assets.map((a) => {
        const result = active.find((r) => r.assetId === a.id);
        return !result
          ? a
          : {
              ...a,
              ...(result.action === "fault"
                ? { status: result.status, severity: result.severity }
                : result.action === "close"
                  ? { status: "closed" }
                  : {}),
            };
      }),
    },
    settings,
  );
  const batchApply = () =>
    setRows((rs) =>
      rs.map((r) => {
        if (!r.marked || !r.selected) return r;
        const f = open(assets.find((a) => a.id === r.assetId));
        return {
          ...r,
          ...batch,
          action:
            batch.action === "close" && !f
              ? "pass"
              : batch.action === "pass" && f
                ? "keep"
                : batch.action,
          verified: false,
        };
      }),
    );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() =>
          api(`/rooms/${room.id}/check`, {
            version: room.version,
            scope,
            roundId: settings.round?.id || null,
            outcomes: active.map(({ selected, marked, slaAt, ...r }) => ({
              ...r,
              ...(r.action === "fault"
                ? { slaAt: israelInputToIso(slaAt) }
                : {}),
            })),
          }),
        );
      }}
    >
      <div className="callout">
        <b>בדיקה אחת, כל העדכונים יחד</b>
        <p>
          אפשר לדווח על כמה פערים ולסגור פערים קיימים באותה שמירה.{" "}
          {isManager(user)
            ? "למנהל מערכת מותר לסגור פער מיידית, ללא שלב אימות."
            : "סגירת פער מחייבת אישור שבדקת את האמצעי והוא תקין."}
        </p>
      </div>
      {request && (
        <div className="note">
          <b>הבקשה שאושרה</b>
          <p>
            {request.reason} · {request.details}
          </p>
        </div>
      )}
      <Field label="היקף הבדיקה">
        <select
          value={scope}
          onChange={(e) => {
            setScope(e.target.value);
            if (e.target.value === "full")
              setRows((rs) => rs.map((r) => ({ ...r, selected: true })));
          }}
        >
          {!initialAsset && (
            <option value="full">בדיקה מלאה — כל האמצעים הפעילים</option>
          )}
          <option value="selected">בדיקה ממוקדת — אמצעים לבחירה</option>
        </select>
      </Field>
      {scope === "selected" && (
        <p className="muted">
          בדיקה ממוקדת מתועדת בנפרד ואינה מחדשת את תוקף הבדיקה המלאה.
        </p>
      )}
      <fieldset className="batch-box">
        <legend>עדכון משותף לאמצעים שסומנו ({marked.length})</legend>
        <div className="form-grid">
          <Field label="פעולה משותפת">
            <select
              value={batch.action}
              onChange={(e) => setBatch({ ...batch, action: e.target.value })}
            >
              <option value="close">סגירת הפערים / אישור תקינות</option>
              <option value="fault">דיווח או עדכון פער</option>
              <option value="pass">תקין / השארת פער קיים</option>
            </select>
          </Field>
          <Field
            label={
              batch.action === "close" ? "הערת סגירה משותפת" : "תיאור משותף"
            }
          >
            <input
              maxLength={2000}
              value={batch.note}
              onChange={(e) => setBatch({ ...batch, note: e.target.value })}
            />
          </Field>
          {batch.action === "fault" && (
            <FaultFields
              value={batch}
              onChange={setBatch}
              technicians={technicians}
              roomId={room.id}
            />
          )}
        </div>
        <div className="actions">
          <button
            type="button"
            onClick={() =>
              setRows((rs) => rs.map((r) => ({ ...r, marked: r.selected })))
            }
          >
            סימון כל המשתתפים
          </button>
          <button type="button" disabled={!marked.length} onClick={batchApply}>
            החלת הפעולה על המסומנים
          </button>
        </div>
      </fieldset>
      <div className="check-list">
        {rows.map((r) => {
          const a = assets.find((a) => a.id === r.assetId),
            f = open(a),
            inherited = preview.assets
              .find((m) => m.id === a.id)
              ?.causeIds.some((id) => id !== a.id),
            causes =
              preview.assets
                .find((m) => m.id === a.id)
                ?.causes.filter((name) => name !== a.name) || [];
          return (
            <section
              key={a.id}
              className={"check-row " + (!r.selected ? "dimmed" : "")}
            >
              <div className="check-row-head">
                {scope === "selected" && (
                  <Toggle
                    checked={r.selected}
                    onChange={(e) =>
                      patch(a.id, { selected: e.target.checked })
                    }
                  >
                    לכלול בבדיקה
                  </Toggle>
                )}
                <Toggle
                  checked={r.marked}
                  disabled={!r.selected}
                  onChange={(e) => patch(a.id, { marked: e.target.checked })}
                >
                  <AssetIcon kind={a.kind} />
                  <b>{a.name}</b>
                </Toggle>
                <Status status={a.status} />
                <span className="muted">{a.network}</span>
              </div>
              {f && <p className="muted">פער קיים: {f.description}</p>}
              {inherited && (
                <p className="callout dependency-notice">
                  כשירות האמצעי מושפעת מ־{causes.join(", ")}. השפעה זו תישאר
                  בחישוב עד לתיקון הרכיבים המזינים. אין צורך לדווח פער נוסף אם
                  לא נמצאה תקלה באמצעי עצמו.
                </p>
              )}
              {r.selected && (
                <>
                  <Field label={`תוצאת הבדיקה — ${a.name}`}>
                    <select
                      value={r.action}
                      onChange={(e) =>
                        patch(a.id, { action: e.target.value, verified: false })
                      }
                    >
                      {f ? (
                        <>
                          <option value="keep">הפער נשאר פתוח</option>
                          <option value="close">
                            {isManager(user)
                              ? "סגירת הפער מיידית"
                              : "האמצעי נבדק ותוקן — סגירת הפער"}
                          </option>
                        </>
                      ) : (
                        <>
                          <option value="pass">
                            {inherited
                              ? "לא נמצאה תקלה באמצעי עצמו — מושפע מתלות"
                              : "תקין"}
                          </option>
                          {inherited && (
                            <option value="keep">
                              השארת השפעת התלות בתיעוד הבדיקה
                            </option>
                          )}
                        </>
                      )}
                      <option value="fault">
                        {f ? "עדכון פרטי הפער" : "דיווח פער חדש"}
                      </option>
                    </select>
                  </Field>
                  {["fault", "close"].includes(r.action) && (
                    <Field
                      label={r.action === "close" ? "הערת סגירה" : "תיאור הפער"}
                    >
                      <textarea
                        required
                        minLength={3}
                        maxLength={2000}
                        value={r.note}
                        onChange={(e) => patch(a.id, { note: e.target.value })}
                      />
                    </Field>
                  )}
                  {r.action === "fault" && (
                    <div className="form-grid">
                      <FaultFields
                        value={r}
                        onChange={(v) => patch(a.id, v)}
                        technicians={technicians}
                        roomId={room.id}
                      />
                      <Field label="יעד לטיפול">
                        <DateTime24
                          label="יעד לטיפול"
                          required
                          value={r.slaAt}
                          onChange={(e) =>
                            patch(a.id, { slaAt: e.target.value })
                          }
                        />
                      </Field>
                    </div>
                  )}
                  {r.action === "close" && !isManager(user) && (
                    <Toggle
                      required
                      checked={r.verified}
                      onChange={(e) =>
                        patch(a.id, { verified: e.target.checked })
                      }
                    >
                      בדקתי את התקלה ב־{a.name} ואימתתי שתוקנה
                    </Toggle>
                  )}
                </>
              )}
            </section>
          );
        })}
      </div>
      <p>
        {active.length} אמצעים בבדיקה ·{" "}
        {active.filter((r) => r.action === "close").length} פערים לסגירה ·{" "}
        {active.filter((r) => r.action === "fault").length} דיווחים
      </p>
      <FormEnd {...s} label="שמירת כל תוצאות הבדיקה" />
    </form>
  );
}
function FaultFields({ value: v, onChange, technicians, roomId }) {
  return (
    <>
      <Field label="חומרת הפגיעה">
        <select
          value={v.severity}
          onChange={(e) => onChange({ ...v, severity: e.target.value })}
        >
          <option value="low">נמוכה</option>
          <option value="medium">בינונית</option>
          <option value="high">גבוהה</option>
        </select>
      </Field>
      <Field label="מצב הטיפול">
        <select
          value={v.status}
          onChange={(e) => onChange({ ...v, status: e.target.value })}
        >
          {["faulty", "in_progress", "waiting"].map((k) => (
            <option key={k} value={k}>
              {STATUSES[k]}
            </option>
          ))}
        </select>
      </Field>
      <Field label="מטפל">
        <select
          value={v.assigneeId}
          onChange={(e) => onChange({ ...v, assigneeId: e.target.value })}
        >
          <option value="">טרם שויך מטפל</option>
          {technicians
            .filter((t) => hasRoomAccess(t, roomId))
            .map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
        </select>
      </Field>
      <Field
        label="פרטי מטפל נוספים (טקסט חופשי, רשות)"
        help="למשל: שם ספק, צוות חיצוני או איש קשר. ניתן למלא בנוסף לטכנאי שנבחר."
      >
        <input
          maxLength={200}
          value={v.assigneeText || ""}
          onChange={(e) => onChange({ ...v, assigneeText: e.target.value })}
        />
      </Field>
    </>
  );
}
export function FaultForm({ room, fault, user, technicians, done }) {
  const [v, set] = useState({
      status: fault.status,
      note: "",
      severity: fault.severity || "high",
      assigneeId: fault.assigneeId || "",
      assigneeText: fault.assigneeText || "",
      slaAt: datetimeInput(fault.slaAt),
    }),
    s = useSubmit(done),
    options = [
      ...new Set([
        fault.status,
        ...TRANSITIONS[fault.status],
        ...(isManager(user) ? ["closed"] : []),
      ]),
    ].filter((x) => x !== "maintenance");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() =>
          api(
            `/rooms/${room.id}/faults/${fault.id}`,
            {
              ...v,
              slaAt: israelInputToIso(v.slaAt),
              version: room.version,
            },
            "PATCH",
          ),
        );
      }}
    >
      <p>{fault.description}</p>
      <Field label="מצב הטיפול">
        <select
          value={v.status}
          onChange={(e) => set({ ...v, status: e.target.value })}
        >
          {options.map((k) => (
            <option key={k} value={k}>
              {k === "closed" && isManager(user)
                ? "סגירה מיידית ללא אימות"
                : STATUSES[k]}
            </option>
          ))}
        </select>
      </Field>
      <Field label={v.status === "closed" ? "הערת סגירה" : "פירוט העדכון"}>
        <textarea
          required
          minLength={3}
          maxLength={2000}
          value={v.note}
          onChange={(e) => set({ ...v, note: e.target.value })}
        />
      </Field>
      <div className="form-grid">
        <Field label="מטפל">
          <select
            value={v.assigneeId}
            onChange={(e) => set({ ...v, assigneeId: e.target.value })}
          >
            <option value="">טרם שויך</option>
            {technicians
              .filter((t) => hasRoomAccess(t, room.id))
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
          </select>
        </Field>
        <Field label="פרטי מטפל נוספים (רשות)">
          <input
            maxLength={200}
            value={v.assigneeText}
            onChange={(e) => set({ ...v, assigneeText: e.target.value })}
          />
        </Field>
        <Field label="יעד לטיפול">
          <DateTime24
            label="יעד לטיפול"
            required
            value={v.slaAt}
            onChange={(e) => set({ ...v, slaAt: e.target.value })}
          />
        </Field>
        <Field label="חומרה">
          <select
            value={v.severity}
            onChange={(e) => set({ ...v, severity: e.target.value })}
          >
            <option value="low">נמוכה</option>
            <option value="medium">בינונית</option>
            <option value="high">גבוהה</option>
          </select>
        </Field>
      </div>
      <FormEnd {...s} />
    </form>
  );
}
export function UserForm({ target, user, rooms, done }) {
  const [v, set] = useState({
      username: target?.username || "",
      name: target?.name || "",
      email: target?.email || "",
      role: target?.role || "viewer",
      roomIds: target?.roomIds || [],
      allRooms: target?.allRooms === true,
      active: target?.active ?? true,
    }),
    s = useSubmit(done);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() =>
          api(
            "/users" + (target ? "/" + target.id : ""),
            v,
            target ? "PATCH" : "POST",
          ),
        );
      }}
    >
      <p className="muted">
        ההרשאה ניתנת ידנית לפי sAMAccountName. ההזדהות הארגונית נעשית אוטומטית
        באמצעות המשתמש המחובר.
      </p>
      <div className="form-grid">
        <Field label="sAMAccountName ב־Active Directory">
          <input
            dir="ltr"
            required
            pattern="[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}"
            maxLength={64}
            value={v.username}
            onChange={(e) => set({ ...v, username: e.target.value })}
          />
        </Field>
        <Field label="רמת הרשאה">
          <select
            disabled={target?.role === "owner"}
            value={v.role}
            onChange={(e) =>
              set({
                ...v,
                role: e.target.value,
                roomIds: v.roomIds,
              })
            }
          >
            {Object.entries(ROLES)
              .filter(([k]) =>
                k === "owner"
                  ? target?.role === "owner"
                  : !["admin", "command_admin"].includes(k) ||
                    user.role === "owner",
              )
              .map(([k, t]) => (
                <option key={k} value={k}>
                  {t}
                </option>
              ))}
          </select>
        </Field>
        <Field label="שם לתצוגה (רשות, מתעדכן מ־AD)">
          <input
            maxLength={100}
            value={v.name}
            onChange={(e) => set({ ...v, name: e.target.value })}
          />
        </Field>
        <Field label="דוא״ל ארגוני (רשות, מתעדכן מ־AD)">
          <input
            type="email"
            dir="ltr"
            value={v.email}
            onChange={(e) => set({ ...v, email: e.target.value })}
          />
        </Field>
      </div>
      {!isManager(v) && (
        <fieldset>
          <legend>מרחבים באחריות המשתמש</legend>
          <Toggle
            checked={v.allRooms}
            onChange={(e) => set({ ...v, allRooms: e.target.checked })}
          >
            כל המרחבים, כולל מרחבים שיתווספו בעתיד
          </Toggle>
          {v.allRooms && (
            <p className="muted">
              רמת ההרשאה שנבחרה תחול על כל מרחב קיים וחדש.
            </p>
          )}
          {rooms.map((r) => (
            <Toggle
              key={r.id}
              disabled={v.allRooms}
              checked={v.allRooms || v.roomIds.includes(r.id)}
              onChange={(e) =>
                set({
                  ...v,
                  roomIds: e.target.checked
                    ? [...v.roomIds, r.id]
                    : v.roomIds.filter((x) => x !== r.id),
                })
              }
            >
              {r.name} · {r.type}
            </Toggle>
          ))}
        </fieldset>
      )}
      <Toggle
        disabled={target?.role === "owner"}
        checked={v.active}
        onChange={(e) => set({ ...v, active: e.target.checked })}
      >
        הרשאה פעילה
      </Toggle>
      <FormEnd {...s} />
    </form>
  );
}
export function RequestForm({ room, done }) {
  const [v, set] = useState({
      requestedFor: datetimeInput(),
      reason: "",
      details: "",
      scope: "full",
      assetIds: [],
    }),
    s = useSubmit(done);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() =>
          api(`/rooms/${room.id}/requests`, {
            ...v,
            version: room.version,
            requestedFor: israelInputToIso(v.requestedFor),
          }),
        );
      }}
    >
      <div className="callout">
        הבקשה תועבר לאישור מנהל מערכת. לאחר האישור המרחב ידרוש בדיקה, והבקשה
        תופיע לטכנאים.
      </div>
      <Field label="המועד המבוקש לבדיקה">
        <DateTime24
          label="המועד המבוקש לבדיקה"
          required
          value={v.requestedFor}
          onChange={(e) => set({ ...v, requestedFor: e.target.value })}
        />
      </Field>
      <Field label="סיבת הבקשה">
        <textarea
          required
          minLength={3}
          maxLength={2000}
          value={v.reason}
          onChange={(e) => set({ ...v, reason: e.target.value })}
        />
      </Field>
      <Field label="מה בדיוק נדרש לבדוק?">
        <textarea
          required
          minLength={3}
          maxLength={2000}
          value={v.details}
          onChange={(e) => set({ ...v, details: e.target.value })}
        />
      </Field>
      <Field label="היקף הבדיקה">
        <select
          value={v.scope}
          onChange={(e) => set({ ...v, scope: e.target.value })}
        >
          <option value="full">בדיקה מלאה של המרחב</option>
          <option value="selected">בדיקה ממוקדת של אמצעים</option>
        </select>
      </Field>
      {v.scope === "selected" && (
        <fieldset>
          <legend>אמצעים לבדיקה</legend>
          {room.assets.map((a) => (
            <Toggle
              key={a.id}
              checked={v.assetIds.includes(a.id)}
              onChange={(e) =>
                set({
                  ...v,
                  assetIds: e.target.checked
                    ? [...v.assetIds, a.id]
                    : v.assetIds.filter((x) => x !== a.id),
                })
              }
            >
              {a.name}
            </Toggle>
          ))}
        </fieldset>
      )}
      <FormEnd {...s} label="העברת הבקשה לאישור" />
    </form>
  );
}
export function ActionForm({
  label = "שמירת העדכון",
  description,
  perform,
  done,
  requireText = true,
}) {
  const [note, set] = useState(""),
    s = useSubmit(done);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() => perform(note));
      }}
    >
      <p>{description}</p>
      {requireText && (
        <Field label="פירוט / סיבה">
          <textarea
            required
            minLength={3}
            maxLength={2000}
            value={note}
            onChange={(e) => set(e.target.value)}
          />
        </Field>
      )}
      <FormEnd {...s} label={label} />
    </form>
  );
}
export function RoundForm({ done }) {
  const [name, set] = useState(""),
    [type, setType] = useState("all"),
    s = useSubmit(done);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        s.run(() => api("/rounds", { name, type }));
      }}
    >
      <p>
        הסבב ידרוש בדיקה חדשה בכל המרחבים הפעילים שנבחרו. תיעוד הבדיקות הקודמות
        יישמר.
      </p>
      <Field label="שם הסבב / סיבה">
        <input
          required
          minLength={3}
          maxLength={200}
          value={name}
          onChange={(e) => set(e.target.value)}
        />
      </Field>
      <Field label="מרחבים בסבב">
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="all">כל המרחבים</option>
          {ROOM_TYPES.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </Field>
      <FormEnd {...s} label="הפעלת סבב בדיקה" />
    </form>
  );
}
