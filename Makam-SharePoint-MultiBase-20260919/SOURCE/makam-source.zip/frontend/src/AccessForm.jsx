import React, { useState, useEffect } from "react";
import { api } from "./api";
import { Field, Toggle, ErrorMessage, FormEnd, useSubmit } from "./ui";
import { ROLES } from "../../shared/model.mjs";

export function MultiBaseUserForm({ target, user, baseId, done }) {
  const central = ["owner", "command_admin"].includes(user.role);
  const [catalog, setCatalog] = useState(null),
    [error, setError] = useState("");
  const [identity, setIdentity] = useState({
    username: target?.username || "",
    name: target?.name || "",
    email: target?.email || "",
    role: central
      ? ["owner", "command_admin"].includes(target?.role)
        ? target.role
        : "viewer"
      : target?.role || "viewer",
    active: target?.active ?? true,
  });
  const [grants, setGrants] = useState(() => {
    const entries =
      target?.grants?.filter((g) => !g.archived) ||
      (target?.baseIds || [baseId]).map((id) => ({
        baseId: id,
        role: target?.role || "viewer",
        roomIds: target?.roomIds || [],
        allRooms: target?.allRooms === true,
        active: target?.active ?? true,
      }));
    return entries.map(({ baseId, role, roomIds, allRooms, active }) => ({
      baseId,
      role,
      roomIds,
      allRooms,
      active,
    }));
  });
  const update = (patch) => setIdentity((v) => ({ ...v, ...patch }));
  const patchGrant = (id, patch) =>
    setGrants((items) =>
      items.map((g) => (g.baseId === id ? { ...g, ...patch } : g)),
    );
  const submit = useSubmit(done);
  const globalRole = ["owner", "command_admin"].includes(identity.role);
  useEffect(() => {
    let active = true;
    api("/access-catalog")
      .then((c) => active && setCatalog(c))
      .catch((e) => active && setError(e.message));
    return () => {
      active = false;
    };
  }, []);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const grant = grants.find((g) => g.baseId === baseId) || {
          roomIds: [],
          allRooms: false,
        };
        const payload = central
          ? {
              ...identity,
              baseIds: globalRole ? [] : grants.map((g) => g.baseId),
              roomIds: [],
              allRooms: false,
              grants: globalRole
                ? []
                : grants.map((g) => ({
                    ...g,
                    roomIds: g.role === "admin" || g.allRooms ? [] : g.roomIds,
                  })),
            }
          : {
              ...identity,
              baseIds: [baseId],
              roomIds: grant.allRooms ? [] : grant.roomIds,
              allRooms: grant.allRooms,
            };
        if (target) payload.version = target.version;
        submit.run(() =>
          api(
            "/users" + (target ? "/" + target.id : ""),
            payload,
            target ? "PATCH" : "POST",
          ),
        );
      }}
    >
      <p className="muted">
        {central
          ? "ניהול מרכזי של החשבון והרשאותיו. אפשר להגדיר תפקיד שונה בכל בסיס."
          : "ההרשאה נשמרת לבסיס הנבחר בלבד. הזינו את שם המשתמש הארגוני כדי להוסיף אותו לבסיס."}
      </p>
      <ErrorMessage error={error} />
      <div className="form-grid">
        <Field label="sAMAccountName">
          <input
            dir="ltr"
            required
            maxLength={64}
            pattern="[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}"
            disabled={target?.role === "owner" || (!central && !!target)}
            value={identity.username}
            onChange={(e) => update({ username: e.target.value })}
          />
        </Field>
        <Field label={central ? "סוג הרשאה" : "הרשאה בבסיס"}>
          <select
            disabled={target?.role === "owner"}
            value={identity.role}
            onChange={(e) => update({ role: e.target.value })}
          >
            {central ? (
              <>
                <option value="viewer">הרשאות לפי בסיס</option>
                {user.role === "owner" && (
                  <option value="command_admin">מנהל מערכת פיקודי</option>
                )}
                {target?.role === "owner" && (
                  <option value="owner">בעלים</option>
                )}
              </>
            ) : (
              ["technician", "commander", "viewer"].map((role) => (
                <option value={role} key={role}>
                  {ROLES[role]}
                </option>
              ))
            )}
          </select>
        </Field>
        <Field label={central ? "שם לתצוגה" : "שם לתצוגה בבסיס"}>
          <input
            maxLength={100}
            value={identity.name}
            onChange={(e) => update({ name: e.target.value })}
          />
        </Field>
        <Field label={central ? "דוא״ל ארגוני" : "דוא״ל לעדכונים בבסיס"}>
          <input
            dir="ltr"
            type="email"
            value={identity.email}
            onChange={(e) => update({ email: e.target.value })}
          />
        </Field>
      </div>
      {globalRole ? (
        <div className="callout">
          גישה לכל הבסיסים הקיימים והעתידיים. מינוי מנהלים פיקודיים וניהול
          הבעלים מוגנים לבעלים בלבד.
        </div>
      ) : (
        <>
          {central && (
            <fieldset>
              <legend>בחירת בסיסים</legend>
              {catalog?.bases.map((base) => (
                <Toggle
                  key={base.id}
                  checked={grants.some((g) => g.baseId === base.id)}
                  onChange={(e) =>
                    setGrants((items) =>
                      e.target.checked
                        ? [
                            ...items,
                            {
                              baseId: base.id,
                              role: "viewer",
                              roomIds: [],
                              allRooms: false,
                              active: true,
                            },
                          ]
                        : items.filter((g) => g.baseId !== base.id),
                    )
                  }
                >
                  {base.name}
                </Toggle>
              ))}
            </fieldset>
          )}
          {grants
            .filter((g) => central || g.baseId === baseId)
            .map((grant) => {
              const role = central ? grant.role : identity.role;
              return (
                <fieldset key={grant.baseId} className="grant-card">
                  <legend>
                    {central
                      ? catalog?.bases.find((b) => b.id === grant.baseId)
                          ?.name || "הרשאת בסיס"
                      : "מרחבים מורשים"}
                  </legend>
                  {central && (
                    <Field label="תפקיד בבסיס">
                      <select
                        value={grant.role}
                        onChange={(e) =>
                          patchGrant(grant.baseId, { role: e.target.value })
                        }
                      >
                        {["admin", "technician", "commander", "viewer"].map(
                          (r) => (
                            <option key={r} value={r}>
                              {ROLES[r]}
                            </option>
                          ),
                        )}
                      </select>
                    </Field>
                  )}
                  {role !== "admin" && (
                    <>
                      <Toggle
                        checked={grant.allRooms}
                        onChange={(e) =>
                          patchGrant(grant.baseId, {
                            allRooms: e.target.checked,
                          })
                        }
                      >
                        כל המרחבים בבסיס, כולל מרחבים חדשים
                      </Toggle>
                      {!grant.allRooms &&
                        catalog?.rooms
                          .filter((r) => r.baseId === grant.baseId)
                          .map((room) => (
                            <Toggle
                              key={room.id}
                              checked={grant.roomIds.includes(room.id)}
                              onChange={(e) =>
                                patchGrant(grant.baseId, {
                                  roomIds: e.target.checked
                                    ? [...grant.roomIds, room.id]
                                    : grant.roomIds.filter(
                                        (id) => id !== room.id,
                                      ),
                                })
                              }
                            >
                              {room.name} · {room.type}
                            </Toggle>
                          ))}
                    </>
                  )}
                  {central && (
                    <Toggle
                      checked={grant.active}
                      onChange={(e) =>
                        patchGrant(grant.baseId, { active: e.target.checked })
                      }
                    >
                      הרשאה פעילה בבסיס
                    </Toggle>
                  )}
                </fieldset>
              );
            })}
        </>
      )}
      <Toggle
        disabled={target?.role === "owner"}
        checked={identity.active}
        onChange={(e) => update({ active: e.target.checked })}
      >
        {central ? "חשבון פעיל במערכת" : "הרשאה פעילה בבסיס"}
      </Toggle>
      {catalog ? <FormEnd {...submit} /> : <p>טוען פרטי הרשאה…</p>}
    </form>
  );
}
