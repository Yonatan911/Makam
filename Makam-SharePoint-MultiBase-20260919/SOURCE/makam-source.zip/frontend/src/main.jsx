import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { getRuntime } from "./config/runtime.js";
const root = createRoot(document.getElementById("root"));
try {
  getRuntime();
  root.render(<App />);
} catch (error) {
  root.render(
    <main
      dir="rtl"
      role="alert"
      style={{
        fontFamily: "Arial",
        maxWidth: 760,
        margin: "10vh auto",
        padding: 24,
      }}
    >
      <h1>לא ניתן להפעיל את מכ״ם</h1>
      <p>{error.message}</p>
      <p>יש לעדכן את קובץ runtime-config.js לפי מדריך ההתקנה ולרענן את הדף.</p>
    </main>,
  );
}
