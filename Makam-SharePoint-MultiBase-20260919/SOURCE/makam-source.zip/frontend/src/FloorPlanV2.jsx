import React, { useState, useRef, useLayoutEffect } from "react";
import {
  Undo2,
  Redo2,
  Plus,
  Save,
  RotateCw,
  Trash2,
  Move,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { api } from "./api";
import {
  AssetIcon,
  Field,
  Toggle,
  ErrorMessage,
  useSubmit,
  Status,
} from "./ui";
const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, n)),
  copy = (x) => structuredClone(x);
export function FloorPlan({ room, editable = false, done, onAssetSelect }) {
  const [drawing, setDrawing] = useState({
      plan: {
        ...room.plan,
        points: room.plan.points || [],
        walls: room.plan.walls || [],
        tables: room.plan.tables.map((t) => ({
          ...t,
          rotation: t.rotation || 0,
          shape: t.shape || "rectangle",
        })),
      },
      positions: room.assets.map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        rotation: a.rotation || 0,
      })),
    }),
    [selected, select] = useState(null),
    [mode, setMode] = useState("select"),
    [start, setStart] = useState(null),
    [snap, setSnap] = useState(true),
    [zoom, setZoom] = useState(1),
    [past, setPast] = useState([]),
    [future, setFuture] = useState([]),
    svg = useRef(),
    viewport = useRef(),
    [viewportSize, setViewportSize] = useState({ width: 800, height: 480 }),
    drag = useRef(null),
    s = useSubmit(done);
  useLayoutEffect(() => {
    const element = viewport.current;
    const observer = new ResizeObserver(() =>
      setViewportSize({
        width: element.clientWidth,
        height: element.clientHeight,
      }),
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  const { plan, positions } = drawing,
    W = 1000,
    H = (1000 * plan.height) / plan.width,
    pX = (n) => (n * W) / 100,
    pY = (n) => (n * H) / 100;
  const checkpoint = () => {
      setPast((p) => [...p.slice(-29), copy(drawing)]);
      setFuture([]);
    },
    change = (fn) => {
      checkpoint();
      setDrawing((d) => fn(copy(d)));
    };
  const undo = () => {
    if (!past.length) return;
    setFuture((f) => [copy(drawing), ...f]);
    setDrawing(past.at(-1));
    setPast((p) => p.slice(0, -1));
    select(null);
  };
  const redo = () => {
    if (!future.length) return;
    setPast((p) => [...p, copy(drawing)]);
    setDrawing(future[0]);
    setFuture((f) => f.slice(1));
    select(null);
  };
  const point = (e) => {
    const r = svg.current.getBoundingClientRect(),
      x = clamp(((e.clientX - r.left) / r.width) * 100),
      y = clamp(((e.clientY - r.top) / r.height) * 100);
    return {
      x: snap ? Math.round(x / 2) * 2 : x,
      y: snap ? Math.round(y / 2) * 2 : y,
    };
  };
  const pick = (e, type, id) => {
    e.stopPropagation();
    select({ type, id });
    if (!editable || mode !== "select") return;
    const item =
      type === "asset"
        ? positions.find((a) => a.id === id)
        : type === "point"
          ? plan.points[id]
          : plan.tables.find((t) => t.id === id);
    if (!item) return;
    checkpoint();
    drag.current = { type, id, origin: point(e), x: item.x, y: item.y };
    svg.current.setPointerCapture(e.pointerId);
  };
  const move = (e) => {
    if (!drag.current) return;
    const p = point(e),
      g = drag.current;
    setDrawing((d) => {
      const n = copy(d),
        item =
          g.type === "asset"
            ? n.positions.find((a) => a.id === g.id)
            : g.type === "point"
              ? n.plan.points[g.id]
              : n.plan.tables.find((t) => t.id === g.id),
        min = g.type === "asset" ? 2 : 0,
        max = g.type === "asset" ? 98 : 100;
      item.x = clamp(g.x + p.x - g.origin.x, min, max);
      item.y = clamp(g.y + p.y - g.origin.y, min, max);
      return n;
    });
  };
  const draw = (e) => {
    if (!editable || mode === "select") {
      select(null);
      return;
    }
    const p = point(e);
    if (mode === "outline") {
      change((n) => {
        n.plan.shape = "polygon";
        n.plan.points.push(p);
        return n;
      });
      return;
    }
    if (!start) setStart(p);
    else if (start.x !== p.x || start.y !== p.y) {
      change((n) => {
        n.plan.walls.push({
          id: crypto.randomUUID(),
          x1: start.x,
          y1: start.y,
          x2: p.x,
          y2: p.y,
          kind: mode,
        });
        return n;
      });
      setStart(null);
    }
  };
  const item =
    selected?.type === "asset"
      ? positions.find((a) => a.id === selected.id)
      : selected?.type === "table"
        ? plan.tables.find((t) => t.id === selected.id)
        : selected?.type === "wall"
          ? plan.walls.find((t) => t.id === selected.id)
          : selected?.type === "point"
            ? plan.points[selected.id]
            : null;
  const update = (patch) =>
    change((n) => {
      const i =
        selected.type === "asset"
          ? n.positions.find((a) => a.id === selected.id)
          : selected.type === "table"
            ? n.plan.tables.find((t) => t.id === selected.id)
            : selected.type === "wall"
              ? n.plan.walls.find((t) => t.id === selected.id)
              : n.plan.points[selected.id];
      Object.assign(i, patch);
      return n;
    });
  const outline =
    plan.shape === "polygon"
      ? plan.points
      : plan.shape === "l-shape"
        ? [
            { x: 2, y: 2 },
            { x: 98, y: 2 },
            { x: 98, y: 60 },
            { x: 65, y: 60 },
            { x: 65, y: 98 },
            { x: 2, y: 98 },
          ]
        : [
            { x: 2, y: 2 },
            { x: 98, y: 2 },
            { x: 98, y: 98 },
            { x: 2, y: 98 },
          ];
  const pickedAsset =
    selected?.type === "asset"
      ? room.metrics.assets.find((a) => a.id === selected.id)
      : null;
  return (
    <div
      className={"floor-editor " + (editable ? "is-editable" : "")}
      data-dirty={editable ? "true" : undefined}
    >
      {editable && (
        <div className="editor-toolbar">
          <button
            type="button"
            onClick={() => {
              const id = crypto.randomUUID();
              change((n) => {
                n.plan.tables.push({
                  id,
                  x: 50,
                  y: 50,
                  w: 20,
                  h: 10,
                  rotation: 0,
                  shape: "rectangle",
                  label: "שולחן",
                });
                return n;
              });
              select({ type: "table", id });
              setMode("select");
            }}
          >
            <Plus size={16} />
            ריהוט
          </button>
          <button
            type="button"
            disabled={!past.length}
            onClick={undo}
            aria-label="ביטול פעולה"
          >
            <Undo2 size={17} />
          </button>
          <button
            type="button"
            disabled={!future.length}
            onClick={redo}
            aria-label="ביצוע מחדש"
          >
            <Redo2 size={17} />
          </button>
          <Toggle checked={snap} onChange={(e) => setSnap(e.target.checked)}>
            הצמדה לרשת
          </Toggle>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2, z + 0.2))}
            aria-label="הגדלה"
          >
            <ZoomIn size={17} />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.6, z - 0.2))}
            aria-label="הקטנה"
          >
            <ZoomOut size={17} />
          </button>
          <button type="button" onClick={() => setZoom(1)}>
            התאמה למסך
          </button>
          <button
            type="button"
            className="primary"
            disabled={s.busy}
            onClick={() =>
              s.run(() =>
                api(
                  `/rooms/${room.id}/plan`,
                  { version: room.version, ...drawing },
                  "PUT",
                ),
              )
            }
          >
            <Save size={16} />
            שמירת שרטוט
          </button>
        </div>
      )}
      <div className="floor-workspace">
        {editable && (
          <aside
            className="floor-settings"
            aria-label="כלי עריכה ומאפייני פריט"
          >
            {" "}
            <div className="form-grid">
              <Field label="כלי עריכה">
                <select
                  value={mode}
                  onChange={(e) => {
                    setMode(e.target.value);
                    setStart(null);
                  }}
                >
                  <option value="select">בחירה והזזה</option>
                  <option value="wall">קיר — בחירת שתי נקודות</option>
                  <option value="door">פתח / דלת — בחירת שתי נקודות</option>
                  <option value="window">חלון — בחירת שתי נקודות</option>
                  <option value="outline">צורת חדר — הוספת פינות בלחיצה</option>
                </select>
              </Field>
              <Field label="צורת החדר">
                <select
                  value={plan.shape}
                  onChange={(e) =>
                    change((n) => {
                      n.plan.shape = e.target.value;
                      return n;
                    })
                  }
                >
                  <option value="rectangle">מלבן</option>
                  <option value="l-shape">צורת רי״ש</option>
                  <option value="polygon">צורה חופשית</option>
                </select>
              </Field>
              {["width", "height"].map((k, i) => (
                <Field key={k} label={i ? "גובה השרטוט" : "רוחב השרטוט"}>
                  <input
                    type="number"
                    min={i ? 300 : 400}
                    max={i ? 1800 : 2400}
                    value={plan[k]}
                    onChange={(e) =>
                      change((n) => {
                        n.plan[k] = clamp(
                          +e.target.value,
                          i ? 300 : 400,
                          i ? 1800 : 2400,
                        );
                        return n;
                      })
                    }
                  />
                </Field>
              ))}
            </div>
            {editable && (
              <div
                className="plan-properties"
                onKeyDown={(e) => {
                  if (
                    !item ||
                    ![
                      "ArrowLeft",
                      "ArrowRight",
                      "ArrowUp",
                      "ArrowDown",
                    ].includes(e.key) ||
                    ["INPUT", "SELECT"].includes(e.target.tagName)
                  )
                    return;
                  if (!("x" in item)) return;
                  e.preventDefault();
                  update({
                    x: clamp(
                      item.x +
                        (e.key === "ArrowRight"
                          ? 1
                          : e.key === "ArrowLeft"
                            ? -1
                            : 0),
                      selected.type === "asset" ? 2 : 0,
                      selected.type === "asset" ? 98 : 100,
                    ),
                    y: clamp(
                      item.y +
                        (e.key === "ArrowDown"
                          ? 1
                          : e.key === "ArrowUp"
                            ? -1
                            : 0),
                      selected.type === "asset" ? 2 : 0,
                      selected.type === "asset" ? 98 : 100,
                    ),
                  });
                }}
                tabIndex={0}
                aria-label="מאפייני הפריט הנבחר"
              >
                <Field label="בחירת פריט לעריכה">
                  <select
                    value={selected ? `${selected.type}:${selected.id}` : ""}
                    onChange={(e) => {
                      const [type, id] = e.target.value.split(":");
                      select(
                        id ? { type, id: type === "point" ? +id : id } : null,
                      );
                    }}
                  >
                    <option value="">בחירת פריט</option>
                    {positions.map((p) => (
                      <option key={p.id} value={`asset:${p.id}`}>
                        {room.assets.find((a) => a.id === p.id).name}
                      </option>
                    ))}
                    {plan.tables.map((t) => (
                      <option key={t.id} value={`table:${t.id}`}>
                        ריהוט: {t.label}
                      </option>
                    ))}
                    {plan.walls.map((w, i) => (
                      <option key={w.id} value={`wall:${w.id}`}>
                        מקטע {i + 1}
                      </option>
                    ))}
                    {plan.points.map((_, i) => (
                      <option key={i} value={`point:${i}`}>
                        פינת חדר {i + 1}
                      </option>
                    ))}
                  </select>
                </Field>
                {item && (
                  <>
                    <div className="form-grid">
                      {Object.entries({
                        x: "מיקום אופקי (%)",
                        y: "מיקום אנכי (%)",
                        w: "רוחב (%)",
                        h: "עומק (%)",
                        rotation: "זווית (מעלות)",
                        x1: "תחילת מקטע X",
                        y1: "תחילת מקטע Y",
                        x2: "סוף מקטע X",
                        y2: "סוף מקטע Y",
                      })
                        .filter(([k]) => k in item)
                        .map(([k, label]) => (
                          <Field key={k} label={label}>
                            <input
                              type="number"
                              value={Math.round(item[k] * 10) / 10}
                              min={
                                ["w", "h"].includes(k)
                                  ? 3
                                  : selected.type === "asset" &&
                                      ["x", "y"].includes(k)
                                    ? 2
                                    : 0
                              }
                              max={
                                k === "rotation"
                                  ? 360
                                  : ["w", "h"].includes(k)
                                    ? 95
                                    : selected.type === "asset" &&
                                        ["x", "y"].includes(k)
                                      ? 98
                                      : 100
                              }
                              onChange={(e) =>
                                update({
                                  [k]: clamp(
                                    +e.target.value,
                                    ["w", "h"].includes(k)
                                      ? 3
                                      : selected.type === "asset" &&
                                          ["x", "y"].includes(k)
                                        ? 2
                                        : 0,
                                    k === "rotation"
                                      ? 360
                                      : ["w", "h"].includes(k)
                                        ? 95
                                        : selected.type === "asset" &&
                                            ["x", "y"].includes(k)
                                          ? 98
                                          : 100,
                                  ),
                                })
                              }
                            />
                          </Field>
                        ))}
                      {selected.type === "table" && (
                        <>
                          <Field label="שם הריהוט">
                            <input
                              maxLength={60}
                              value={item.label}
                              onChange={(e) =>
                                update({ label: e.target.value })
                              }
                            />
                          </Field>
                          <Field label="צורת הריהוט">
                            <select
                              value={item.shape}
                              onChange={(e) =>
                                update({ shape: e.target.value })
                              }
                            >
                              <option value="rectangle">מלבני</option>
                              <option value="ellipse">אליפטי</option>
                              <option value="round">עגול</option>
                            </select>
                          </Field>
                        </>
                      )}
                    </div>
                    <div className="actions">
                      {"rotation" in item && (
                        <button
                          type="button"
                          onClick={() =>
                            update({ rotation: (item.rotation + 15) % 360 })
                          }
                        >
                          <RotateCw size={16} />
                          סיבוב 15°
                        </button>
                      )}
                      {selected.type !== "asset" && (
                        <button
                          type="button"
                          className="danger-button"
                          onClick={() => {
                            change((n) => {
                              if (selected.type === "point")
                                n.plan.points.splice(selected.id, 1);
                              else
                                n.plan[
                                  selected.type === "table" ? "tables" : "walls"
                                ] = n.plan[
                                  selected.type === "table" ? "tables" : "walls"
                                ].filter((t) => t.id !== selected.id);
                              return n;
                            });
                            select(null);
                          }}
                        >
                          <Trash2 size={16} />
                          מחיקת פריט שרטוט
                        </button>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}
          </aside>
        )}
        <div className="floor-stage">
          {" "}
          <div className="plan-scroll" ref={viewport}>
            <div
              style={{
                width:
                  Math.max(
                    1,
                    Math.min(
                      viewportSize.width - 4,
                      ((viewportSize.height - 4) * W) / H,
                    ),
                  ) * zoom,
                marginInline: "auto",
                aspectRatio: `${W}/${H}`,
              }}
            >
              <svg
                ref={svg}
                className="plan-canvas"
                viewBox={`0 0 ${W} ${H}`}
                role="img"
                aria-label={`שרטוט ${room.name}`}
                onPointerMove={move}
                onPointerUp={() => {
                  drag.current = null;
                }}
                onPointerCancel={() => {
                  drag.current = null;
                }}
                onPointerDown={draw}
              >
                <defs>
                  <pattern
                    id={`grid-${room.id}`}
                    width={W * 0.02}
                    height={H * 0.02}
                    patternUnits="userSpaceOnUse"
                  >
                    <path
                      d={`M ${W * 0.02} 0 L 0 0 0 ${H * 0.02}`}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth=".5"
                      opacity=".12"
                    />
                  </pattern>
                </defs>
                <rect width={W} height={H} fill={`url(#grid-${room.id})`} />
                <polygon
                  points={outline.map((p) => `${pX(p.x)},${pY(p.y)}`).join(" ")}
                  className="room-outline"
                />
                {plan.tables.map((t) => (
                  <g
                    key={t.id}
                    transform={`translate(${pX(t.x)} ${pY(t.y)}) rotate(${t.rotation})`}
                    onPointerDown={(e) => pick(e, "table", t.id)}
                    className={
                      selected?.id === t.id ? "selected-furniture" : "furniture"
                    }
                  >
                    <title>{t.label}</title>
                    {t.shape === "rectangle" ? (
                      <rect
                        x={-pX(t.w) / 2}
                        y={-pY(t.h) / 2}
                        width={pX(t.w)}
                        height={pY(t.h)}
                        rx="7"
                      />
                    ) : (
                      <ellipse
                        rx={pX(t.w) / 2}
                        ry={t.shape === "round" ? pX(t.w) / 2 : pY(t.h) / 2}
                      />
                    )}
                    <text textAnchor="middle" dominantBaseline="middle">
                      {t.label}
                    </text>
                  </g>
                ))}
                {plan.walls.map((w) => (
                  <g
                    key={w.id}
                    className={
                      "plan-wall " +
                      w.kind +
                      (selected?.id === w.id ? " selected-wall" : "")
                    }
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      select({ type: "wall", id: w.id });
                    }}
                  >
                    <line
                      x1={pX(w.x1)}
                      y1={pY(w.y1)}
                      x2={pX(w.x2)}
                      y2={pY(w.y2)}
                    />
                    <line
                      className="wall-hit"
                      x1={pX(w.x1)}
                      y1={pY(w.y1)}
                      x2={pX(w.x2)}
                      y2={pY(w.y2)}
                    />
                  </g>
                ))}
                {positions.map((p) => {
                  const a = room.metrics.assets.find((a) => a.id === p.id);
                  return (
                    <g
                      key={p.id}
                      transform={`translate(${pX(p.x)} ${pY(p.y)})`}
                      onPointerDown={(e) => pick(e, "asset", p.id)}
                      className={
                        "plan-asset " +
                        (a.planned
                          ? "planned"
                          : a.loss
                            ? "fault-pulse"
                            : "healthy") +
                        (selected?.id === p.id ? " selected-asset" : "")
                      }
                    >
                      <title>
                        {a.name + " — " + (a.loss ? "מושפע מתקלה" : "תקין")}
                      </title>
                      <g transform={`rotate(${p.rotation})`}>
                        <rect x="-19" y="-17" width="38" height="34" rx="8" />
                        <AssetIcon
                          kind={a.kind}
                          x={-10}
                          y={-10}
                          width={20}
                          height={20}
                        />
                      </g>
                      <text y="32" textAnchor="middle">
                        {a.name}
                      </text>
                    </g>
                  );
                })}
                {editable &&
                  plan.shape === "polygon" &&
                  plan.points.map((p, i) => (
                    <circle
                      key={i}
                      cx={pX(p.x)}
                      cy={pY(p.y)}
                      r="7"
                      className="plan-handle"
                      onPointerDown={(e) => pick(e, "point", i)}
                    />
                  ))}
                {start && (
                  <circle
                    cx={pX(start.x)}
                    cy={pY(start.y)}
                    r="7"
                    className="plan-handle"
                  />
                )}
              </svg>
            </div>
          </div>
        </div>
      </div>
      {editable && (
        <p className="muted editor-help">
          {mode === "outline"
            ? "לחצו לפי סדר הפינות סביב החדר (3 לפחות). לסיום בחרו בכלי ״בחירה והזזה״. אפשר לגרור כל פינה."
            : mode !== "select"
              ? start
                ? "בחרו נקודת סיום. החלפת כלי מבטלת את הקו שטרם הושלם."
                : "בחרו נקודת התחלה ונקודת סיום."
              : "גררו ציוד וריהוט. בחרו פריט כדי לשנות זווית, מידה או מיקום מדויק. חיצי המקלדת מזיזים פריט נבחר."}
        </p>
      )}
      {pickedAsset && (
        <div className="asset-inspector">
          <AssetIcon kind={pickedAsset.kind} />
          <b>{pickedAsset.name}</b>
          {!editable && onAssetSelect && (
            <button
              type="button"
              onClick={() =>
                onAssetSelect(room.assets.find((a) => a.id === pickedAsset.id))
              }
            >
              פרטי אמצעי וטיפול בפער
            </button>
          )}
          <Status status={pickedAsset.status} />
          {pickedAsset.loss > 0 && (
            <span>מושפע מ־{pickedAsset.causes.join(", ")}</span>
          )}
        </div>
      )}
      <ErrorMessage error={s.error} />
      <p className="muted">
        התוכנית היא שרטוט תפעולי למיקום ציוד; היא אינה תוכנית הנדסית בקנה מידה.
      </p>
    </div>
  );
}
