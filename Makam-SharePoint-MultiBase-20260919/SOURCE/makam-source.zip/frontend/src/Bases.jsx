import React, { useEffect, useState } from "react";
import { api, date } from "./api";
import { Field, ErrorMessage, FormEnd, useSubmit, Toggle } from "./ui";
import { ROLES, isManager } from "../../shared/model.mjs";
import { Building2 } from "lucide-react";

export function BaseSelector({ bases, baseId, disabled }) {
  if (bases.length < 2) return null;
  return (
    <div className="base-selector compact-base-selector">
      <label htmlFor="active-base">מעבר בין בסיסים</label>
      <div className="base-select-control">
        <Building2 size={16} aria-hidden="true" />
        <select
          id="active-base"
          aria-label="בחירת בסיס"
          value={baseId}
          disabled={disabled}
          onChange={(e) => chooseBase(e.target.value)}
        >
          {bases.map((base) => (
            <option key={base.id} value={base.id}>
              {base.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

export function chooseBase(id) {
  sessionStorage.setItem("makam-active-base", id);
  // Recreate all forms and pending views so nothing from the old base can be saved
  // under the newly selected base. The API still enforces access independently.
  location.reload();
}

export function BasesPage({ data, refresh }) {
  const [name, setName] = useState(""),
    [rows, setRows] = useState([]),
    [logs, setLogs] = useState([]),
    [archived, setArchived] = useState([]),
    [deleting, setDeleting] = useState(null),
    [confirmation, setConfirmation] = useState(""),
    [error, setError] = useState("");
  const global = ["owner", "command_admin"].includes(data.user.role);
  const submit = useSubmit(async () => {
    setName("");
    await refresh();
  });
  useEffect(() => {
    let active = true;
    Promise.all([
      api("/base-overview"),
      global ? api("/global-audit") : [],
      global ? api("/bases/archived") : [],
    ])
      .then(([r, l, a]) => {
        if (active) {
          setRows(r);
          setLogs(l);
          setArchived(a);
        }
      })
      .catch((e) => active && setError(e.message));
    return () => {
      active = false;
    };
  }, [data]);
  return (
    <>
      <div className="page-heading">
        <div>
          <h1>{global ? "תמונת מצב רב־בסיסית" : "הבסיסים באחריותי"}</h1>
          <p>
            כל בסיס מנוהל בנפרד: מרחבים, תצ״א, בדיקות, פערים, דוחות ותזכורות.
          </p>
        </div>
      </div>
      <ErrorMessage error={error} />
      <div className="bases-grid">
        {rows.map((base) => (
          <article className="panel base-summary" key={base.id}>
            <span className="muted">
              {base.id === data.base?.id ? "הבסיס הנבחר" : "בסיס מורשה"}
            </span>
            <h2>{base.name}</h2>
            <strong className="base-score">
              {base.metrics.overall == null
                ? "טרם הוזנו אמצעים"
                : base.metrics.overall + "% כשירות"}
            </strong>
            <p>
              {base.roomCount} מרחבים · {base.faultCount} פערים פתוחים
            </p>
            <button className="primary" onClick={() => chooseBase(base.id)}>
              פתיחת הבסיס
            </button>
            {global && (
              <button
                className="base-delete-button"
                onClick={() => {
                  setDeleting(base.id);
                  setConfirmation("");
                }}
              >
                מחיקת בסיס
              </button>
            )}
            {deleting === base.id && (
              <form
                className="base-delete-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  submit.run(async () => {
                    await api(
                      "/bases/" + base.id,
                      { version: base.version, confirmation },
                      "DELETE",
                    );
                    setDeleting(null);
                  });
                }}
              >
                <p>
                  הבסיס יוסר מהתצוגה ומגישה שוטפת. ההיסטוריה תישמר לשחזור בניהול
                  הפיקודי.
                </p>
                <Field label="הקלידו את שם הבסיס לאישור">
                  <input
                    required
                    value={confirmation}
                    onChange={(e) => setConfirmation(e.target.value)}
                  />
                </Field>
                <button
                  type="submit"
                  disabled={submit.busy || confirmation !== base.name}
                >
                  אישור מחיקת הבסיס
                </button>
                <button type="button" onClick={() => setDeleting(null)}>
                  ביטול
                </button>
                <ErrorMessage error={submit.error} />
              </form>
            )}
          </article>
        ))}
      </div>
      {global && archived.length > 0 && (
        <section className="panel">
          <h2>בסיסים שהוסרו</h2>
          {archived.map((base) => (
            <div className="section-heading" key={base.id}>
              <span>
                {base.name} · הוסר {date(base.deletedAt)}
              </span>
              <button
                disabled={submit.busy}
                onClick={() =>
                  submit.run(() =>
                    api("/bases/" + base.id + "/restore", {
                      version: base.version,
                    }),
                  )
                }
              >
                שחזור בסיס
              </button>
            </div>
          ))}
          <ErrorMessage error={submit.error} />
        </section>
      )}
      {global && (
        <form
          className="panel settings-form"
          onSubmit={(e) => {
            e.preventDefault();
            submit.run(() => api("/bases", { name }));
          }}
        >
          <h2>הוספת בסיס</h2>
          <p>
            הבסיס ייפתח ללא מרחבים וללא תמונה אווירית. הרשאות, מועדי בדיקה
            ונמעני דוא״ל יוגדרו עבורו בנפרד.
          </p>
          <Field label="שם הבסיס">
            <input
              required
              maxLength={120}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </Field>
          <ErrorMessage error={submit.error} />
          <button type="submit" className="primary" disabled={submit.busy}>
            {submit.busy ? "יוצר בסיס…" : "יצירת בסיס"}
          </button>
        </form>
      )}
      {global && (
        <section className="panel">
          <h2>יומן ניהול פיקודי</h2>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>מועד</th>
                  <th>פעולה</th>
                  <th>פרטים</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((row, i) => (
                  <tr key={row.id || i}>
                    <td>{date(row.at)}</td>
                    <td>
                      {row.action === "create_base" ? "הוספת בסיס" : row.action}
                    </td>
                    <td>{row.name || row.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </>
  );
}

export { MultiBaseUserForm } from "./AccessForm";
