import React from "react";
import logo from "./assets/makam-logo.png";
import { APP_NAME, APP_DESCRIPTION } from "../../shared/branding.mjs";

export function BrandLogo({ className = "", decorative = false }) {
  return (
    <img
      className={`brand-logo ${className}`}
      src={logo}
      width={1129}
      height={1129}
      alt={decorative ? "" : `${APP_NAME} — ${APP_DESCRIPTION}`}
    />
  );
}
