// Public values only. Configure once per deployment; no rebuild/source edit.
// Production package replaces this development file with a fail-closed template.
window.MAKAM_RUNTIME_CONFIG=Object.freeze({schemaVersion:1,apiBaseUrl:'http://127.0.0.1:4310/api',environment:'development',releaseVersion:'3.1.0',authMode:'local-test'});
