// The library build gets only public URLs from config.js. No secret is shipped to SharePoint.
const isLibrary = import.meta.env?.VITE_SHAREPOINT_LIBRARY === "true";
let bearer = "",
  expiry = 0,
  pending;
export { isLibrary };
function settings() {
  const config = window.MAKAM_SHAREPOINT_CONFIG;
  if (!config) throw new Error("חסר קובץ הגדרות SharePoint: config.js");
  const backend = new URL(config.apiOrigin),
    web = new URL(config.webUrl);
  // about:srcdoc reports a "null" location.origin, although its security origin
  // is inherited from the SharePoint parent. Read the same-origin parent here.
  let pageOrigin;
  try {
    pageOrigin =
      location.protocol === "about:"
        ? window.parent.location.origin
        : location.origin;
  } catch {
    throw new Error("יש לפתוח את המערכת מתוך דף SharePoint מורשה");
  }
  if (
    backend.protocol !== "https:" ||
    backend.pathname !== "/" ||
    backend.username ||
    backend.password ||
    backend.search ||
    backend.hash ||
    web.origin !== pageOrigin ||
    web.protocol !== "https:" ||
    web.search ||
    web.hash
  )
    throw new Error("כתובות השרת ו־SharePoint אינן תקינות בקובץ ההגדרות");
  return { backend: backend.origin, web: web.href.replace(/\/$/, "") };
}
export function apiAddress(url) {
  return (isLibrary ? settings().backend : "") + "/api" + url;
}
async function jsonResponse(response, fallback) {
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(fallback);
  }
  if (!response.ok)
    throw new Error(data.error?.message?.value || data.error || fallback);
  return data;
}
function windowsSam(login) {
  const match =
    /^(?:i:0#\.w\|)?([^\\]+)\\([a-zA-Z0-9][a-zA-Z0-9._-]{0,63})$/i.exec(
      login || "",
    );
  if (!match) throw new Error("נדרש חשבון Windows ארגוני ב־SharePoint");
  return match[2].toLowerCase();
}
async function login() {
  const config = settings();
  const spGet = (suffix) =>
    fetch(config.web + "/_api" + suffix, {
      credentials: "same-origin",
      cache: "no-store",
      headers: { Accept: "application/json;odata=verbose" },
    });
  const current = await jsonResponse(
    await spGet("/web/currentUser"),
    "לא ניתן לזהות את המשתמש המחובר ל־SharePoint",
  );
  const expectedSam = windowsSam(current.d.LoginName);
  const post = (url, body) =>
    fetch(apiAddress(url), {
      method: "POST",
      credentials: "omit",
      cache: "no-store",
      headers: {
        "Content-Type": "application/json",
        "X-Readiness-Client": "dashboard",
      },
      body: JSON.stringify(body),
    });
  const challenge = await jsonResponse(
    await post("/auth/sharepoint/challenge", {}),
    "לא ניתן להתחיל הזדהות מול שרת מכ״ם",
  );
  if (
    challenge.webUrl !== config.web ||
    !/^[a-f0-9]{64}$/.test(challenge.id) ||
    !/^\/[a-zA-Z0-9/_-]+$/.test(challenge.folder) ||
    challenge.fileName !== "makam-" + challenge.id + ".txt"
  )
    throw new Error("הגדרות ספריית האימות אינן תואמות לשרת");
  const info = await jsonResponse(
    await fetch(config.web + "/_api/contextinfo", {
      method: "POST",
      credentials: "same-origin",
      headers: { Accept: "application/json;odata=verbose" },
    }),
    "לא ניתן לקבל אישור פעולה מ־SharePoint",
  );
  const digest = info.d.GetContextWebInformation.FormDigestValue;
  const uploadUrl =
    config.web +
    "/_api/web/GetFolderByServerRelativeUrl('" +
    challenge.folder +
    "')/Files/Add(url='" +
    challenge.fileName +
    "',overwrite=false)";
  await jsonResponse(
    await fetch(uploadUrl, {
      method: "POST",
      credentials: "same-origin",
      headers: {
        Accept: "application/json;odata=verbose",
        "Content-Type": "text/plain",
        "X-RequestDigest": digest,
      },
      body: challenge.id,
    }),
    "אין אפשרות ליצור קובץ אימות בספריית SharePoint. יש לבדוק הרשאת הוספת קבצים.",
  );
  const session = await jsonResponse(
    await post("/auth/sharepoint/complete", {
      id: challenge.id,
      secret: challenge.secret,
    }),
    "אימות המשתמש נכשל",
  );
  if (session.username !== expectedSam || !/^[a-f0-9]{64}$/.test(session.token))
    throw new Error(
      "המשתמש המאומת אינו תואם למשתמש SharePoint. יש לרענן את הדף.",
    );
  bearer = session.token;
  expiry = Date.parse(session.expiresAt);
}
async function ensureSession() {
  if (bearer && Date.now() < expiry - 30000) return;
  if (!pending)
    pending = login().finally(() => {
      pending = undefined;
    });
  await pending;
}
export async function apiFetch(url, options = {}) {
  const baseId = sessionStorage.getItem("makam-active-base");
  options = { ...options, headers: { ...options.headers, ...(baseId && !url.startsWith("/auth/") ? { "X-Base-Id": baseId } : {}) } };
  if (!isLibrary)
    return fetch(apiAddress(url), { credentials: "same-origin", ...options });
  await ensureSession();
  const response = await fetch(apiAddress(url), {
    ...options,
    credentials: "omit",
    cache: "no-store",
    headers: { ...options.headers, Authorization: "Bearer " + bearer },
  });
  // Do not replay writes automatically. The user's action may already have reached the server.
  if (response.status === 401 || url === "/auth/logout") {
    bearer = "";
    expiry = 0;
  }
  return response;
}
