# קובצי הטמעה מחייבים

web.config המחייב ב־backend/web.config. מתאם SharePoint ב־deployment/sharepoint. מדריכי התקנה ובדיקות קבלה ב־GUIDE וב־docs. תשתית service/ARR/proof הישנה נשמרה ב־baseline וב־.verification בלבד, ואינה בחבילת ברירת המחדל.
