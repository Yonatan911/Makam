"use strict";
const rateLimit = require("express-rate-limit").rateLimit;
const randomUUID = require("node:crypto").randomUUID;
const z = require("zod").z;
const token = require("../src/security.js").token;
const hash = require("../src/security.js").hash;
const safeEqual = require("../src/security.js").safeEqual;
const safeUser = require("../src/security.js").safeUser;
const normalizeWindowsIdentity = require("../src/security.js").normalizeWindowsIdentity;
const syncAdProfile = require("../src/ad-profile.js").syncAdProfile;
const installSharePointProof = require("./sharepoint-proof.js").installSharePointProof;
const proofConfiguration = require("./sharepoint-proof.js").proofConfiguration;
const fail = require("../src/validation.js").fail;
const parse = require("../src/validation.js").parse;
const id = require("../src/validation.js").id;
async function installAuth(app, db, config, {
  readProof
} = {}) {
  const users = db.collection("users"),
    sessions = db.collection("sessions");
  if (config.authMode === "sharepoint-library") await installSharePointProof(app, db, proofConfiguration(), readProof);
  const testMode = config.authMode === "local-test" && process.env.ENABLE_LOCAL_TEST_LOGIN === "true" && process.env.NODE_ENV !== "production";
  if (config.authMode === "windows-proxy" && (!process.env.AD_DOMAIN || !process.env.TRUSTED_PROXY_SECRET || process.env.TRUSTED_PROXY_SECRET.length < 32)) throw new Error("Windows SSO requires AD_DOMAIN and a strong TRUSTED_PROXY_SECRET.");
  if (testMode) {
    const all = await db.collection("rooms").find().toArray(),
      hamal = all.find(r => r.type === "חמ״ל") || all[0];
    for (const [username, name, role] of [["test.admin", "מנהל מערכת לדוגמה", "admin"], ["test.technician", "טכנאי לדוגמה", "technician"], ["test.commander", "מפקד מרחב לדוגמה", "commander"], ["test.viewer", "נציג מרחב לדוגמה", "viewer"]]) {
      const uid = randomUUID();
      await users.updateOne({
        username
      }, {
        $setOnInsert: {
          _id: uid,
          id: uid,
          username,
          name,
          role,
          roomIds: role === "technician" ? all.map(r => r.id) : hamal ? [hamal.id] : [],
          active: true,
          testAccount: true,
          email: "",
          preferences: {}
        }
      }, {
        upsert: true
      });
    }
  }
  async function sessionFor(user, res) {
    const raw = token();
    await sessions.insertOne({
      _id: hash(raw),
      userId: user.id,
      expiresAt: new Date(Date.now() + 8 * 3600000)
    });
    res.cookie("readiness_session", raw, {
      httpOnly: true,
      secure: config.cookieSecure,
      sameSite: config.cookieSecure && process.env.SHAREPOINT_ORIGIN ? "none" : "lax",
      path: "/",
      maxAge: 8 * 3600000
    });
    return safeUser(user);
  }
  const rawCookie = req => (req.headers.cookie || "").split(";").map(s => s.trim()).find(s => s.startsWith("readiness_session="))?.slice("readiness_session=".length);
  async function currentUser(req) {
    if (config.authMode === "sharepoint-library") {
      const bearer = /^Bearer ([a-f0-9]{64})$/.exec(req.get("Authorization") || "")?.[1];
      if (!bearer) return null;
      const session = await sessions.findOne({
        _id: hash(bearer),
        authMode: "sharepoint-library",
        expiresAt: {
          $gt: new Date()
        }
      });
      return session ? users.findOne({
        id: session.userId,
        active: true,
        testAccount: {
          $ne: true
        }
      }) : null;
    }
    if (config.authMode === "windows-proxy") {
      if (!safeEqual(req.get("X-Readiness-Proxy"), process.env.TRUSTED_PROXY_SECRET)) return null;
      const username = normalizeWindowsIdentity(req.get("X-Remote-User"), process.env.AD_DOMAIN);
      if (!username) return null;
      return syncAdProfile(await users.findOne({
        username,
        active: true,
        testAccount: {
          $ne: true
        }
      }), users);
    }
    const raw = rawCookie(req);
    if (!raw || raw.length !== 64) return null;
    const session = await sessions.findOne({
      _id: hash(raw),
      expiresAt: {
        $gt: new Date()
      }
    });
    return session ? users.findOne({
      id: session.userId,
      active: true
    }) : null;
  }
  const limiter = rateLimit({
    windowMs: 60000,
    limit: 40,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: "יותר מדי בקשות כניסה. יש להמתין דקה."
    }
  });
  app.get("/api/auth/me", async (req, res) => {
    const user = await currentUser(req);
    res.json({
      user: user ? safeUser(user) : null,
      authMode: config.authMode,
      testMode
    });
  });
  app.get("/api/auth/local-users", async (req, res) => {
    if (!testMode) throw fail(404, "פעולה אינה זמינה");
    res.json((await users.find({
      active: true
    }).toArray()).map(u => ({
      id: u.id,
      name: u.name,
      role: u.role,
      username: u.username,
      testAccount: !!u.testAccount
    })));
  });
  app.post("/api/auth/local-login", limiter, async (req, res) => {
    if (!testMode) throw fail(404, "פעולה אינה זמינה");
    const {
        userId
      } = parse(z.object({
        userId: id
      }), req.body),
      user = await users.findOne({
        id: userId,
        active: true
      });
    if (!user) throw fail(404, "המשתמש אינו זמין");
    const previous = await currentUser(req);
    const raw = rawCookie(req);
    if (raw) await sessions.deleteOne({
      _id: hash(raw)
    });
    await db.collection("adminAudit").insertOne({
      id: randomUUID(),
      at: new Date().toISOString(),
      actorId: user.id,
      actor: user.name,
      action: "החלפת משתמש בסביבת בדיקה",
      detail: `${previous?.name || "כניסה"} ← ${user.name}`,
      testMode: true
    });
    res.json({
      user: await sessionFor(user, res)
    });
  });
  app.post("/api/auth/login", limiter, (req, res) => {
    throw fail(403, "המערכת משתמשת בהזדהות ארגונית ללא סיסמה. בסביבת הבדיקה יש לבחור משתמש.");
  });
  app.post("/api/auth/launch", limiter, async (req, res) => {
    if (["windows-proxy", "sharepoint-library"].includes(config.authMode)) throw fail(404, "פעולה אינה זמינה");
    const {
      key
    } = parse(z.object({
      key: z.string().length(64)
    }), req.body);
    const launch = await db.collection("launchTokens").findOneAndDelete({
      _id: hash(key),
      expiresAt: {
        $gt: new Date()
      }
    });
    if (!launch) throw fail(401, "קישור ההפעלה פג תוקף. יש להפעיל שוב מקיצור הדרך.");
    const user = await users.findOne({
      id: launch.userId,
      active: true
    });
    if (!user) throw fail(401, "חשבון לא פעיל");
    res.json({
      user: await sessionFor(user, res)
    });
  });
  app.post("/api/auth/logout", async (req, res) => {
    if (config.authMode === "sharepoint-library") {
      const bearer = /^Bearer ([a-f0-9]{64})$/.exec(req.get("Authorization") || "")?.[1];
      if (bearer) await sessions.deleteOne({
        _id: hash(bearer),
        authMode: "sharepoint-library"
      });
      return res.json({
        ok: true
      });
    }
    const raw = rawCookie(req);
    if (raw) await sessions.deleteOne({
      _id: hash(raw)
    });
    res.clearCookie("readiness_session", {
      path: "/"
    }).json({
      ok: true
    });
  });
  app.use("/api", async (req, res, next) => {
    req.user = await currentUser(req);
    if (!req.user) throw fail(401, "המשתמש אינו מורשה. נדרש זיהוי ארגוני ושיוך ידני במערכת.");
    req.testMode = testMode;
    next();
  });
  return {
    testMode
  };
}
exports.installAuth = installAuth;
