"use strict";
const execFile = require("node:child_process").execFile;
const promisify = require("node:util").promisify;
const fileURLToPath = require("node:url").fileURLToPath;
const path = require("node:path");
const rateLimit = require("express-rate-limit").rateLimit;
const token = require("../src/security.js").token;
const hash = require("../src/security.js").hash;
const normalizeWindowsIdentity = require("../src/security.js").normalizeWindowsIdentity;
const fail = require("../src/validation.js").fail;
const execFileAsync = promisify(execFile);
const script = path.resolve(__dirname,"Read-Proof.ps1");
const hex = /^[a-f0-9]{64}$/;
function normalizeSharePointLogin(login, domain) {
  // Only Windows claims are accepted. Never strip arbitrary provider prefixes.
  return normalizeWindowsIdentity(typeof login === "string" ? login.replace(/^i:0#\.w\|/i, "") : login, domain);
}
function proofConfiguration(env = process.env) {
  const web = new URL(env.SP_WEB_URL);
  if (web.protocol !== "https:" || web.username || web.password || web.search || web.hash) throw new Error("SP_WEB_URL must be an internal HTTPS web URL");
  const folder = env.SP_PROOF_FOLDER || "";
  if (!/^\/[a-zA-Z0-9/_-]+$/.test(folder) || folder.endsWith("/") || folder.includes("//")) throw new Error("SP_PROOF_FOLDER must be an ASCII server-relative folder without spaces or trailing slash");
  const webPath = web.pathname.replace(/\/$/, "");
  if (!folder.startsWith(webPath + "/")) throw new Error("Proof library must be inside SP_WEB_URL");
  if (new URL(env.SHAREPOINT_ORIGIN).origin !== web.origin || !env.AD_DOMAIN) throw new Error("SharePoint origin and AD domain must match proof configuration");
  return {
    webUrl: web.href.replace(/\/$/, ""),
    folder,
    domain: env.AD_DOMAIN
  };
}
async function readSharePointProof(config, id) {
  if (!hex.test(id)) throw new Error("Invalid proof ID");
  // Use the Windows service identity; no user password, impersonation or browser cookie is forwarded.
  const powershell = path.join(process.env.SystemRoot || "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
  const {
    stdout
  } = await execFileAsync(powershell, ["-NoLogo", "-NoProfile", "-NonInteractive", "-File", script, "-WebUrl", config.webUrl, "-Folder", config.folder, "-ProofId", id], {
    windowsHide: true,
    timeout: 20000,
    maxBuffer: 65536
  });
  return JSON.parse(stdout.replace(/^\uFEFF/, "").trim());
}
async function installSharePointProof(app, db, config, readProof = readSharePointProof) {
  const challenges = db.collection("spChallenges"),
    sessions = db.collection("sessions");
  await challenges.createIndex({
    expiresAt: 1
  }, {
    expireAfterSeconds: 0
  });
  const limiter = rateLimit({
    windowMs: 60000,
    limit: 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: "יותר מדי ניסיונות הזדהות. יש להמתין דקה."
    }
  });
  let activeReads = 0;
  app.post("/api/auth/sharepoint/challenge", limiter, async (req, res) => {
    const id = token(),
      secret = token(),
      now = new Date();
    await challenges.insertOne({
      _id: id,
      secretHash: hash(secret),
      createdAt: now,
      expiresAt: new Date(+now + 120000)
    });
    // Only the ID is uploaded to SharePoint. The exchange secret stays in this browser's memory.
    res.json({
      id,
      secret,
      fileName: "makam-" + id + ".txt",
      webUrl: config.webUrl,
      folder: config.folder
    });
  });
  app.post("/api/auth/sharepoint/complete", limiter, async (req, res) => {
    const {
      id,
      secret
    } = req.body || {};
    if (typeof id !== "string" || typeof secret !== "string" || !hex.test(id) || !hex.test(secret)) throw fail(400, "בקשת ההזדהות אינה תקינה");
    if (activeReads >= 4) throw fail(503, "שירות ההזדהות עמוס. יש לנסות שוב בעוד מספר שניות.");
    activeReads++;
    let proof, challenge;
    try {
      challenge = await challenges.findOneAndDelete({
        _id: id,
        secretHash: hash(secret),
        expiresAt: {
          $gt: new Date()
        }
      });
      if (!challenge) throw fail(401, "האימות פג תוקף או כבר נוצל. יש להתחבר מחדש.");
      proof = await readProof(config, id);
    } catch (error) {
      if (error.status) throw error;
      throw fail(503, "השרת לא הצליח לאמת את יוצר קובץ SharePoint. יש לבדוק את חשבון השירות והגישה לספריית האימות.");
    } finally {
      activeReads--;
    }
    const username = normalizeSharePointLogin(proof.loginName, config.domain);
    const created = Date.parse(proof.createdAt);
    if (!username || proof.content !== id || !Number.isFinite(created) || created < +challenge.createdAt - 30000 || created > Date.now() + 30000) throw fail(401, "פרטי האימות מ־SharePoint אינם תקינים");
    const user = await db.collection("users").findOne({
      username,
      active: true,
      testAccount: {
        $ne: true
      }
    });
    if (!user) throw fail(403, "המשתמש זוהה ב־SharePoint אך לא הוקצתה לו הרשאה פעילה במכ״ם.");
    const bearer = token(),
      expiresAt = new Date(Date.now() + 3600000);
    await sessions.insertOne({
      _id: hash(bearer),
      userId: user.id,
      authMode: "sharepoint-library",
      expiresAt
    });
    await db.collection("adminAudit").insertOne({
      id: token(),
      at: new Date().toISOString(),
      actorId: user.id,
      actor: user.name,
      action: "הזדהות באמצעות SharePoint",
      detail: username,
      testMode: false
    });
    res.json({
      token: bearer,
      username,
      expiresAt
    });
  });
}
exports.normalizeSharePointLogin = normalizeSharePointLogin;
exports.proofConfiguration = proofConfiguration;
exports.readSharePointProof = readSharePointProof;
exports.installSharePointProof = installSharePointProof;
