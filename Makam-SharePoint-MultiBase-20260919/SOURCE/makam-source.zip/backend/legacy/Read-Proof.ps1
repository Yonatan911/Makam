param(
  [Parameter(Mandatory=$true)][string]$WebUrl,
  [Parameter(Mandatory=$true)][string]$Folder,
  [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{64}$')][string]$ProofId
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$siteUri = [Uri]$WebUrl
if ($siteUri.Scheme -ne 'https' -or $siteUri.UserInfo -or $siteUri.Query -or $siteUri.Fragment) { throw 'Invalid SharePoint URL' }
if ($Folder -notmatch '^/[a-zA-Z0-9/_-]+$') { throw 'Invalid proof folder' }
$filePath = $Folder + '/makam-' + $ProofId + '.txt'
$fileEndpoint = $WebUrl.TrimEnd('/') + "/_api/web/GetFileByServerRelativeUrl('" + $filePath + "')"
function Read-TrustedResponse([string]$Url) {
  $request = [Net.HttpWebRequest]::Create($Url)
  $request.Method = 'GET'
  $request.UseDefaultCredentials = $true
  $request.AllowAutoRedirect = $false
  $request.Accept = 'application/json;odata=verbose'
  $request.Timeout = 7000
  $request.ReadWriteTimeout = 7000
  $response = $request.GetResponse()
  try {
    if ([int]$response.StatusCode -ne 200) { throw 'Unexpected SharePoint response' }
    $stream = $response.GetResponseStream()
    $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::UTF8)
    try {
      $buffer = New-Object char[] 16385
      $length = $reader.ReadBlock($buffer, 0, $buffer.Length)
      if ($length -gt 16384) { throw 'SharePoint response too large' }
      if ($length -eq 0) { return '' }
      return (-join $buffer[0..($length - 1)])
    } finally { $reader.Dispose() }
  } finally { $response.Dispose() }
}
# Read the file author set by SharePoint, never a name in uploaded JSON or list text fields.
$metadata = Read-TrustedResponse ($fileEndpoint + '?$select=TimeCreated,Author/LoginName&$expand=Author') | ConvertFrom-Json
$content = Read-TrustedResponse ($fileEndpoint + '/$value')
@{ loginName = $metadata.d.Author.LoginName; createdAt = $metadata.d.TimeCreated; content = $content } | ConvertTo-Json -Compress
