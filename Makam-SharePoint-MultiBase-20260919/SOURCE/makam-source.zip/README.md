# מכ״ם — מערכת כשירות מרחבית, מרובת בסיסים

גרסה 3.1.0. זו הגרסה המקומית האחרונה שעליה נעשתה העבודה, עם כל יכולות ריבוי הבסיסים ותמונת המצב הפיקודית. בסיס המקור: a22b4e12f100227af755cbea150948cda1d1b9f8.

מקור יחיד: frontend/src עבור React ו־backend/src עבור Express/CommonJS; shared מכיל חישובי כשירות משותפים. הקוד העסקי הועבר מהגרסה המקומית ולא הוחלף במערכת בעלת בסיס יחיד.

חבילת המסירה הקיימת מתעדכנת באותו מיקום: ../../delivery/Makam-SharePoint-MultiBase-20260919/{FRONT,SERVER,GUIDE}. README זה אינו מחליף את GUIDE/INSTALLATION.he.md, ובו הפקודות המדויקות להתקנה, מיגרציה וקבלת DevOps.

IISNode מפעיל ישירות SERVER/src/server.js באמצעות Named Pipe; FRONT מוגש מספריית SharePoint; MongoDB הוא השירות הארגוני הקיים. אין npm/build, ARR, שירות Node נפרד או התקנת Mongo נוספת בשרת. אין שירות אינטרנט חיצוני בזמן ריצה.

בנייה: npm ci --ignore-scripts; npm run lint; npm test; npm run test:browser; npm run build; npm run package. האריזה דורשת commit נקי ומעדכנת את חבילת המסירה הקיימת. אימות: npm run verify.

בדיקות IIS/SharePoint והזדהות ארגוניות: NOT RUN. TRUSTED_IDENTITY_VERIFIED נשאר false בייצור עד דוח קבלה של DevOps.

מענה לדוח DevOps מ־07.10.2026: docs/DELTA-REVIEW.he.md. החבילה כוללת כעת SOURCE עם Git bundle מלא ומקור ZIP באותו commit. שחזור מעותק נקי ותיעוד פלט בדיקות: GUIDE/REPRODUCING.he.md ו־node scripts/verify-delta.mjs source. עדויות ניידות יימסרו לצד ZIP; שערי יעד: GUIDE/DELTA-TARGET.he.md. מאגר GitHub ששימש לסקירה נשאר לקריאה בלבד.

לפתיחת תצוגת בדיקה מבודדת במחשב: START-LOCAL.ps1. נדרשים Node ו־MongoDB קיימים; התצוגה משתמשת במסד readiness_test_multibase_preview ובפורט 4322, ואינה משנה את נתוני העבודה הקודמים.
