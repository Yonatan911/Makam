import 'dotenv/config';
import http from 'node:http';
import {randomBytes} from 'node:crypto';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(here,'../..');
if(process.env.AUTH_MODE!=='local-test'||process.env.ENABLE_LOCAL_TEST_LOGIN!=='true'||process.env.NODE_ENV==='production')throw new Error('The test center is available only in the explicitly enabled local test installation.');
const origin='http://127.0.0.1:4314',key=randomBytes(32).toString('hex'),reportDir=path.join(root,'.runtime','test-center');await mkdir(reportDir,{recursive:true});
let state={status:'idle',log:'',passed:0,failed:0,total:0},child=null;
try{state=JSON.parse(await readFile(path.join(reportDir,'latest.json'),'utf8'));if(state.status==='running')state={...state,status:'interrupted',message:'ההרצה הקודמת הופסקה. אפשר להפעיל בדיקה חדשה.'}}catch{}
const suites={unit:['domain.test.mjs','v2-domain.test.mjs','ui.test.mjs','sharepoint-client.test.mjs'],integration:['api.test.mjs','windows-proxy.test.mjs','migration-mail.test.mjs','sharepoint-library.test.mjs'],all:['domain.test.mjs','v2-domain.test.mjs','ui.test.mjs','api.test.mjs','windows-proxy.test.mjs','migration-mail.test.mjs','sharepoint-client.test.mjs','sharepoint-library.test.mjs']};
const persist=()=>writeFile(path.join(reportDir,'latest.json'),JSON.stringify(state,null,2));
function json(res,code,value){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value))}
function run(suite){
 state={status:'running',suite,startedAt:new Date().toISOString(),endedAt:null,total:0,passed:0,failed:0,log:'',message:'הבדיקות מתבצעות…'};
 child=spawn(process.execPath,['--test','--test-reporter=tap',...suites[suite].map(f=>path.join(root,'tests',f))],{cwd:root,windowsHide:true,env:{...process.env,NO_COLOR:'1',FORCE_COLOR:'0',NODE_OPTIONS:'',LDAP_URL:'',SMTP_HOST:'',SMTP_FROM:''},stdio:['ignore','pipe','pipe']});
 const append=chunk=>{state.log=(state.log+chunk.toString()).slice(-180000);for(const [field,label] of [['total','tests'],['passed','pass'],['failed','fail']]){const match=state.log.match(new RegExp('^# '+label+' (\\d+)\\s*$','m'));if(match)state[field]=Number(match[1])}};
 child.stdout.on('data',append);child.stderr.on('data',append);
 child.on('error',error=>{state.message='לא ניתן להפעיל את הבדיקות: '+error.message});
 child.on('close',code=>{state.status=code===0?'passed':'failed';state.endedAt=new Date().toISOString();state.message=code===0?'כל הבדיקות בהרצה עברו בהצלחה.':'ההרצה לא הושלמה בהצלחה. פירוט זמין ביומן הבדיקה.';child=null;persist().catch(()=>{})});persist().catch(()=>{});
}
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
 try{
 if(req.headers.host!=='127.0.0.1:4314')return json(res,403,{error:'כתובת אינה מורשית'});
 const url=new URL(req.url,origin);
 if(req.method==='GET'&&url.pathname==='/health')return json(res,200,{service:'readiness-test-center',ok:true});
 if(req.method==='GET'&&url.pathname==='/api/status')return json(res,200,state);
 if(req.method==='POST'&&url.pathname==='/api/run'){
  if(req.headers.origin!==origin||req.headers['x-test-center']!==key)return json(res,403,{error:'יש לפתוח את מרכז הבדיקות מהמחשב המקומי ולנסות שוב.'});
  if(child)return json(res,409,{error:'בדיקה כבר מתבצעת. יש להמתין לסיומה.'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>1024)return json(res,413,{error:'בקשה גדולה מדי'})}
  let suite;try{suite=JSON.parse(body).suite}catch{return json(res,400,{error:'בקשה אינה תקינה'})}if(!Object.hasOwn(suites,suite))return json(res,400,{error:'סוג בדיקה אינו מוכר'});
  if(suite!=='unit'){try{const response=await fetch('http://127.0.0.1:4310/api/health',{signal:AbortSignal.timeout(3000)});const health=await response.json();if(!response.ok||health.service!=='command-readiness'||health.authMode!=='local-test'||health.database!=='connected')throw new Error()}catch{return json(res,503,{error:'סביבת הבדיקה אינה פועלת. פתחו מחדש את קיצור הדרך ״מכ״ם — מרכז בדיקות״ ואז לחצו על הרצה.'})}}
  // Claim the runner synchronously after the asynchronous health probe.
  if(child)return json(res,409,{error:'בדיקה כבר מתבצעת. יש להמתין לסיומה.'});run(suite);return json(res,202,state);
 }
 if(req.method==='GET'&&url.pathname==='/api/log'){res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Content-Disposition':'attachment; filename="readiness-tests.txt"'});return res.end(state.log||'טרם בוצעה הרצה')}
 const files={'/':'index.html','/center.js':'center.js','/center.css':'center.css'};
 if(req.method==='GET'&&files[url.pathname]){let contents=await readFile(path.join(here,files[url.pathname]));if(url.pathname==='/')contents=Buffer.from(contents.toString().replace('__TOKEN__',key));res.writeHead(200,{'Content-Type':url.pathname==='/'?'text/html; charset=utf-8':url.pathname.endsWith('.js')?'text/javascript; charset=utf-8':'text/css; charset=utf-8'});return res.end(contents)}
 if(req.method==='GET'&&url.pathname==='/logo.png'){res.writeHead(200,{'Content-Type':'image/png'});return res.end(await readFile(path.join(root,'src/assets/makam-logo.png')))}
 if(req.method==='GET'&&url.pathname==='/heebo.woff2'){res.writeHead(200,{'Content-Type':'font/woff2'});return res.end(await readFile(path.join(root,'node_modules/@fontsource/heebo/files/heebo-hebrew-400-normal.woff2')))}
 json(res,404,{error:'העמוד אינו קיים'});
 }catch{if(!res.headersSent)json(res,500,{error:'אירעה שגיאה במרכז הבדיקות'});else res.end()}
});
server.listen(4314,'127.0.0.1',()=>console.log('Local test center ready: '+origin));
