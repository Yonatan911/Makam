import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import { transform } from "esbuild";
import { build } from "vite";
export const root = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
export async function buildShared() {
  const output = path.resolve(root, "backend/shared");
  if (path.relative(root, output) !== path.join("backend", "shared"))
    throw new Error("Unsafe generated shared output path");
  await fs.mkdir(output, { recursive: true });
  for (const name of await fs.readdir(path.join(root, "shared"))) {
    if (!name.endsWith(".mjs")) continue;
    const source = (
      await fs.readFile(path.join(root, "shared", name), "utf8")
    ).replaceAll('.mjs"', '.js"');
    const { code } = await transform(source, {
      format: "cjs",
      platform: "node",
      target: "node22",
    });
    // Readers must never see a deleted/truncated model during a rebuild.
    const destination = path.join(output, name.replace(".mjs", ".js"));
    const temporary = destination + "." + randomUUID() + ".tmp";
    await fs.writeFile(temporary, code);
    await fs.rename(temporary, destination);
  }
}
export async function buildFrontend() {
  await buildShared();
  await build({ configFile: path.join(root, "frontend/vite.config.js") });
  const front = path.join(root, ".build/FRONT");
  await fs.writeFile(
    path.join(front, "runtime-config.js"),
    `// PUBLIC configuration. Set your approved URLs before upload. No secrets.\nwindow.MAKAM_RUNTIME_CONFIG=Object.freeze({schemaVersion:1,apiBaseUrl:'',environment:'production',releaseVersion:'3.1.0',authMode:'iis-session'});\n`,
  );
  for (const name of ["loader.js", "embed.html"])
    await fs.copyFile(
      path.join(root, "deployment/sharepoint", name),
      path.join(front, name),
    );
}
if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
)
  await buildFrontend();
