import fs from "node:fs/promises";
import path from "node:path";
import { spawnSync, execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { MongoClient } from "mongodb";
import { root } from "./build.mjs";

// Portable evidence capture. Needs an explicitly provisioned test MongoDB on
// loopback:27028 and approved Chrome. Never installs/stops services or touches IIS.
const mode = process.argv[2] || "source";
if (!["source", "package"].includes(mode))
  throw new Error("Use: verify-delta.mjs source | package RELEASE_PATH");
const release =
  mode === "package"
    ? path.resolve(
        process.argv[3] || "../../delivery/Makam-SharePoint-MultiBase-20260919",
      )
    : null;
const output = path.resolve(
  process.env.MAKAM_EVIDENCE_DIR ||
    path.join(root, ".verification/delta", mode),
);
await fs.mkdir(output, { recursive: true });
const sanitize = (text) => {
  for (const [value, replacement] of [
    [release, "<RELEASE>"],
    [root, "<SOURCE>"],
    [process.env.USERPROFILE, "<USERPROFILE>"],
  ]) {
    if (value)
      text = text
        .split(value)
        .join(replacement)
        .split(value.replaceAll("\\", "/"))
        .join(replacement);
  }
  return text;
};
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const evidence = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  mode,
  sourceCommit: execFileSync("git", ["rev-parse", "HEAD"], {
    cwd: root,
    encoding: "utf8",
    windowsHide: true,
  }).trim(),
  sourceDirty: !!execFileSync("git", ["status", "--porcelain"], {
    cwd: root,
    encoding: "utf8",
    windowsHide: true,
  }).trim(),
  environment: {
    platform: process.platform,
    architecture: process.arch,
    node: process.version,
  },
  targetEnvironment: "BLOCKED — TARGET ENVIRONMENT REQUIRED",
  commands: [],
};
const mongo = new MongoClient("mongodb://127.0.0.1:27028", {
  serverSelectionTimeoutMS: 3000,
});
try {
  await mongo.connect();
  evidence.environment.mongo = (
    await mongo.db("admin").command({ buildInfo: 1 })
  ).version;
} finally {
  await mongo.close();
}
const childEnv = {
  ...process.env,
  NODE_ENV: "test",
  MONGODB_URI: "mongodb://127.0.0.1:27028",
  SMTP_HOST: "",
  SMTP_FROM: "",
  SMTP_USER: "",
  SMTP_PASSWORD: "",
  LDAP_URL: "",
  LDAP_BIND_DN: "",
  LDAP_BIND_PASSWORD: "",
  MAKAM_EVIDENCE_DIR: output,
};
delete childEnv.MAKAM_TEST_SERVER_ROOT;
delete childEnv.MAKAM_TEST_RELEASE_ROOT;
if (release) {
  childEnv.MAKAM_TEST_SERVER_ROOT = path.join(release, "SERVER");
  childEnv.MAKAM_TEST_RELEASE_ROOT = release;
  const manifest = await fs.readFile(path.join(release, "manifest.json"));
  evidence.release = {
    sourceCommit: JSON.parse(manifest).sourceCommit,
    manifestSha256: sha(manifest),
  };
  if (evidence.release.sourceCommit !== evidence.sourceCommit)
    throw new Error("Run the same source commit as the packaged release");
}
const commands =
  mode === "source"
    ? [
        ["lint", ["scripts/lint.mjs"]],
        ["tests", ["scripts/test.mjs"]],
        ["build", ["scripts/build.mjs"]],
        [
          "browser",
          ["--test", "--test-reporter=tap", "tests/browser.test.mjs"],
        ],
      ]
    : [
        ["verify", ["scripts/verify-release.mjs", release]],
        [
          "tests",
          [
            "--test",
            "--test-reporter=tap",
            "tests/api.test.mjs",
            "tests/multibase.test.mjs",
            "tests/ipc-rate-limit.test.mjs",
          ],
        ],
        [
          "browser",
          ["--test", "--test-reporter=tap", "tests/browser.test.mjs"],
        ],
      ];
try {
  for (const [name, args] of commands) {
    console.log("Running", name, "for", mode);
    const start = Date.now();
    const result = spawnSync(process.execPath, args, {
      cwd: root,
      env: childEnv,
      encoding: "utf8",
      windowsHide: true,
      maxBuffer: 32 * 1024 * 1024,
    });
    const log = sanitize((result.stdout || "") + (result.stderr || ""));
    const filename = name + ".txt";
    await fs.writeFile(path.join(output, filename), log);
    evidence.commands.push({
      command: "node " + args.map((a) => sanitize(a)).join(" "),
      exitCode: result.status,
      elapsedMs: Date.now() - start,
      artifact: filename,
      sha256: sha(Buffer.from(log)),
      status: result.status === 0 ? "REPRODUCED" : "FAILED",
    });
    if (result.status !== 0) throw new Error(name + " failed; see " + filename);
    if (name === "browser") {
      const browserDir = path.join(root, ".verification/browser");
      await fs.cp(browserDir, path.join(output, "browser"), {
        recursive: true,
      });
      const summary = path.join(output, "browser/result.json");
      await fs.writeFile(summary, sanitize(await fs.readFile(summary, "utf8")));
    }
  }
  evidence.status = "PASS";
} catch (error) {
  evidence.status = "FAIL";
  throw error;
} finally {
  await fs.writeFile(
    path.join(output, "commands.json"),
    JSON.stringify(evidence, null, 2) + "\n",
  );
  console.log("Evidence:", output);
}
