import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { buildShared } from "./build.mjs";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
await buildShared();
const frontend = process.argv.includes("--frontend");
const files = frontend
  ? ["frontend-runtime.test.mjs", "ui.test.mjs"]
  : (await fs.readdir(path.join(root, "tests"))).filter(
      (f) => f.endsWith(".test.mjs") && f !== "browser.test.mjs",
    );
const result = spawnSync(
  process.execPath,
  ["--test", "--test-reporter=tap", ...files.map((f) => path.join(root, "tests", f))],
  { cwd: root, stdio: "inherit", windowsHide: true },
);
process.exitCode = result.status ?? 1;
