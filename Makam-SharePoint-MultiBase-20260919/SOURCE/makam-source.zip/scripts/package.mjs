import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { spawnSync, execFileSync } from "node:child_process";
import { buildFrontend, root } from "./build.mjs";
import { verifyRelease } from "./verify-release.mjs";
import { normalizeReleaseText } from "./release-text.mjs";
const sourceCommit = execFileSync("git", ["rev-parse", "HEAD"], {
  cwd: root,
  encoding: "utf8",
  windowsHide: true,
}).trim();
if (
  execFileSync("git", ["status", "--porcelain", "--untracked-files=all"], {
    cwd: root,
    encoding: "utf8",
    windowsHide: true,
  }).trim()
)
  throw new Error("Commit the reviewed source before packaging a release");
const version = JSON.parse(
  await fs.readFile(path.join(root, "package.json"), "utf8"),
).version;
const workspace = path.resolve(root, "../.."),
  delivery = path.join(workspace, "delivery"),
  releaseName = "Makam-SharePoint-MultiBase-20260919",
  published = path.join(delivery, releaseName),
  target = path.join(root, ".build", "assembled-release"),
  stage = path.join(root, ".build", "production-dependencies");
async function safeClear(dir) {
  const resolved = path.resolve(dir);
  if (!resolved.startsWith(path.join(root, ".build") + path.sep))
    throw new Error("Unsafe build cleanup path");
  await fs.rm(resolved, { recursive: true, force: true });
  await fs.mkdir(resolved, { recursive: true });
}
await buildFrontend();
await safeClear(stage);
for (const name of ["package.json", "package-lock.json"])
  await fs.copyFile(path.join(root, "backend", name), path.join(stage, name));
const npmCli =
  process.env.NPM_CLI_PATH ||
  path.join(path.dirname(process.execPath), "node_modules/npm/bin/npm-cli.js");
if (!(await fs.stat(npmCli).catch(() => null)))
  throw new Error(
    "Builder only: set NPM_CLI_PATH to approved npm-cli.js; never npm install on the target",
  );
// Explicit online preparation is optional on the BUILD machine. Default is cached/offline.
const result = spawnSync(
  process.execPath,
  [
    npmCli,
    "ci",
    "--omit=dev",
    "--ignore-scripts",
    "--workspaces=false",
    "--no-audit",
    "--no-fund",
    ...(process.env.PREPARE_DEPENDENCIES_ONLINE === "true"
      ? []
      : ["--offline"]),
  ],
  { cwd: stage, stdio: "inherit", windowsHide: true },
);
if (result.status !== 0)
  throw new Error(
    "Production dependency closure could not be prepared on the builder",
  );
await safeClear(target);
await fs.cp(path.join(root, ".build/FRONT"), path.join(target, "FRONT"), {
  recursive: true,
});
await fs.mkdir(path.join(target, "SERVER"), { recursive: true });
for (const name of [
  "src",
  "shared",
  "api",
  "scripts",
  "web.config",
  ".env.example",
  "package.json",
  "package-lock.json",
])
  await fs.cp(
    path.join(root, "backend", name),
    path.join(target, "SERVER", name),
    { recursive: true },
  );
await fs.cp(
  path.join(stage, "node_modules"),
  path.join(target, "SERVER/node_modules"),
  { recursive: true },
);
await fs.cp(path.join(root, "GUIDE"), path.join(target, "GUIDE"), {
  recursive: true,
});
for (const name of ["Target-Smoke.ps1", "Inspect-Target.ps1"])
  await fs.copyFile(
    path.join(root, "deployment", name),
    path.join(target, "GUIDE", name),
  );
await fs.copyFile(
  path.join(root, "scripts/verify-release.mjs"),
  path.join(target, "GUIDE/verify-release.mjs"),
);
for (const name of [
  "REMEDIATION-MATRIX.md",
  "API-INVENTORY.md",
  "TEST-RESULTS.md",
  "HANDOFF.he.md",
  "RELEASE-RESULTS.md",
  "CHANGED-FILES.md",
  "DELTA-REVIEW.he.md",
])
  await fs.copyFile(
    path.join(root, "docs", name),
    path.join(target, "GUIDE", name),
  );
await fs.copyFile(
  path.join(root, "deployment/delivery.gitattributes"),
  path.join(target, ".gitattributes"),
);
// The full authoritative Git source travels with the same existing delivery.
// Do not copy working files or ignored runtime data into this distribution.
const sourceDir = path.join(target, "SOURCE");
await fs.mkdir(sourceDir, { recursive: true });
const branch = execFileSync("git", ["symbolic-ref", "--short", "HEAD"], {
  cwd: root,
  encoding: "utf8",
  windowsHide: true,
}).trim();
const tracked = execFileSync("git", ["ls-tree", "-r", "--name-only", "HEAD"], {
  cwd: root,
  encoding: "utf8",
  windowsHide: true,
})
  .trim()
  .split("\n");
if (
  tracked.some((p) =>
    /(^|\/)(node_modules|\.runtime|\.verification|\.env(?!\.example$)[^/]*)(\/|$)/.test(
      p,
    ),
  )
)
  throw new Error(
    "Sensitive/runtime source file would enter source distribution",
  );
execFileSync(
  "git",
  [
    "-c",
    "pack.threads=1",
    "bundle",
    "create",
    path.join(sourceDir, "makam-source.bundle"),
    "HEAD",
    "refs/heads/" + branch,
  ],
  { cwd: root, windowsHide: true },
);
execFileSync(
  "git",
  [
    "archive",
    "--format=zip",
    "--output=" + path.join(sourceDir, "makam-source.zip"),
    sourceCommit,
  ],
  { cwd: root, windowsHide: true },
);
const sourceArtifacts = [];
for (const name of ["makam-source.bundle", "makam-source.zip"]) {
  const bytes = await fs.readFile(path.join(sourceDir, name));
  sourceArtifacts.push({
    path: name,
    bytes: bytes.length,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  });
}
await fs.writeFile(
  path.join(sourceDir, "source.json"),
  JSON.stringify(
    {
      sourceCommit,
      branch,
      sourceFiles: tracked.length,
      artifacts: sourceArtifacts,
    },
    null,
    2,
  ) + "\n",
);
await fs.copyFile(
  path.join(root, "GUIDE/REPRODUCING.he.md"),
  path.join(sourceDir, "README.he.md"),
);
// Normalize FINAL generated/copied first-party text before hashing. Vendor bytes
// and source archives are deliberately immutable and never newline-converted.
await normalizeReleaseText(target);
const files = [];
async function walk(dir) {
  for (const entry of (await fs.readdir(dir, { withFileTypes: true })).sort(
    (a, b) => a.name.localeCompare(b.name),
  )) {
    const file = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) throw new Error("Release cannot contain links");
    if (entry.isDirectory()) await walk(file);
    else
      files.push({
        path: path.relative(target, file).split(path.sep).join("/"),
        bytes: (await fs.stat(file)).size,
        sha256: createHash("sha256")
          .update(await fs.readFile(file))
          .digest("hex"),
      });
  }
}
await walk(target);
const manifest = {
  schemaVersion: 1,
  releaseVersion: version,
  edition: "sharepoint-multibase",
  baselineCommit: "a22b4e12f100227af755cbea150948cda1d1b9f8",
  sourceCommit,
  sourceDirty: false,
  sourceDistribution: {
    gitBundle: "SOURCE/makam-source.bundle",
    sourceArchive: "SOURCE/makam-source.zip",
    metadata: "SOURCE/source.json",
    policy:
      "Git LF; final first-party payload LF; vendor and archives byte-preserved",
  },
  frontend: {
    builder: "Vite",
    base: "./",
    runtimeConfig: "FRONT/runtime-config.js",
    canonicalSource: "frontend/src",
  },
  backend: {
    entry: "SERVER/src/server.js",
    authenticationEntry: "SERVER/api/auth/session.js",
    moduleFormat: "CommonJS",
    platform: process.platform,
    architecture: process.arch,
  },
  runtime: {
    node: ">=22.12.0",
    builderNode: process.version,
    targetRuntimeVerified: false,
    iisnode: "existing approved installation; direct named-pipe hosting",
    mongo:
      "existing organizational service; schema 2 + iisnodeMultibaseSchema 1; all base namespaces",
  },
  targetEnvironment: {
    status: "NOT RUN",
    acceptance: "BLOCKED — TARGET ENVIRONMENT REQUIRED",
    gate: "DevOps evidence: installed Node/IISNode and Windows-auth/native-identity boundary + real smoke report",
  },
  files,
};
await fs.writeFile(
  path.join(target, "manifest.json"),
  JSON.stringify(manifest, null, 2) + "\n",
);
await verifyRelease(target);
// Publish only a fully assembled, verified package. Preserve the prior delivery in
// the local ignored verification area before replacing this exact existing edition.
const backup = path.join(root, ".verification", "previous-delivery");
if (path.relative(workspace, published) !== path.join("delivery", releaseName))
  throw new Error("Unsafe delivery destination");
if (await fs.stat(published).catch(() => null)) {
  if (!(await fs.stat(backup).catch(() => null))) {
    await fs.mkdir(path.dirname(backup), { recursive: true });
    await fs.rename(published, backup);
  } else {
    await fs.rm(published, { recursive: true, force: true });
  }
}
await fs.mkdir(delivery, { recursive: true });
await fs.rename(target, published);
const archive = path.join(delivery, releaseName + ".zip");
if (await fs.stat(archive).catch(() => null)) {
  const previousZip = path.join(root, ".verification", "previous-delivery.zip");
  if (!(await fs.stat(previousZip).catch(() => null)))
    await fs.copyFile(archive, previousZip);
}
// Windows' bundled bsdtar preserves dotfiles and packages the exact verified tree.
const archiveResult = spawnSync(
  "tar.exe",
  [
    "-a",
    "-c",
    "-f",
    path.relative(published, archive),
    "FRONT",
    "SERVER",
    "GUIDE",
    "manifest.json",
    ".gitattributes",
    "SOURCE",
  ],
  { cwd: published, stdio: "inherit", windowsHide: true },
);
if (archiveResult.status !== 0)
  throw new Error("Creating the offline ZIP failed");
const archiveHash = createHash("sha256")
  .update(await fs.readFile(archive))
  .digest("hex");
const manifestHash = createHash("sha256")
  .update(await fs.readFile(path.join(published, "manifest.json")))
  .digest("hex");
await fs.writeFile(
  path.join(delivery, releaseName + ".sha256.txt"),
  `${archiveHash}  ${path.basename(archive)}\n${manifestHash}  ${releaseName}/manifest.json\n`,
);
await fs.writeFile(
  path.join(delivery, releaseName + ".release-report.json"),
  JSON.stringify(
    {
      sourceCommit,
      commitsCreated: execFileSync(
        "git",
        [
          "rev-list",
          "--reverse",
          "a22b4e12f100227af755cbea150948cda1d1b9f8..HEAD",
        ],
        { cwd: root, encoding: "utf8", windowsHide: true },
      )
        .trim()
        .split(/\r?\n/),
      sourceDirty: false,
      version,
      archive: path.basename(archive),
      archiveSha256: archiveHash,
      manifestSha256: manifestHash,
      files: files.length,
      packagedVerification: "PASS",
      targetEnvironment: "NOT RUN",
    },
    null,
    2,
  ) + "\n",
);
console.log("Offline multi-base release:", published);
console.log("ZIP:", archive, "SHA-256:", archiveHash);
