import fs from "node:fs/promises";
import path from "node:path";
import { spawnSync, execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { root } from "./build.mjs";

const release = path.resolve(
  process.argv[2] || "../../delivery/Makam-SharePoint-MultiBase-20260919",
);
const output = path.resolve(
  process.env.MAKAM_FRESH_EVIDENCE_DIR ||
    path.join(root, ".verification/fresh-checkout"),
);
const clone = path.join(output, "workspace/variants/sharepoint-multibase");
if (await fs.stat(clone).catch(() => null))
  throw new Error(
    "Use a NEW fresh-checkout evidence directory; existing checkouts are never deleted",
  );
await fs.mkdir(output, { recursive: true });
const npm =
  process.env.NPM_CLI_PATH ||
  path.join(path.dirname(process.execPath), "node_modules/npm/bin/npm-cli.js");
await fs.access(npm);
const manifest = JSON.parse(
  await fs.readFile(path.join(release, "manifest.json"), "utf8"),
);
const result = {
  sourceCommit: manifest.sourceCommit,
  node: process.version,
  platform: process.platform,
  architecture: process.arch,
  targetEnvironment: "BLOCKED — TARGET ENVIRONMENT REQUIRED",
  commands: [],
};
const sanitize = (text) =>
  text
    .split(clone)
    .join("<FRESH_SOURCE>")
    .split(root)
    .join("<SOURCE>")
    .split(process.env.USERPROFILE || "__unused__")
    .join("<USERPROFILE>");
function run(name, executable, args, cwd, env = process.env) {
  const run = spawnSync(executable, args, {
    cwd,
    env,
    encoding: "utf8",
    windowsHide: true,
    maxBuffer: 32 * 1024 * 1024,
  });
  const log = sanitize((run.stdout || "") + (run.stderr || ""));
  result.commands.push({
    name,
    command: sanitize([path.basename(executable), ...args].join(" ")),
    exitCode: run.status,
    artifact: name + ".txt",
  });
  return { log, status: run.status };
}
async function step(...args) {
  const runResult = run(...args);
  await fs.writeFile(path.join(output, args[0] + ".txt"), runResult.log);
  if (runResult.status !== 0)
    throw new Error("Fresh checkout failed at " + args[0]);
}
try {
  await step(
    "clone",
    "git",
    ["clone", path.join(release, "SOURCE/makam-source.bundle"), clone],
    root,
  );
  const commit = execFileSync("git", ["rev-parse", "HEAD"], {
    cwd: clone,
    encoding: "utf8",
    windowsHide: true,
  }).trim();
  if (commit !== manifest.sourceCommit)
    throw new Error("Clone commit differs from release sourceCommit");
  await step(
    "install",
    process.execPath,
    [npm, "ci", "--ignore-scripts", "--no-audit", "--no-fund", "--offline"],
    clone,
  );
  const env = {
    ...process.env,
    NPM_CLI_PATH: npm,
    MAKAM_EVIDENCE_DIR: path.join(output, "source"),
  };
  await step(
    "source-verification",
    process.execPath,
    ["scripts/verify-delta.mjs", "source"],
    clone,
    env,
  );
  await step("package", process.execPath, ["scripts/package.mjs"], clone, env);
  const rebuilt = path.join(
    output,
    "workspace/delivery/Makam-SharePoint-MultiBase-20260919",
  );
  const beforeBytes = await fs.readFile(path.join(release, "manifest.json"));
  const afterBytes = await fs.readFile(path.join(rebuilt, "manifest.json"));
  const after = JSON.parse(afterBytes);
  const changed = manifest.files
    .filter((f) => {
      const a = after.files.find((g) => g.path === f.path);
      return !a || a.sha256 !== f.sha256 || a.bytes !== f.bytes;
    })
    .map((f) => f.path);
  const extras = after.files
    .filter((a) => !manifest.files.some((f) => f.path === a.path))
    .map((a) => a.path);
  result.parity = {
    files: manifest.files.length,
    changed,
    extras,
    manifestIdentical: beforeBytes.equals(afterBytes),
    manifestSha256: createHash("sha256").update(beforeBytes).digest("hex"),
    rebuiltManifestSha256: createHash("sha256")
      .update(afterBytes)
      .digest("hex"),
    rebuiltZipSha256: createHash("sha256")
      .update(await fs.readFile(rebuilt + ".zip"))
      .digest("hex"),
  };
  if (changed.length || extras.length || !result.parity.manifestIdentical)
    throw new Error(
      "Rebuilt payload or manifest differs; see parity in result.json",
    );
  result.status = "REPRODUCED";
  console.log(
    "Fresh checkout: clone/install/tests/browser/build/package and identical manifest PASS",
  );
} catch (error) {
  result.status = "FAIL";
  throw error;
} finally {
  await fs.writeFile(
    path.join(output, "result.json"),
    JSON.stringify(result, null, 2) + "\n",
  );
}
