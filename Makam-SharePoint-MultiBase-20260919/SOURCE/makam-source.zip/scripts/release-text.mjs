import fs from "node:fs/promises";
import path from "node:path";
import { TextDecoder } from "node:util";

export function isFirstPartyText(relative) {
  return (
    relative === ".gitattributes" ||
    relative === "manifest.json" ||
    relative.startsWith("GUIDE/") ||
    /^SOURCE\/[^/]+\.(json|md)$/.test(relative) ||
    /^FRONT\/[^/]+\.(js|html)$/.test(relative) ||
    /^FRONT\/assets\/[^/]+\.(js|css)$/.test(relative) ||
    /^SERVER\/(src|shared|scripts|api)\//.test(relative) ||
    /^SERVER\/(web\.config|package(?:-lock)?\.json|\.env\.example)$/.test(
      relative,
    )
  );
}
export async function normalizeReleaseText(target) {
  const changed = [];
  async function walk(dir) {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      const file = path.join(dir, entry.name);
      if (entry.isSymbolicLink())
        throw new Error("Release links are forbidden");
      if (entry.isDirectory()) await walk(file);
      else {
        const relative = path.relative(target, file).split(path.sep).join("/");
        if (!isFirstPartyText(relative)) continue;
        const bytes = await fs.readFile(file);
        const text = new TextDecoder("utf-8", {
          fatal: true,
          ignoreBOM: true,
        }).decode(bytes);
        if (text.includes("\0"))
          throw new Error("Binary in first-party text: " + relative);
        // Vite may leave a lone CR when removing a module script from CRLF HTML.
        // Normalize both CRLF and CR after generation, before manifest hashing.
        const normalized = Buffer.from(text.replace(/\r\n?/g, "\n"), "utf8");
        if (!bytes.equals(normalized)) {
          await fs.writeFile(file, normalized);
          changed.push(relative);
        }
      }
    }
  }
  await walk(target);
  return changed.sort();
}
