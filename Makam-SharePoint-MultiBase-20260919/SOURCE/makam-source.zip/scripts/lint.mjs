import { ESLint } from "eslint";
import fs from "node:fs/promises";
import path from "node:path";
import { transform } from "esbuild";
import { root } from "./build.mjs";
process.chdir(root);
const frontendOnly = process.argv.includes("--frontend");
const eslint = new ESLint();
const results = await eslint.lintFiles(
  frontendOnly
    ? ["frontend/src/**/*.{js,jsx}"]
    : [
        "backend/src/**/*.js",
        "backend/scripts/**/*.js",
        "frontend/src/**/*.{js,jsx}",
        "scripts/*.mjs",
        "shared/*.mjs",
      ],
);
const formatter = await eslint.loadFormatter("stylish");
const output = formatter.format(results);
if (output) console.log(output);
// JSX is parsed by the actual compiler; business JS is checked by ESLint.
async function jsx(dir) {
  for (const e of await fs.readdir(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) await jsx(p);
    else if (p.endsWith(".jsx"))
      await transform(await fs.readFile(p, "utf8"), {
        loader: "jsx",
        jsx: "automatic",
        sourcefile: p,
      });
  }
}
await jsx(path.join(root, "frontend/src"));
if (results.some((r) => r.errorCount)) process.exitCode = 1;
else console.log("JS rules and JSX compilation passed");
