import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { spawnSync, execFileSync } from "node:child_process";
import { root } from "./build.mjs";

// Build the portable evidence packet after testing the FINAL source/release.
const input = path.resolve(process.argv[2] || ".verification/delta-20261007");
const release = path.resolve(
  process.argv[3] || "../../delivery/Makam-SharePoint-MultiBase-20260919",
);
const stage = path.join(root, ".build/delta-evidence");
if (await fs.stat(stage).catch(() => null))
  throw new Error(
    "Evidence stage already exists; preserve it and use a new checkout",
  );
await fs.mkdir(stage, { recursive: true });
const sourceCommit = execFileSync("git", ["rev-parse", "HEAD"], {
  cwd: root,
  encoding: "utf8",
  windowsHide: true,
}).trim();
const manifestBytes = await fs.readFile(path.join(release, "manifest.json"));
const manifest = JSON.parse(manifestBytes);
if (sourceCommit !== manifest.sourceCommit)
  throw new Error("Evidence and release source differ");
const safe = (text) =>
  text
    .split(root)
    .join("<SOURCE>")
    .split(process.env.USERPROFILE || "__unused__")
    .join("<USERPROFILE>");
const sha = (b) => createHash("sha256").update(b).digest("hex");
async function copy(from, to) {
  const info = await fs.lstat(from);
  if (info.isSymbolicLink()) throw new Error("Evidence links forbidden");
  if (info.isDirectory()) {
    await fs.mkdir(to, { recursive: true });
    for (const name of await fs.readdir(from)) {
      if (["workspace", "reference.git"].includes(name)) continue;
      await copy(path.join(from, name), path.join(to, name));
    }
  } else {
    await fs.mkdir(path.dirname(to), { recursive: true });
    const bytes = await fs.readFile(from);
    if (/\.(txt|tap|json|md|html|log|mjs|cjs)$/.test(from))
      await fs.writeFile(to, safe(bytes.toString("utf8")));
    else await fs.writeFile(to, bytes);
  }
}
const selection = [
  "source",
  "package",
  "fresh-checkout",
  "before",
  "ipc-before.tap",
  "ipc-after.tap",
  "review/input-hashes.json",
  "review/extracted",
];
for (const name of selection)
  await copy(path.join(input, name), path.join(stage, name));
await copy(
  path.join(root, ".verification/baseline-tests.txt"),
  path.join(stage, "historical/baseline-tests.txt"),
);
await copy(
  path.join(root, "docs/DELTA-REVIEW.he.md"),
  path.join(stage, "DELTA-REVIEW.he.md"),
);
await copy(
  path.join(root, "GUIDE/REPRODUCING.he.md"),
  path.join(stage, "REPRODUCING.he.md"),
);
const fresh = JSON.parse(
  await fs.readFile(path.join(stage, "fresh-checkout/result.json"), "utf8"),
);
const packageRun = JSON.parse(
  await fs.readFile(path.join(stage, "package/commands.json"), "utf8"),
);
const sourceRun = JSON.parse(
  await fs.readFile(
    path.join(stage, "fresh-checkout/source/commands.json"),
    "utf8",
  ),
);
if (
  fresh.status !== "REPRODUCED" ||
  fresh.sourceCommit !== sourceCommit ||
  packageRun.status !== "PASS" ||
  packageRun.sourceCommit !== sourceCommit ||
  sourceRun.status !== "PASS" ||
  sourceRun.sourceCommit !== sourceCommit
)
  throw new Error(
    "Final source, fresh checkout and packaged tests must PASS on the same commit",
  );
const report = {
  schemaVersion: 1,
  sourceCommit,
  platform: process.platform,
  node: process.version,
  source: "REPRODUCED from full Git bundle clone",
  package: "REPRODUCED from actual extracted ZIP",
  freshCheckout: fresh.parity,
  archiveSha256: sha(await fs.readFile(release + ".zip")),
  manifestSha256: sha(manifestBytes),
  targetEnvironment: "BLOCKED — TARGET ENVIRONMENT REQUIRED",
  original7z:
    "EVIDENCE PRESENT BUT NOT RE-RUN — archive not supplied; external inventory only",
};
await fs.writeFile(
  path.join(stage, "acceptance.json"),
  JSON.stringify(report, null, 2) + "\n",
);
const files = [];
async function inventory(dir) {
  for (const name of (await fs.readdir(dir)).sort()) {
    const p = path.join(dir, name);
    if ((await fs.stat(p)).isDirectory()) await inventory(p);
    else {
      const b = await fs.readFile(p);
      files.push({
        path: path.relative(stage, p).split(path.sep).join("/"),
        bytes: b.length,
        sha256: sha(b),
      });
    }
  }
}
await inventory(stage);
await fs.writeFile(
  path.join(stage, "evidence-manifest.json"),
  JSON.stringify({ sourceCommit, files }, null, 2) + "\n",
);
const archive = release + ".evidence.zip";
const tar = spawnSync(
  "tar.exe",
  ["-a", "-c", "-f", path.relative(stage, archive), "."],
  { cwd: stage, stdio: "inherit", windowsHide: true },
);
if (tar.status !== 0) throw new Error("Evidence ZIP failed");
await fs.writeFile(
  release + ".evidence.sha256.txt",
  sha(await fs.readFile(archive)) + "  " + path.basename(archive) + "\n",
);
await fs.writeFile(
  release + ".acceptance-local.json",
  JSON.stringify(report, null, 2) + "\n",
);
console.log("Portable evidence:", archive, "files:", files.length);
