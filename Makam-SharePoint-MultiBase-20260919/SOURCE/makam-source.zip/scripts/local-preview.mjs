// Explicit, isolated developer preview; not part of SERVER or organizational startup.
import express from "express";
import path from "node:path";
import { createRequire } from "node:module";
import { buildFrontend, buildShared, root } from "./build.mjs";
const require = createRequire(import.meta.url);
await buildShared();
const { loadConfiguration } = require("../backend/src/config.js");
const { connectDatabase } = require("../backend/src/database.js");
const { initializeForTest } = require("../backend/src/migrations.js");
const { createApp } = require("../backend/src/app.js");
const origin = "http://127.0.0.1:4322";
const config = loadConfiguration({
  env: {
    ...process.env,
    NODE_ENV: "test",
    AUTH_MODE: "local-test",
    ENABLE_LOCAL_TEST_LOGIN: "true",
    AUTO_INITIALIZE_TEST_DB: "true",
    MONGODB_URI: "mongodb://127.0.0.1:27029",
    MONGODB_DATABASE: "readiness_test_multibase_preview",
    PORT: "4322",
    PUBLIC_API_URL: origin + "/api",
    APP_PUBLIC_URL: origin,
    SHAREPOINT_ORIGIN: origin,
    BOOTSTRAP_OWNER_SAM: "m9267680",
    BOOTSTRAP_ADMIN_SAM: "c9812933",
    JOBS_ENABLED: "false",
    SMTP_HOST: "",
    LDAP_URL: "",
  },
});
const { client, db } = await connectDatabase(config);
try {
  await initializeForTest(db, config);
  await buildFrontend();
  const api = await createApp({ db, config }),
    app = express();
  app.get("/runtime-config.js", (_, res) =>
    res
      .type("application/javascript")
      .send(
        "window.MAKAM_RUNTIME_CONFIG=" +
          JSON.stringify({
            schemaVersion: 1,
            apiBaseUrl: config.apiBaseUrl,
            environment: "test",
            authMode: "local-test",
            releaseVersion: "3.1.0",
          }) +
          ";",
      ),
  );
  app.use((req, res, next) =>
    req.path.startsWith("/api/") ? api(req, res, next) : next(),
  );
  app.use(express.static(path.join(root, ".build/FRONT")));
  const server = app.listen(4322, "127.0.0.1", () =>
    console.log("Makam MultiBase isolated preview: " + origin),
  );
  const stop = () => server.close(() => client.close());
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
} catch (error) {
  await client.close();
  throw error;
}
