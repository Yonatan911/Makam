import test from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { initializeDatabase } from "./helpers/setup.mjs";

test("explicit initial owner/admin are provisioned once; later role changes are preserved", async () => {
  const dbName = "readiness_test_bootstrap_" + Date.now();
  const keys = [
    "MONGODB_URI",
    "MONGODB_DATABASE",
    "AUTH_MODE",
    "BOOTSTRAP_OWNER_SAM",
    "BOOTSTRAP_ADMIN_SAM",
    "RUNTIME_DIR",
  ];
  const saved = Object.fromEntries(keys.map((k) => [k, process.env[k]]));
  Object.assign(process.env, {
    MONGODB_URI: "mongodb://127.0.0.1:27028",
    MONGODB_DATABASE: dbName,
    AUTH_MODE: "windows-proxy",
    BOOTSTRAP_OWNER_SAM: "m9267680",
    BOOTSTRAP_ADMIN_SAM: "c9812933",
    RUNTIME_DIR: path.resolve(".runtime", dbName),
  });
  let first, second;
  try {
    first = await initializeDatabase(process.cwd());
    const users = first.db.collection("users");
    const owner = await users.findOne({ username: "m9267680" });
    const admin = await users.findOne({ username: "c9812933" });
    assert.equal(owner.role, "owner");
    assert.equal(owner.owner, true);
    assert.equal(admin.role, "admin");
    assert.equal(admin.active, true);
    assert.notEqual(admin.testAccount, true);
    assert.equal(await first.db.collection("rooms").countDocuments(), 0);
    await users.updateOne(
      { id: admin.id },
      { $set: { role: "viewer", active: false } },
    );
    process.env.BOOTSTRAP_OWNER_SAM = "replacement";
    second = await initializeDatabase(process.cwd());
    assert.equal(await users.countDocuments(), 2);
    assert.equal((await users.findOne({ id: owner.id })).role, "owner");
    assert.equal((await users.findOne({ id: admin.id })).role, "viewer");
    assert.equal((await users.findOne({ id: admin.id })).active, false);
  } finally {
    assert.ok(dbName.startsWith("readiness_test_"));
    await first?.db.dropDatabase();
    await first?.client.close();
    await second?.client.close();
    for (const key of keys) {
      if (saved[key] === undefined) delete process.env[key];
      else process.env[key] = saved[key];
    }
  }
});
