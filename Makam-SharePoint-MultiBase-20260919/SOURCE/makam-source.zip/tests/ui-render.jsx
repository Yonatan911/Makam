import { BaseMap } from "../frontend/src/features/BaseMap.jsx";
import React from "react";
import { Time24, DateTime24 } from "../frontend/src/DateTime24";
import { renderToStaticMarkup } from "react-dom/server";
import assert from "node:assert/strict";
import { sampleRooms } from "../backend/src/seed.js";
import { publicRoom, aggregate, DEFAULT_SCORING } from "../shared/model.mjs";
import {
  AssetForm,
  CheckForm,
  UserForm,
  RequestForm,
  RoomForm,
} from "../frontend/src/FormsV2";
import {
  Snapshot,
  RoomDetails,
  Reports,
  RequestsPage,
  MetricGrid,
} from "../frontend/src/ViewsV2";
import { SettingsPage, OwnerPanel } from "../frontend/src/ManagementV2";
import { FloorPlan } from "../frontend/src/FloorPlanV2";
const settings = {
  version: 1,
  appName: "מצפן",
  baseName: "בסיס בדיקה",
  freshnessDays: 7,
  scoring: DEFAULT_SCORING,
  networks: ["שחורה", "אדומה"],
  defaultSlaHours: 24,
  round: null,
  schedule: { enabled: true, day: 4, time: "17:00" },
  remindersEnabled: false,
  requestMailEnabled: false,
  reminderDay: 4,
  reminderTime: "09:30",
  recipients: [],
  baseMap: { imageId: null, markers: [] },
  defaultTheme: "dark",
  accentColor: "#77bbcc",
  density: "comfortable",
};
const user = {
    id: "owner",
    role: "owner",
    name: "בדיקה",
    roomIds: [],
    preferences: { theme: "dark" },
  },
  rooms = sampleRooms().map((r) =>
    publicRoom({ ...r, requests: [] }, user, settings),
  ),
  room = rooms[0],
  data = {
    settings,
    user,
    rooms,
    technicians: [],
    metrics: aggregate(rooms, true, settings),
  },
  done = () => {},
  open = () => {};
const render = (node) => renderToStaticMarkup(node);
const form = render(<AssetForm room={room} settings={settings} done={done} />);
assert.match(form, /שם מחשב/);
assert.match(form, /כתובת IP/);
assert.ok(!form.includes("מספר טלפון"));
assert.match(form, /הוספה לרשימה והכנת אמצעי נוסף/);
assert.match(form, /בחירת כל האמצעים האפשריים/);
assert.match(form, /אמצעים התלויים באמצעי זה/);
const tech = { ...user, role: "technician", allRooms: true };
const techDetails = render(
  <RoomDetails room={room} user={tech} settings={settings} open={open} />,
);
assert.match(techDetails, /הוספת אמצעים/);
assert.match(techDetails, /עריכת שרטוט/);
const techRoomForm = render(<RoomForm room={room} user={tech} done={done} />);
assert.ok(!techRoomForm.includes("הערכת מנהל מערכת"));
assert.match(
  render(<UserForm user={user} rooms={rooms} done={done} />),
  /כולל מרחבים שיתווספו בעתיד/,
);
const phone = render(
  <AssetForm
    room={room}
    settings={settings}
    asset={{ kind: "phone", name: "טלפון" }}
    done={done}
  />,
);
assert.match(phone, /מספר טלפון/);
assert.ok(!phone.includes("כתובת IP"));
const summary = render(
  <Snapshot
    rooms={rooms}
    settings={settings}
    title="סטטוס כשירות כללי"
    summaryOnly
  />,
);
for (const r of rooms) assert.ok(!summary.includes(r.name));
const cards = render(
  <Snapshot
    rooms={rooms}
    settings={settings}
    title="תמונת מצב חמ״לים"
    presentation
  />,
);
assert.equal(
  (cards.match(/class="snapshot-room"/g) || []).length,
  rooms.length,
);
assert.ok(cards.includes("שמירת תמונת מצב למצגת"));
assert.ok(!cards.includes("התמונה הבאה"));
for (const r of rooms) assert.ok(cards.includes(r.name));
const singleCheck = render(
  <CheckForm
    room={room}
    user={tech}
    settings={settings}
    technicians={[]}
    initialAsset={room.assets[0]}
    done={done}
  />,
);
assert.equal((singleCheck.match(/class="check-row /g) || []).length, 1);
assert.ok(!singleCheck.includes('value="full"'));
for (const node of [
  <CheckForm
    room={room}
    user={user}
    settings={settings}
    technicians={[]}
    done={done}
  />,
  <RoomDetails room={room} user={user} settings={settings} open={open} />,
  <FloorPlan room={room} editable done={done} />,
  <Reports data={data} open={open} />,
  <UserForm user={user} rooms={rooms} done={done} />,
  <RoomForm room={room} done={done} />,
  <RequestForm room={room} done={done} />,
  <RequestsPage data={data} open={open} />,
  <BaseMap data={data} done={done} open={open} />,
  <SettingsPage data={data} open={open} refresh={done} />,
  <OwnerPanel data={data} open={open} refresh={done} />,
  <MetricGrid metrics={data.metrics} />,
])
  assert.ok(render(node).length > 100);
console.log(
  "UI server rendering: all views render; conditional asset fields and aggregate snapshot privacy verified.",
);
for (const time of ["00:00", "12:00", "23:59"]) {
  const output = renderToStaticMarkup(
    <DateTime24 value={`2026-09-13T${time}`} required onChange={() => {}} />,
  );
  assert.match(output, /type="date"/);
  assert.ok(output.includes('value="2026-09-13"'));
  for (const part of time.split(":"))
    assert.ok(output.includes(`value="${part}" selected=""`));
  assert.doesNotMatch(output, /type="(?:time|datetime-local)"|\b(?:AM|PM)\b/);
}
assert.equal(
  (
    renderToStaticMarkup(<Time24 value="09:30" onChange={() => {}} />).match(
      /<option /g,
    ) || []
  ).length,
  86,
);

assert.match(
  render(
    <RoomDetails
      room={room}
      user={{ ...user, role: "command_admin" }}
      settings={settings}
      open={open}
    />,
  ),
  /תיעוד בדיקות/,
);

import { BaseSelector } from "../frontend/src/Bases";
import { CommandCard, CommandOverview } from "../frontend/src/CommandOverview";
import { summarizeBase } from "../backend/src/command-overview.js";
const commandBase = summarizeBase(
  { id: "one" },
  sampleRooms(),
  settings,
).summary;
assert.match(
  render(<CommandCard base={commandBase} onOpen={() => {}} />),
  /חריגות בדיקה/,
);
assert.match(
  render(<CommandCard base={commandBase} onOpen={() => {}} />),
  /פירוט החישוב/,
);
assert.match(render(<CommandOverview />), /dir="rtl"/);
assert.equal(
  render(
    <BaseSelector bases={[{ id: "one", name: "בסיס יחיד" }]} baseId="one" />,
  ),
  "",
);
assert.match(
  render(
    <BaseSelector
      bases={[
        { id: "one", name: "ראשון" },
        { id: "two", name: "שני" },
      ]}
      baseId="two"
    />,
  ),
  /בחירת בסיס/,
);
