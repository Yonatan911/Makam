import test from "node:test";
import assert from "node:assert/strict";
import express from "express";
import { MongoClient } from "mongodb";
import { once } from "node:events";
import { spawn } from "node:child_process";
import path from "node:path";
import { installAuth } from "../backend/legacy/auth.js";
import {
  normalizeSharePointLogin,
  proofConfiguration,
} from "../backend/legacy/sharepoint-proof.js";

test("SharePoint accepts only the configured Windows domain and validated fixed endpoints", () => {
  assert.equal(
    normalizeSharePointLogin("i:0#.w|ARMY\\m9267680", "army"),
    "m9267680",
  );
  for (const login of [
    "i:0#.f|membership|ARMY\\m9267680",
    "OTHER\\m9267680",
    "m9267680",
    "ARMY\\x\ny",
  ])
    assert.equal(normalizeSharePointLogin(login, "ARMY"), null);
  const env = {
    SP_WEB_URL: "https://sp.example/sites/ops",
    SP_PROOF_FOLDER: "/sites/ops/MakamAuthProofs",
    SHAREPOINT_ORIGIN: "https://sp.example",
    AD_DOMAIN: "ARMY",
  };
  assert.equal(proofConfiguration(env).folder, env.SP_PROOF_FOLDER);
  for (const changes of [
    { SP_WEB_URL: "http://sp.example/sites/ops" },
    { SP_PROOF_FOLDER: "/outside/Proofs" },
    { SP_PROOF_FOLDER: "/sites/ops/../Proofs" },
    { SP_WEB_URL: "https://user:pass@sp.example/sites/ops" },
    { SHAREPOINT_ORIGIN: "https://other.example" },
  ])
    assert.throws(() => proofConfiguration({ ...env, ...changes }));
});

test("SharePoint proof exchanges are browser-bound, single-use and keep authorization server-side", async (t) => {
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  await mongo.connect();
  const db = mongo.db("readiness_test_sp_library_" + Date.now());
  const saved = Object.fromEntries(
    ["SP_WEB_URL", "SP_PROOF_FOLDER", "SHAREPOINT_ORIGIN", "AD_DOMAIN"].map(
      (k) => [k, process.env[k]],
    ),
  );
  Object.assign(process.env, {
    SP_WEB_URL: "https://sp.example/sites/ops",
    SP_PROOF_FOLDER: "/sites/ops/MakamAuthProofs",
    SHAREPOINT_ORIGIN: "https://sp.example",
    AD_DOMAIN: "ARMY",
  });
  let reads = 0,
    transform = (p) => p;
  const app = express();
  app.use(express.json());
  await db.collection("users").insertOne({
    id: "owner-id",
    username: "m9267680",
    name: "Owner",
    role: "owner",
    active: true,
  });
  await installAuth(
    app,
    db,
    { authMode: "sharepoint-library" },
    {
      readProof: async (config, id) => {
        reads++;
        return transform({
          loginName: "i:0#.w|ARMY\\m9267680",
          createdAt: new Date().toISOString(),
          content: id,
        });
      },
    },
  );
  app.get("/api/protected", (req, res) => res.json({ role: req.user.role }));
  app.use((err, req, res, next) =>
    res.status(err.status || 500).json({ error: err.message }),
  );
  const server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  const base = "http://127.0.0.1:" + server.address().port;
  const post = (route, body, headers = {}) =>
    fetch(base + "/api" + route, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
    });
  const challenge = async () =>
    (await post("/auth/sharepoint/challenge", {})).json();
  const complete = (c) =>
    post("/auth/sharepoint/complete", {
      id: c.id,
      secret: c.secret,
      username: "forged.owner",
      role: "owner",
    });
  let session;
  try {
    await t.test(
      "knowing the uploaded filename does not suffice; wrong secret does not consume the valid challenge",
      async () => {
        const c = await challenge();
        assert.equal(
          (await complete({ ...c, secret: "0".repeat(64) })).status,
          401,
        );
        assert.equal(reads, 0);
        const ok = await complete(c);
        assert.equal(ok.status, 200);
        session = await ok.json();
        assert.equal(session.username, "m9267680");
        assert.equal((await complete(c)).status, 401);
        assert.equal(reads, 1);
      },
    );
    await t.test(
      "parallel exchange consumes a challenge atomically",
      async () => {
        const c = await challenge(),
          responses = await Promise.all([complete(c), complete(c)]);
        assert.deepEqual(responses.map((r) => r.status).sort(), [200, 401]);
      },
    );
    await t.test(
      "expired, mismatched and stale files cannot grant access",
      async () => {
        const c = await challenge();
        await db
          .collection("spChallenges")
          .updateOne({ _id: c.id }, { $set: { expiresAt: new Date(0) } });
        assert.equal((await complete(c)).status, 401);
        for (const changed of [
          { content: "wrong" },
          { createdAt: "2000-01-01" },
          { createdAt: "invalid" },
          { loginName: "i:0#.f|membership|ARMY\\m9267680" },
          { loginName: "OTHER\\m9267680" },
        ]) {
          transform = (p) => ({ ...p, ...changed });
          assert.equal((await complete(await challenge())).status, 401);
        }
        transform = (p) => p;
      },
    );
    await t.test("SharePoint outage fails closed", async () => {
      transform = () => {
        throw new Error("service credentials unavailable");
      };
      assert.equal((await complete(await challenge())).status, 503);
      transform = (p) => p;
    });
    await t.test(
      "unassigned/inactive users are denied and never auto-provisioned",
      async () => {
        transform = (p) => ({ ...p, loginName: "ARMY\\unassigned" });
        assert.equal((await complete(await challenge())).status, 403);
        assert.equal(await db.collection("users").countDocuments(), 1);
        transform = (p) => p;
        await db
          .collection("users")
          .updateOne({ id: "owner-id" }, { $set: { active: false } });
        assert.equal((await complete(await challenge())).status, 403);
        const headers = { Authorization: "Bearer " + session.token };
        assert.equal(
          (await fetch(base + "/api/protected", { headers })).status,
          401,
        );
        await db
          .collection("users")
          .updateOne(
            { id: "owner-id" },
            { $set: { active: true, role: "viewer" } },
          );
        assert.equal(
          (await (await fetch(base + "/api/protected", { headers })).json())
            .role,
          "viewer",
        );
      },
    );
    await t.test(
      "bearer required; cookies and browser-provided identity cannot substitute",
      async () => {
        const forged = {
          Cookie: "readiness_session=" + session.token,
          "X-Remote-User": "ARMY\\m9267680",
          "X-Readiness-Proxy": "whatever",
        };
        assert.equal(
          (await fetch(base + "/api/protected", { headers: forged })).status,
          401,
        );
        assert.equal((await fetch(base + "/api/auth/local-users")).status, 404);
        assert.equal(
          (await post("/auth/launch", { key: "a".repeat(64) })).status,
          404,
        );
        assert.equal(
          (
            await post(
              "/auth/logout",
              {},
              { Authorization: "Bearer " + session.token },
            )
          ).status,
          200,
        );
        assert.equal(
          (
            await fetch(base + "/api/protected", {
              headers: { Authorization: "Bearer " + session.token },
            })
          ).status,
          401,
        );
      },
    );
  } finally {
    server.close();
    server.closeAllConnections();
    await db.dropDatabase();
    await mongo.close();
    for (const [k, v] of Object.entries(saved))
      v === undefined ? delete process.env[k] : (process.env[k] = v);
  }
});

test("isolated legacy library regression boots without demo data, rejects foreign origins and serves API only", async () => {
  const database = "readiness_test_sp_mode_" + Date.now(),
    base = "http://127.0.0.1:4317";
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  await mongo.connect();
  const child = spawn(
    process.execPath,
    [
      process.env.MAKAM_TEST_SERVER_ROOT
        ? path.join(process.env.MAKAM_TEST_SERVER_ROOT, "src/server.js")
        : "backend/src/server.js",
    ],
    {
      windowsHide: true,
      stdio: "ignore",
      env: {
        ...process.env,
        PORT: "4317",
        HOST: "127.0.0.1",
        APP_ORIGIN: base,
        AUTO_INITIALIZE_TEST_DB: "true",
        AUTH_MODE: "sharepoint-library",
        NODE_ENV: "test",
        MONGODB_DATABASE: database,
        MONGODB_URI: "mongodb://127.0.0.1:27028",
        RUNTIME_DIR: path.resolve(".runtime", database),
        BOOTSTRAP_OWNER_SAM: "m9267680",
        BOOTSTRAP_ADMIN_SAM: "c9812933",
        AD_DOMAIN: "ARMY",
        SP_WEB_URL: "https://sp.example/sites/ops",
        SP_PROOF_FOLDER: "/sites/ops/MakamAuthProofs",
        SHAREPOINT_ORIGIN: "https://sp.example",
        SMTP_HOST: "",
        LDAP_URL: "",
      },
    },
  );
  try {
    let ready = false;
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(base + "/api/health")).ok) {
          ready = true;
          break;
        }
      } catch {}
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.equal(ready, true);
    assert.equal(
      await mongo.db(database).collection("rooms").countDocuments(),
      0,
    );
    assert.equal(
      (
        await mongo
          .db(database)
          .collection("users")
          .findOne({ username: "m9267680" })
      ).role,
      "owner",
    );
    assert.equal(
      (
        await mongo
          .db(database)
          .collection("users")
          .findOne({ username: "c9812933" })
      ).role,
      "admin",
    );
    assert.equal((await fetch(base + "/")).status, 404);
    const preflight = await fetch(base + "/api/state", {
      method: "OPTIONS",
      headers: {
        Origin: "https://sp.example",
        "Access-Control-Request-Method": "GET",
        "Access-Control-Request-Headers": "Authorization",
      },
    });
    assert.equal(preflight.status, 204);
    assert.equal(
      preflight.headers.get("access-control-allow-origin"),
      "https://sp.example",
    );
    assert.equal(
      preflight.headers.get("access-control-allow-credentials"),
      null,
    );
    assert.equal(
      (
        await fetch(base + "/api/auth/sharepoint/challenge", {
          method: "POST",
          headers: {
            Origin: "https://evil.example",
            "Content-Type": "application/json",
            "X-Readiness-Client": "dashboard",
          },
          body: "{}",
        })
      ).status,
      403,
    );
    const valid = await fetch(base + "/api/auth/sharepoint/challenge", {
      method: "POST",
      headers: {
        Origin: "https://sp.example",
        "Sec-Fetch-Site": "cross-site",
        "Content-Type": "application/json",
        "X-Readiness-Client": "dashboard",
      },
      body: "{}",
    });
    assert.equal(valid.status, 200);
    assert.equal(
      (
        await fetch(base + "/api/state", {
          headers: {
            Origin: "https://sp.example",
            "X-Remote-User": "ARMY\\m9267680",
          },
        })
      ).status,
      401,
    );
  } finally {
    child.kill();
    await once(child, "exit");
    await mongo.db(database).dropDatabase();
    await mongo.close();
  }
});
