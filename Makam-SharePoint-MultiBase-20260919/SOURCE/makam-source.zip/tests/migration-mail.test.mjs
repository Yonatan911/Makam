import test from "node:test";
import assert from "node:assert/strict";
import { MongoClient } from "mongodb";
import { randomUUID } from "node:crypto";
import { initializeDatabase } from "./helpers/setup.mjs";
import { sampleRooms } from "../backend/src/seed.js";
import { createMailJobs } from "../backend/src/mail-jobs.js";
import { israelTime } from "../shared/model.mjs";
import path from "node:path";
test("v1 migration preserves history and maps owner, identities, backups and preferences", async () => {
  const name = "readiness_test_migration_" + Date.now(),
    client = new MongoClient("mongodb://127.0.0.1:27028");
  await client.connect();
  const db = client.db(name),
    id = randomUUID(),
    legacy = sampleRooms();
  await db.collection("users").insertOne({
    _id: id,
    id,
    username: "UNIT\\Owner",
    name: "Owner",
    rank: "unused",
    role: "admin",
    owner: true,
    active: true,
    roomIds: [],
    preferences: { theme: "light", hideGreeting: true },
  });
  await db.collection("settings").insertOne({
    _id: "main",
    baseName: "Preserved",
    freshnessDays: 14,
    note: "Original note",
  });
  await db.collection("rooms").insertMany(legacy);
  process.env.MONGODB_DATABASE = name;
  process.env.MONGODB_URI = "mongodb://127.0.0.1:27028";
  process.env.AUTH_MODE = "local-test";
  process.env.RUNTIME_DIR = path.resolve(".runtime", name);
  let migrated;
  try {
    migrated = await initializeDatabase(process.cwd());
    const owner = await db.collection("users").findOne({ id });
    assert.equal(owner.username, "owner");
    assert.equal(owner.role, "owner");
    assert.equal(owner.rank, undefined);
    assert.equal(owner.preferences.hideGreeting, undefined);
    assert.equal(owner.preferences.theme, "light");
    const s = await db.collection("settings").findOne({ _id: "main" });
    assert.equal(s.baseName, "Preserved");
    assert.equal(s.freshnessDays, 14);
    assert.equal(s.schemaVersion, 2);
    for (const old of legacy) {
      const r = await db.collection("rooms").findOne({ id: old.id });
      assert.equal(r.zone, undefined);
      assert.deepEqual(r.faults, old.faults);
      assert.deepEqual(r.audit, old.audit);
      for (const a of old.assets.filter((a) => a.dependency === "redundancy")) {
        const current = r.assets.find((x) => x.id === a.id);
        assert.deepEqual(current.backupIds, [a.parentId]);
        assert.equal(current.parentId, null);
      }
    }
  } finally {
    await migrated?.client.close();
    assert.ok(name.startsWith("readiness_test_"));
    await db.dropDatabase();
    await client.close();
  }
});
test("email queue routes recipients, deduplicates events, catches weekly reminder and records partial SMTP delivery", async () => {
  const name = "readiness_test_mail_" + Date.now(),
    client = new MongoClient("mongodb://127.0.0.1:27028");
  await client.connect();
  const db = client.db(name),
    roomId = randomUUID(),
    cmdId = randomUUID();
  try {
    await db.collection("settings").insertOne({
      _id: "main",
      baseName: "test",
      schedule: { enabled: true, day: 4, time: "17:00" },
      requestMailEnabled: true,
      remindersEnabled: true,
      reminderDay: 4,
      reminderTime: "09:30",
      recipients: ["reminder@unit.example"],
    });
    await db.collection("users").insertMany([
      {
        id: randomUUID(),
        role: "owner",
        active: true,
        email: "owner@unit.example",
      },
      {
        id: randomUUID(),
        role: "admin",
        active: true,
        email: "admin@unit.example",
      },
      {
        id: cmdId,
        role: "commander",
        active: true,
        email: "commander@unit.example",
        roomIds: [roomId],
      },
      {
        id: randomUUID(),
        role: "technician",
        active: true,
        email: "tech@unit.example",
        roomIds: [roomId],
      },
      {
        id: randomUUID(),
        role: "technician",
        active: true,
        email: "unrelated@unit.example",
        roomIds: [],
      },
      {
        id: randomUUID(),
        role: "technician",
        active: true,
        email: "allrooms@unit.example",
        roomIds: [],
        allRooms: true,
      },
    ]);
    const events = [
      "request_created",
      "request_approved",
      "request_completed",
    ].map((type) => ({
      id: randomUUID(),
      type,
      at: new Date().toISOString(),
      requesterId: cmdId,
      detail: "test",
      actor: "tester",
    }));
    await db.collection("rooms").insertOne({
      id: roomId,
      name: "room",
      mailEvents: events,
      requests: [],
    });
    process.env.SMTP_HOST = "mock.invalid";
    process.env.SMTP_FROM = "service@unit.example";
    const sent = [],
      factory = (options) => {
        assert.equal(options.requireTLS, true);
        return {
          sendMail: async (message) => {
            sent.push(message);
            return { accepted: message.to, rejected: [] };
          },
        };
      };
    const jobs = createMailJobs(db, "https://internal.invalid", factory),
      now = israelTime(2026, 9, 10, 9, 31);
    await jobs.tick(now);
    await jobs.tick(now);
    assert.equal(sent.length, 4);
    assert.equal(sent[0].to.length, 2);
    assert.equal(sent[1].to.length, 5);
    assert.ok(sent[1].to.includes("allrooms@unit.example"));
    assert.ok(!sent.some((m) => m.to.includes("unrelated@unit.example")));
    assert.equal(
      await db.collection("mailOutbox").countDocuments({ status: "sent" }),
      4,
    );
    await db.collection("mailOutbox").insertOne({
      _id: "partial-test",
      id: "partial-test",
      kind: "weekly",
      status: "pending",
      subject: "test",
      text: "test",
    });
    await createMailJobs(db, "https://internal.invalid", () => ({
      sendMail: async () => ({ accepted: ["one"], rejected: ["two"] }),
    })).tick(now);
    assert.equal(
      (await db.collection("mailOutbox").findOne({ _id: "partial-test" }))
        .status,
      "partial",
    );
  } finally {
    delete process.env.SMTP_HOST;
    delete process.env.SMTP_FROM;
    assert.ok(name.startsWith("readiness_test_"));
    await db.dropDatabase();
    await client.close();
  }
});
