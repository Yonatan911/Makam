import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { transform } from "esbuild";
import vm from "node:vm";

async function browserClient(fetch, srcdoc = false) {
  const source = await readFile(
    "frontend/legacy/sharepoint-session.js",
    "utf8",
  );
  const compiled = await transform(source, {
    format: "cjs",
    define: { "import.meta.env": '{"VITE_SHAREPOINT_LIBRARY":"true"}' },
  });
  const module = { exports: {} };
  vm.runInNewContext(compiled.code, {
    module,
    sessionStorage: { getItem: () => "00000000-0000-4000-8000-000000000001" },
    URL,
    Date,
    fetch,
    window: {
      parent: { location: { origin: "https://sp.example" } },
      MAKAM_SHAREPOINT_CONFIG: {
        apiOrigin: "https://api.example",
        webUrl: "https://sp.example/sites/ops",
      },
    },
    location: {
      origin: srcdoc ? "null" : "https://sp.example",
      protocol: srcdoc ? "about:" : "https:",
    },
  });
  return module.exports;
}
test("srcdoc uses the authenticated SharePoint parent's origin", async () => {
  const client = await browserClient(() => {
    throw new Error("No request expected");
  }, true);
  assert.equal(client.apiAddress("/state"), "https://api.example/api/state");
});
test("SharePoint library client uses same-origin SP identity and keeps exchange secret out of the uploaded proof", async () => {
  const calls = [],
    id = "a".repeat(64),
    secret = "b".repeat(64),
    bearer = "c".repeat(64);
  const client = await browserClient(async (url, options) => {
    calls.push({ url, options });
    let data = {};
    if (url.endsWith("/web/currentUser"))
      data = { d: { LoginName: "i:0#.w|ARMY\\m9267680" } };
    else if (url.endsWith("/sharepoint/challenge"))
      data = {
        id,
        secret,
        webUrl: "https://sp.example/sites/ops",
        folder: "/sites/ops/MakamAuthProofs",
        fileName: `makam-${id}.txt`,
      };
    else if (url.endsWith("/contextinfo"))
      data = {
        d: { GetContextWebInformation: { FormDigestValue: "sp-digest" } },
      };
    else if (url.endsWith("/sharepoint/complete"))
      data = {
        username: "m9267680",
        token: bearer,
        expiresAt: new Date(Date.now() + 3600000).toISOString(),
      };
    return new Response(JSON.stringify(data), { status: 200 });
  });
  await Promise.all([client.apiFetch("/state"), client.apiFetch("/export")]);
  assert.equal(
    calls.filter((c) => c.url.endsWith("/sharepoint/challenge")).length,
    1,
  );
  const proof = calls.find((c) => c.url.includes("Files/Add"));
  assert.equal(proof.options.body, id);
  assert.equal(proof.options.credentials, "same-origin");
  assert.equal(proof.options.headers["X-RequestDigest"], "sp-digest");
  assert.match(proof.url, /overwrite=false/);
  assert.ok(!JSON.stringify(proof).includes(secret));
  for (const call of calls.filter(
    (c) => c.url.endsWith("/state") || c.url.endsWith("/export"),
  )) {
    assert.equal(call.options.credentials, "omit");
    assert.equal(call.options.headers.Authorization, "Bearer " + bearer);
  }
  await client.apiFetch("/base-map/image", {
    method: "POST",
    headers: { "Content-Type": "image/png" },
    body: "image-bytes",
  });
  const last = calls.at(-1);
  assert.equal(last.options.headers["Content-Type"], "image/png");
  assert.equal(last.options.body, "image-bytes");
});
test("a failed SharePoint upload never leads to backend authentication or a protected API call", async () => {
  const calls = [],
    id = "a".repeat(64);
  const client = await browserClient(async (url) => {
    calls.push(url);
    let data;
    if (url.endsWith("/web/currentUser"))
      data = { d: { LoginName: "ARMY\\m9267680" } };
    else if (url.endsWith("/sharepoint/challenge"))
      data = {
        id,
        secret: "b".repeat(64),
        webUrl: "https://sp.example/sites/ops",
        folder: "/sites/ops/MakamAuthProofs",
        fileName: `makam-${id}.txt`,
      };
    else if (url.endsWith("/contextinfo"))
      data = { d: { GetContextWebInformation: { FormDigestValue: "digest" } } };
    else
      return new Response(
        JSON.stringify({ error: { message: { value: "Access denied" } } }),
        { status: 403 },
      );
    return new Response(JSON.stringify(data));
  });
  await assert.rejects(client.apiFetch("/state"), /Access denied/);
  assert.ok(
    !calls.some(
      (url) => url.endsWith("/sharepoint/complete") || url.endsWith("/state"),
    ),
  );
});
