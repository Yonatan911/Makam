import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { MongoClient } from "mongodb";
import sharp from "sharp";
import ExcelJS from "exceljs";
import { tenantDatabase, runInBase } from "../backend/src/tenancy.js";
import { createMailJobs } from "../backend/src/mail-jobs.js";

test("multi-base: isolation, command access, grants, maps, exports, mail and concurrency", async (t) => {
  const database = "readiness_test_multibase_" + Date.now(),
    origin = "http://127.0.0.1:4321";
  const client = await new MongoClient("mongodb://127.0.0.1:27028").connect(),
    db = client.db(database);
  let output = "";
  const server = spawn(
    process.execPath,
    [
      process.env.MAKAM_TEST_SERVER_ROOT
        ? path.join(process.env.MAKAM_TEST_SERVER_ROOT, "src/server.js")
        : "backend/src/server.js",
    ],
    {
      windowsHide: true,
      env: {
        ...process.env,
        HOST: "127.0.0.1",
        PORT: "4321",
        APP_ORIGIN: origin,
        MONGODB_URI: "mongodb://127.0.0.1:27028",
        MONGODB_DATABASE: database,
        RUNTIME_DIR: ".runtime/" + database,
        AUTO_INITIALIZE_TEST_DB: "true",
        AUTH_MODE: "local-test",
        ENABLE_LOCAL_TEST_LOGIN: "true",
        BOOTSTRAP_OWNER_SAM: "m9267680",
        BOOTSTRAP_ADMIN_SAM: "c9812933",
        NODE_ENV: "test",
        SMTP_HOST: "",
        SMTP_FROM: "",
        LDAP_URL: "",
      },
      stdio: ["ignore", "pipe", "pipe"],
    },
  );
  server.stdout.on("data", (b) => (output += b));
  server.stderr.on("data", (b) => (output += b));
  async function req(
    url,
    cookie,
    baseId,
    body,
    method = body ? "POST" : "GET",
  ) {
    const response = await fetch(origin + "/api" + url, {
      method,
      headers: {
        "Content-Type": "application/json",
        "X-Readiness-Client": "dashboard",
        Origin: origin,
        ...(cookie ? { Cookie: cookie } : {}),
        ...(baseId ? { "X-Base-Id": baseId } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    return {
      status: response.status,
      cookie: response.headers.get("set-cookie")?.split(";")[0],
      value: response.headers.get("content-type")?.includes("json")
        ? await response.json()
        : Buffer.from(await response.arrayBuffer()),
    };
  }
  const ok = (result) => {
    assert.ok(
      result.status >= 200 && result.status < 300,
      JSON.stringify(result),
    );
    return result.value;
  };
  const login = async (id) =>
    (await req("/auth/local-login", null, null, { userId: id })).cookie;
  let owner,
    command,
    adminA,
    adminB,
    both,
    viewer,
    baseA,
    baseB,
    roomA,
    roomB,
    viewerId;
  const account = async (role, baseIds, suffix, extra = {}) => {
    const id = ok(
      await req("/users", owner, baseA, {
        username: "multi." + suffix,
        role,
        baseIds,
        roomIds: [],
        allRooms: true,
        active: true,
        ...extra,
      }),
    ).id;
    return { id, cookie: await login(id) };
  };
  try {
    for (let i = 0; i < 150; i++) {
      try {
        if ((await fetch(origin + "/api/health")).ok) break;
      } catch {}
      if (server.exitCode !== null) throw Error(output);
      await new Promise((r) => setTimeout(r, 100));
      if (i === 149) throw Error(output);
    }
    const local = ok(await req("/auth/local-users"));
    owner = await login(local.find((u) => u.role === "owner").id);
    command = await login(local.find((u) => u.role === "command_admin").id);
    baseA = ok(await req("/bases", owner))[0].id;
    baseB = ok(
      await req("/bases", owner, null, { name: "בסיס ב׳ — מבודד" }),
    ).id;
    adminA = (await account("admin", [baseA], "admin_a")).cookie;
    adminB = (await account("admin", [baseB], "admin_b")).cookie;
    both = (await account("admin", [baseA, baseB], "both")).cookie;
    ({ cookie: viewer, id: viewerId } = await account(
      "viewer",
      [baseA],
      "viewer",
    ));
    roomA = ok(
      await req("/rooms", adminA, baseA, { name: "חמל א בלבד", type: "חמ״ל" }),
    ).id;
    roomB = ok(
      await req("/rooms", adminB, baseB, { name: "חדן ב בלבד", type: "חד״ן" }),
    ).id;

    await t.test(
      "command overview: global-only access, scoped detail and export, persisted trends",
      async () => {
        for (const cookie of [owner, command]) {
          const overview = ok(await req("/command-overview", cookie));
          assert.deepEqual(
            new Set(overview.bases.map((b) => b.id)),
            new Set([baseA, baseB]),
          );
          assert.ok(overview.generatedAt);
          assert.equal(overview.totals.baseCount, 2);
          assert.ok(!JSON.stringify(overview).includes("assigneeId"));
          const detail = ok(
            await req("/command-overview/" + baseB, cookie, baseA),
          );
          assert.deepEqual(
            detail.rooms.map((r) => r.id),
            [roomB],
          );
          assert.equal(detail.summary.checks.never, 1);
          assert.equal(detail.summary.score, null);
          const wb = new ExcelJS.Workbook();
          await wb.xlsx.load(
            ok(await req("/command-overview/export?theme=dark", cookie)),
          );
          assert.equal(wb.worksheets[0].rowCount, 3);
        }
        for (const cookie of [adminA, adminB, both, viewer]) {
          for (const route of [
            "/command-overview",
            "/command-overview/" + baseB,
            "/command-overview/export",
          ])
            assert.equal((await req(route, cookie, baseA)).status, 403);
        }
        assert.equal(
          (await req("/command-overview/" + randomUUID(), owner)).status,
          404,
        );
        const hour = Math.floor(Date.now() / 3600000);
        await db
          .collection("commandSnapshots")
          .insertOne({
            baseId: baseA,
            bucket: hour - 1,
            at: new Date(Date.now() - 3600000).toISOString(),
            score: 50,
          });
        const overview = ok(await req("/command-overview", owner));
        const first = overview.bases.find((b) => b.id === baseA);
        assert.equal(
          first.trend.delta,
          first.score == null ? null : first.score - 50,
        );
        assert.equal(
          await db
            .collection("commandSnapshots")
            .countDocuments({ baseId: baseB, bucket: hour }),
          1,
        );
      },
    );

    await t.test(
      "base listing and explicit header enforcement; two-base admin",
      async () => {
        assert.deepEqual(
          ok(await req("/bases", adminA)).map((b) => b.id),
          [baseA],
        );
        assert.equal(ok(await req("/bases", both)).length, 2);
        assert.equal((await req("/state", adminA, baseB)).status, 403);
        assert.equal((await req("/state", adminA, randomUUID())).status, 403);
        assert.equal((await req("/state", owner, "../settings")).status, 400);
        for (const [cookie, base, allowed, denied] of [
          [adminA, baseA, roomA, roomB],
          [adminB, baseB, roomB, roomA],
          [both, baseB, roomB, roomA],
        ]) {
          const state = ok(await req("/state", cookie, base));
          assert.equal(state.base.id, base);
          assert.ok(state.rooms.some((r) => r.id === allowed));
          assert.ok(!state.rooms.some((r) => r.id === denied));
        }
      },
    );
    await t.test(
      "guessed room IDs, all mutations, settings and admin APIs cannot cross bases",
      async () => {
        for (const url of [
          "/state",
          "/export",
          "/audit",
          "/notifications",
          "/owner/diagnostics",
        ])
          assert.equal((await req(url, adminA, baseB)).status, 403, url);
        assert.equal(
          (
            await req(
              "/rooms/" + roomB,
              adminA,
              baseA,
              { version: 1, name: "אסור" },
              "PATCH",
            )
          ).status,
          404,
        );
        assert.equal(
          (
            await req(
              "/rooms/" + roomB,
              adminA,
              baseB,
              { version: 1, name: "אסור" },
              "PATCH",
            )
          ).status,
          403,
        );
        for (const url of [
          "/rounds",
          "/base-map/markers",
          "/settings",
          "/rooms/" + roomB + "/assets/batch",
        ])
          assert.equal(
            (
              await req(
                url,
                adminA,
                baseB,
                {},
                url.endsWith("markers") ? "PUT" : "POST",
              )
            ).status,
            403,
            url,
          );
        assert.equal(
          (await req("/bases", adminA, null, { name: "אסור" })).status,
          403,
        );
        assert.equal((await req("/global-audit", adminA)).status, 403);
        assert.equal((await req("/access-catalog", viewer)).status, 403);
        const overview = ok(await req("/base-overview", adminA));
        assert.equal(overview.length, 1);
        assert.equal(typeof overview[0].metrics.overall, "number");
      },
    );
    await t.test(
      "new bases automatically available to owner and command admin only",
      async () => {
        const baseC = ok(
          await req("/bases", command, null, { name: "בסיס חדש ג׳" }),
        ).id;
        assert.equal(ok(await req("/bases", owner)).length, 3);
        assert.equal(ok(await req("/bases", command)).length, 3);
        assert.equal(ok(await req("/bases", both)).length, 2);
        assert.equal(ok(await req("/state", command, baseC)).rooms.length, 0);
        assert.equal(
          ok(await req("/state", command, baseC)).settings.baseMap.imageId,
          null,
        );
        assert.equal((await req("/state", viewer, baseC)).status, 403);
        ok(
          await req("/rooms", command, baseC, {
            name: "ניהול פיקודי",
            type: "חמ״ל",
          }),
        );
      },
    );
    await t.test(
      "owner and command administrators appoint base administrators; local managers cannot escalate",
      async () => {
        for (const role of ["admin", "command_admin", "owner"]) {
          const grant = {
            username: "attack." + role,
            role,
            baseIds: [baseA],
            roomIds: [],
            allRooms: true,
            active: true,
          };
          assert.equal((await req("/users", adminA, baseA, grant)).status, 403);
          assert.equal(
            (await req("/users", command, baseA, grant)).status,
            role === "admin" ? 201 : 403,
          );
        }
        const grant = {
          username: "cross.base",
          role: "technician",
          baseIds: [baseB],
          roomIds: [],
          allRooms: true,
          active: true,
        };
        assert.equal((await req("/users", adminA, baseA, grant)).status, 403);
        const shared = await account("technician", [baseA, baseB], "shared");
        const row = ok(await req("/users", adminA)).find(
          (u) => u.id === shared.id,
        );
        assert.equal(row.canManage, true);
        assert.deepEqual(row.baseIds, [baseA]);
        assert.equal(
          (
            await req(
              "/users/" + shared.id,
              adminA,
              baseA,
              { ...grant, baseIds: [baseA], version: row.version },
              "PATCH",
            )
          ).status,
          404,
        );
        assert.equal(
          (
            await req(
              "/users/" + shared.id,
              adminA,
              baseA,
              { version: row.version },
              "DELETE",
            )
          ).status,
          200,
        );
        assert.ok(
          !ok(await req("/users", adminA)).some(
            (u) => u.username === "multi.admin_b",
          ),
        );
        const foreignRooms = {
          ...grant,
          baseIds: [baseA],
          allRooms: false,
          roomIds: [roomB],
        };
        assert.equal(
          (await req("/users", owner, baseA, foreignRooms)).status,
          400,
        );
      },
    );
    await t.test(
      "new rooms and revoked base access are reflected without new login",
      async () => {
        const added = ok(
          await req("/rooms", adminA, baseA, {
            name: "נוסף אחרי מתן הרשאה",
            type: "חמ״ל",
          }),
        ).id;
        assert.ok(
          ok(await req("/state", viewer, baseA)).rooms.some(
            (r) => r.id === added,
          ),
        );
        const target = await db.collection("users").findOne({ id: viewerId });
        const payload = {
          username: target.username,
          name: target.name,
          role: target.role,
          baseIds: [baseB],
          roomIds: [],
          allRooms: true,
          active: true,
          version: target.version,
        };
        ok(await req("/users/" + viewerId, owner, baseA, payload, "PATCH"));
        assert.equal((await req("/state", viewer, baseA)).status, 403);
        assert.ok(
          ok(await req("/state", viewer, baseB)).rooms.some(
            (r) => r.id === roomB,
          ),
        );
        assert.equal(
          (await req("/users/" + viewerId, owner, baseA, payload, "PATCH"))
            .status,
          409,
        );
      },
    );
    await t.test(
      "aerial images and markers are independently scoped",
      async () => {
        const bytes = await sharp({
          create: { width: 20, height: 20, channels: 3, background: "#008899" },
        })
          .png()
          .toBuffer();
        const upload = async (cookie, baseId) => {
          const response = await fetch(origin + "/api/base-map/image", {
            method: "POST",
            headers: {
              Cookie: cookie,
              "X-Base-Id": baseId,
              "X-Readiness-Client": "dashboard",
              Origin: origin,
              "Content-Type": "image/png",
            },
            body: bytes,
          });
          assert.equal(response.status, 201);
          return (await response.json()).id;
        };
        const imageA = await upload(adminA, baseA),
          imageB = await upload(adminB, baseB);
        assert.equal(
          (await req("/base-map/image/" + imageA, adminA, baseA)).status,
          200,
        );
        assert.equal(
          (await req("/base-map/image/" + imageB, adminA, baseA)).status,
          404,
        );
        assert.equal(
          (await req("/base-map/image/" + imageB, adminA, baseB)).status,
          403,
        );
        assert.equal(
          ok(await req("/state", adminB, baseB)).settings.baseMap.imageId,
          imageB,
        );
        const state = ok(await req("/state", adminA, baseA));
        assert.equal(
          (
            await req(
              "/base-map/markers",
              adminA,
              baseA,
              {
                version: state.settings.version,
                markers: [{ roomId: roomB, x: 20, y: 30 }],
              },
              "PUT",
            )
          ).status,
          400,
        );
      },
    );
    await t.test(
      "reports, logs and concurrent requests stay within each namespace",
      async () => {
        const results = await Promise.all(
          Array.from({ length: 24 }, (_, i) =>
            req("/state", both, i % 2 ? baseA : baseB),
          ),
        );
        results.forEach((result, i) => {
          const state = ok(result);
          assert.equal(state.base.id, i % 2 ? baseA : baseB);
          assert.ok(!state.rooms.some((r) => r.id === (i % 2 ? roomB : roomA)));
        });
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(ok(await req("/export", adminB, baseB)));
        const text = JSON.stringify(workbook.model);
        assert.ok(!text.includes("חמל א בלבד"));
        assert.ok(text.includes("חדן ב בלבד"));
        assert.ok(
          !JSON.stringify(ok(await req("/audit", adminA, baseA))).includes(
            "חדן ב בלבד",
          ),
        );
        const scoped = tenantDatabase(db);
        assert.throws(() => scoped.collection("rooms").find(), /context/);
      },
    );
    await t.test(
      "base mail queues resolve only their own administrators and technicians",
      async () => {
        const base = await db.collection("bases").findOne({ id: baseB }),
          scoped = tenantDatabase(db);
        await db
          .collection("users")
          .updateMany(
            { role: "admin" },
            { $set: { email: "admin@example.test" } },
          );
        await db
          .collection("users")
          .updateOne(
            { username: "multi.admin_a" },
            { $set: { email: "foreign@example.test" } },
          );
        await db
          .collection(base.prefix + "settings")
          .updateOne({ _id: "main" }, { $set: { requestMailEnabled: true } });
        await db.collection(base.prefix + "mailOutbox").insertOne({
          _id: "mail-b",
          id: "mail-b",
          status: "pending",
          kind: "request",
          eventType: "request_created",
          roomId: roomB,
          subject: "בסיס ב",
          text: "בדיקה",
        });
        const sent = [],
          oldHost = process.env.SMTP_HOST,
          oldFrom = process.env.SMTP_FROM;
        process.env.SMTP_HOST = "smtp.test";
        process.env.SMTP_FROM = "service@example.test";
        try {
          await runInBase(base, () =>
            createMailJobs(scoped, origin, () => ({
              sendMail: async (message) => {
                sent.push(message);
                return { rejected: [] };
              },
            })).tick(),
          );
          assert.equal(sent.length, 1);
          assert.ok(!sent[0].to.includes("foreign@example.test"));
          assert.ok(sent[0].to.includes("admin@example.test"));
        } finally {
          if (oldHost === undefined) delete process.env.SMTP_HOST;
          else process.env.SMTP_HOST = oldHost;
          if (oldFrom === undefined) delete process.env.SMTP_FROM;
          else process.env.SMTP_FROM = oldFrom;
        }
      },
    );
    await t.test(
      "blind local addition, independent roles, scoped removal and no cross-base metadata",
      async () => {
        const foreign = await account("admin", [baseB], "foreign_existing");
        const before = await db.collection("users").findOne({ id: foreign.id });
        const grant = {
          username: before.username,
          name: "שם מקומי א",
          email: "local-a@example.test",
          role: "viewer",
          baseIds: [baseA],
          roomIds: [roomA],
          allRooms: false,
          active: true,
        };
        const added = await req("/users", adminA, baseA, grant);
        assert.equal(added.status, 201);
        assert.deepEqual(Object.keys(added.value), ["id"]);
        assert.equal(added.value.id, foreign.id);
        assert.equal(
          await db
            .collection("users")
            .countDocuments({ username: before.username }),
          1,
        );
        const row = ok(await req("/users", adminA, baseA)).find(
          (u) => u.id === foreign.id,
        );
        assert.equal(row.role, "viewer");
        assert.deepEqual(row.baseIds, [baseA]);
        assert.deepEqual(row.roomIds, [roomA]);
        assert.equal(row.canManage, true);
        assert.equal(row.grants, undefined);
        assert.equal(row.baseGrants, undefined);
        assert.ok(!JSON.stringify(row).includes(baseB));
        const a = ok(await req("/state", foreign.cookie, baseA)),
          b = ok(await req("/state", foreign.cookie, baseB));
        assert.equal(a.user.role, "viewer");
        assert.equal(a.user.name, grant.name);
        assert.equal(a.rooms.length, 1);
        assert.equal(b.user.role, "admin");
        assert.equal(b.user.name, before.name);
        assert.equal((await req("/users", foreign.cookie, baseA)).status, 403);
        assert.equal(
          (
            await req("/rooms", foreign.cookie, baseA, {
              name: "אסור",
              type: "חמ״ל",
            })
          ).status,
          403,
        );
        ok(
          await req("/rooms", foreign.cookie, baseB, {
            name: "מורשה בבסיס ב",
            type: "חמ״ל",
          }),
        );
        const central = ok(await req("/users", command)).find(
          (u) => u.id === foreign.id,
        );
        assert.equal(
          central.grants.find((g) => g.baseId === baseA).role,
          "viewer",
        );
        assert.equal(
          central.grants.find((g) => g.baseId === baseB).role,
          "admin",
        );
        assert.equal(
          (
            await req(
              "/users/" + foreign.id,
              adminA,
              baseA,
              { ...grant, role: "admin", version: row.version },
              "PATCH",
            )
          ).status,
          403,
        );
        ok(
          await req(
            "/users/" + foreign.id,
            adminA,
            baseA,
            { ...grant, role: "technician", version: row.version },
            "PATCH",
          ),
        );
        assert.equal(
          ok(await req("/state", foreign.cookie, baseA)).user.role,
          "technician",
        );
        const next = ok(await req("/users", adminA, baseA)).find(
          (u) => u.id === foreign.id,
        );
        assert.equal(
          ok(await req("/users", adminB, baseB)).find(
            (u) => u.id === foreign.id,
          ).version,
          0,
        );
        ok(
          await req(
            "/users/" + foreign.id,
            adminA,
            baseA,
            { version: next.version },
            "DELETE",
          ),
        );
        assert.equal((await req("/state", foreign.cookie, baseA)).status, 403);
        assert.equal((await req("/state", foreign.cookie, baseB)).status, 200);
        const after = await db.collection("users").findOne({ id: foreign.id });
        assert.equal(after.name, before.name);
        assert.equal(after.email, before.email);
        assert.equal(after.active, true);
      },
    );
    await t.test(
      "central per-base role editor and local hidden memberships work with recipient queries",
      async () => {
        const payload = {
          username: "central.mixed",
          name: "מעורב",
          email: "mixed@example.test",
          role: "viewer",
          active: true,
          baseIds: [baseA, baseB],
          roomIds: [],
          allRooms: false,
          grants: [
            {
              baseId: baseA,
              role: "viewer",
              roomIds: [roomA],
              allRooms: false,
              active: true,
            },
            {
              baseId: baseB,
              role: "admin",
              roomIds: [],
              allRooms: true,
              active: true,
            },
          ],
        };
        const mixed = ok(await req("/users", command, null, payload));
        const cookie = await login(mixed.id);
        assert.equal(ok(await req("/state", cookie, baseB)).user.role, "admin");
        assert.equal((await req("/users", cookie, baseA)).status, 403);
        assert.ok(
          ok(await req("/users", cookie, baseB)).some((u) => u.id === mixed.id),
        );
        const technicians = ok(await req("/state", adminB, baseB)).technicians;
        assert.equal(technicians.find((u) => u.id === mixed.id).role, "admin");
        const base = await db.collection("bases").findOne({ id: baseB });
        const recipient = await runInBase(base, () =>
          tenantDatabase(db)
            .collection("users")
            .findOne({ id: mixed.id, role: "admin", active: true }),
        );
        assert.equal(recipient.email, payload.email);
        // A manager responsible for two bases still receives only the selected base's grants.
        const listA = ok(await req("/users", both, baseA));
        assert.ok(
          listA.every((u) => u.baseIds.length === 1 && u.baseIds[0] === baseA),
        );
        assert.ok(!JSON.stringify(listA).includes(baseB));
        const legacy = await account(
          "technician",
          [baseA, baseB],
          "legacy_split",
          { allRooms: false, roomIds: [roomA, roomB] },
        );
        const centralLegacy = ok(await req("/users", command)).find(
          (u) => u.id === legacy.id,
        );
        assert.deepEqual(
          centralLegacy.grants.find((g) => g.baseId === baseA).roomIds,
          [roomA],
        );
        assert.deepEqual(
          centralLegacy.grants.find((g) => g.baseId === baseB).roomIds,
          [roomB],
        );
        const localLegacy = ok(await req("/users", adminA, baseA)).find(
          (u) => u.id === legacy.id,
        );
        assert.deepEqual(localLegacy.roomIds, [roomA]);
        ok(
          await req(
            "/users/" + legacy.id,
            adminA,
            baseA,
            { version: localLegacy.version },
            "DELETE",
          ),
        );
        assert.equal((await req("/state", legacy.cookie, baseA)).status, 403);
        assert.equal(
          ok(await req("/state", legacy.cookie, baseB)).rooms[0].id,
          roomB,
        );
      },
    );
    await t.test(
      "base deletion is global-only, immediately blocks data and preserves restorable history",
      async () => {
        const current = ok(await req("/bases", owner)).find(
          (b) => b.id === baseB,
        );
        assert.equal(
          (
            await req(
              "/bases/" + baseB,
              adminB,
              baseB,
              { version: current.version, confirmation: current.name },
              "DELETE",
            )
          ).status,
          403,
        );
        assert.equal((await req("/bases/archived", adminB)).status, 403);
        assert.equal(
          (
            await req(
              "/bases/" + baseB,
              command,
              null,
              { version: current.version, confirmation: "wrong" },
              "DELETE",
            )
          ).status,
          400,
        );
        ok(
          await req(
            "/bases/" + baseB,
            command,
            null,
            { version: current.version, confirmation: current.name },
            "DELETE",
          ),
        );
        assert.ok(!ok(await req("/bases", adminB)).some((b) => b.id === baseB));
        assert.equal((await req("/state", adminB, baseB)).status, 404);
        assert.equal((await req("/state", owner, baseB)).status, 404);
        assert.equal(
          (
            await req("/bases/" + baseB + "/restore", adminA, baseA, {
              version: current.version + 1,
            })
          ).status,
          403,
        );
        const archived = ok(await req("/bases/archived", command)).find(
          (b) => b.id === baseB,
        );
        ok(
          await req("/bases/" + baseB + "/restore", command, null, {
            version: archived.version,
          }),
        );
        assert.ok(
          ok(await req("/state", adminB, baseB)).rooms.some(
            (r) => r.id === roomB,
          ),
        );
        const remaining = ok(await req("/bases", owner));
        for (const base of remaining)
          ok(
            await req(
              "/bases/" + base.id,
              owner,
              null,
              { version: base.version, confirmation: base.name },
              "DELETE",
            ),
          );
        assert.deepEqual(ok(await req("/bases", owner)), []);
        assert.equal(ok(await req("/state", owner)).base, null);
        const fresh = ok(
          await req("/bases", command, null, { name: "בסיס לאחר מחיקה" }),
        );
        assert.equal(ok(await req("/state", owner, fresh.id)).rooms.length, 0);
      },
    );
  } finally {
    if (server.exitCode === null) {
      const exit = once(server, "exit");
      server.kill();
      await exit;
    }
    // Dedicated generated test database only; application data is never touched.
    await db.dropDatabase();
    await client.close();
  }
});
