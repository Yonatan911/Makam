import test from "node:test";
import { build } from "esbuild";
import { spawnSync } from "node:child_process";
import assert from "node:assert/strict";
import path from "node:path";
test("React views render with v2 contracts and sensitive report boundaries", async () => {
  const outfile = path.resolve(".runtime/ui-render.cjs");
  await build({
    entryPoints: ["tests/ui-render.jsx"],
    bundle: true,
    platform: "node",
    format: "cjs",
    packages: "external",
    loader: { ".png": "file" },
    define: { "import.meta.env": "{}" },
    outfile,
  });
  const result = spawnSync(process.execPath, [outfile], {
    encoding: "utf8",
    windowsHide: true,
  });
  assert.equal(result.status, 0, result.stdout + result.stderr);
});
