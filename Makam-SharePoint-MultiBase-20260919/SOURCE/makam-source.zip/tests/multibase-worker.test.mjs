import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { MongoClient } from "mongodb";
import { createMultiBaseMailJobs } from "../backend/src/multibase-jobs.js";
test("multi-base durable worker: isolated queues, concurrent claims, distinct message IDs and deleted-base exclusion", async () => {
  const client = await new MongoClient("mongodb://127.0.0.1:27028").connect();
  const db = client.db("readiness_test_workers_" + Date.now()),
    saved = {
      SMTP_HOST: process.env.SMTP_HOST,
      SMTP_FROM: process.env.SMTP_FROM,
    };
  process.env.SMTP_HOST = "smtp.internal.test";
  process.env.SMTP_FROM = "system@internal.test";
  try {
    const bases = [
      { _id: "original", id: randomUUID(), prefix: "" },
      {
        _id: "second",
        id: randomUUID(),
        prefix: "base_" + randomUUID().replaceAll("-", "") + "_",
      },
      {
        _id: "deleted",
        id: randomUUID(),
        prefix: "base_" + randomUUID().replaceAll("-", "") + "_",
        deletedAt: new Date().toISOString(),
      },
    ];
    await db.collection("bases").insertMany(bases);
    for (const base of bases) {
      await db
        .collection(base.prefix + "settings")
        .insertOne({
          _id: "main",
          remindersEnabled: true,
          requestMailEnabled: false,
          recipients: [base.id + "@internal.test"],
          reminderDay: -1,
        });
      await db
        .collection(base.prefix + "mailOutbox")
        .insertOne({
          _id: "same-job",
          id: "same-job",
          kind: "weekly",
          status: "pending",
          subject: "test",
          text: "test",
        });
    }
    const sent = [],
      transport = () => ({
        sendMail: async (message) => {
          sent.push(message);
          return { accepted: message.to, rejected: [] };
        },
        close() {},
      });
    const first = createMultiBaseMailJobs(
        db,
        "https://sp.internal/sites/ops",
        transport,
      ),
      second = createMultiBaseMailJobs(
        db,
        "https://sp.internal/sites/ops",
        transport,
      );
    await Promise.all([first.tick(), second.tick()]);
    assert.equal(sent.length, 2);
    assert.equal(new Set(sent.map((m) => m.messageId)).size, 2);
    for (const base of bases.slice(0, 2)) {
      assert.deepEqual(sent.find((m) => m.messageId.includes(base.id)).to, [
        base.id + "@internal.test",
      ]);
      assert.equal(
        (await db.collection(base.prefix + "mailOutbox").findOne()).status,
        "sent",
      );
    }
    assert.equal(
      (await db.collection(bases[2].prefix + "mailOutbox").findOne()).status,
      "pending",
    );
    first.stop();
    second.stop();
    await first.tick();
    assert.equal(sent.length, 2);
  } finally {
    for (const [key, value] of Object.entries(saved)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
    await db.dropDatabase();
    await client.close();
  }
});
