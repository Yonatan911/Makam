import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, writeFile, readFile, rm } from "node:fs/promises";
import path from "node:path";
import { tmpdir } from "node:os";
import { normalizeReleaseText } from "../scripts/release-text.mjs";

test("release normalization fixes loader/embed parity before hashing, preserving vendor and binary bytes", async () => {
  const dir = await mkdtemp(path.join(tmpdir(), "makam-eol-"));
  const vendor = Buffer.from([0, 255, 13, 10, 0, 128]);
  try {
    for (const name of ["FRONT", "SERVER/node_modules/vendor", "SOURCE"])
      await mkdir(path.join(dir, name), { recursive: true });
    await writeFile(
      path.join(dir, "FRONT/loader.js"),
      "// שלום\r\nconsole.log('ready');\r\n",
    );
    await writeFile(path.join(dir, "FRONT/embed.html"), "<div></div>\r\n");
    await writeFile(
      path.join(dir, "FRONT/index.html"),
      '<div id="root"></div>\r  </body>\r\n',
    );
    await writeFile(
      path.join(dir, "SERVER/node_modules/vendor/index.js"),
      vendor,
    );
    await writeFile(path.join(dir, "FRONT/logo.png"), vendor);
    await writeFile(path.join(dir, "SOURCE/makam-source.bundle"), vendor);
    assert.deepEqual(await normalizeReleaseText(dir), [
      "FRONT/embed.html",
      "FRONT/index.html",
      "FRONT/loader.js",
    ]);
    assert.equal(
      await readFile(path.join(dir, "FRONT/embed.html"), "utf8"),
      "<div></div>\n",
    );
    assert.equal(
      await readFile(path.join(dir, "FRONT/index.html"), "utf8"),
      '<div id="root"></div>\n  </body>\n',
    );
    for (const name of [
      "SERVER/node_modules/vendor/index.js",
      "FRONT/logo.png",
      "SOURCE/makam-source.bundle",
    ])
      assert.deepEqual(await readFile(path.join(dir, name)), vendor);
    assert.deepEqual(await normalizeReleaseText(dir), []);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
