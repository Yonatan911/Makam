import test from "node:test";
import { request as httpRequest } from "node:http";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdir, readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { once } from "node:events";
import { MongoClient } from "mongodb";
import ExcelJS from "exceljs";
import sharp from "sharp";
import { createMailJobs } from "../backend/src/mail-jobs.js";
const pause = (ms) => new Promise((r) => setTimeout(r, ms));
test("v2 full API: roles, batch checks, requests, maps, archive, scheduling and reports", async (t) => {
  const database = "readiness_test_v2_" + Date.now(),
    runtime = path.resolve(".runtime", database),
    base = "http://127.0.0.1:4311";
  await mkdir(runtime, { recursive: true });
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  await mongo.connect();
  const db = mongo.db(database);
  let server,
    logs = "";
  const start = async () => {
    server = spawn(
      process.execPath,
      [
        process.env.MAKAM_TEST_SERVER_ROOT
          ? path.join(process.env.MAKAM_TEST_SERVER_ROOT, "src/server.js")
          : "backend/src/server.js",
      ],
      {
        windowsHide: true,
        env: {
          ...process.env,
          PORT: "4311",
          APP_ORIGIN: base,
          MONGODB_DATABASE: database,
          RUNTIME_DIR: runtime,
          AUTO_INITIALIZE_TEST_DB: "true",
          AUTH_MODE: "local-test",
          ENABLE_LOCAL_TEST_LOGIN: "true",
          NODE_ENV: "test",
          SMTP_HOST: "",
          SMTP_FROM: "",
          LDAP_URL: "",
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );
    server.stdout.on("data", (d) => (logs += d));
    server.stderr.on("data", (d) => (logs += d));
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(base + "/api/health")).ok) return;
      } catch {}
      if (server.exitCode !== null) throw new Error(logs);
      await pause(100);
    }
    throw new Error(logs);
  };
  const stop = async () => {
    if (server?.exitCode === null) {
      const exit = once(server, "exit");
      server.kill();
      await exit;
    }
  };
  const req = async (url, body, cookie, method) => {
    if (body && url.startsWith("/users")) {
      const first = await db.collection("bases").findOne({ _id: "original" });
      const target =
        url === "/users"
          ? null
          : await db.collection("users").findOne({ id: url.split("/").pop() });
      body = {
        ...body,
        ...(method === "DELETE" ? {} : { baseIds: body.baseIds || [first.id] }),
        ...(target ? { version: target.version } : {}),
      };
    }
    const r = await fetch(base + "/api" + url, {
      method: method || (body ? "POST" : "GET"),
      headers: {
        "Content-Type": "application/json",
        "X-Readiness-Client": "dashboard",
        Origin: base,
        ...(cookie ? { Cookie: cookie } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    return {
      status: r.status,
      value: r.headers.get("content-type")?.includes("json")
        ? await r.json()
        : Buffer.from(await r.arrayBuffer()),
      cookie: r.headers.get("set-cookie")?.split(";")[0],
      headers: r.headers,
    };
  };
  const ok = (r) => {
    assert.ok(r.status >= 200 && r.status < 300, JSON.stringify(r.value));
    return r.value;
  };
  let c = {},
    u = {},
    r1,
    r2,
    a1,
    a2,
    ups,
    requestId;
  const state = async (role = "owner") =>
    ok(await req("/state", null, c[role]));
  const room = async (id = r1, role = "owner") =>
    (await state(role)).rooms.find((r) => r.id === id);
  try {
    await start();
    await t.test(
      "local test identities and authentication boundaries",
      async () => {
        assert.equal((await req("/state")).status, 401);
        assert.equal(
          (await req("/auth/login", { username: "admin", password: "unused" }))
            .status,
          403,
        );
        const people = ok(await req("/auth/local-users"));
        for (const role of [
          "owner",
          "admin",
          "technician",
          "commander",
          "viewer",
        ]) {
          u[role] = people.find((x) => x.role === role);
          const login = await req("/auth/local-login", { userId: u[role].id });
          ok(login);
          c[role] = login.cookie;
          assert.match(login.headers.get("set-cookie"), /HttpOnly/);
        }
        assert.equal(
          (
            await fetch(base + "/api/preferences", {
              method: "PATCH",
              headers: { "Content-Type": "application/json", Cookie: c.owner },
              body: '{"theme":"dark"}',
            })
          ).status,
          403,
        );
        assert.equal(
          await new Promise((resolve, reject) => {
            const r = httpRequest(
              base + "/api/state",
              { headers: { Host: "evil.test", Cookie: c.owner } },
              (res) => {
                res.resume();
                resolve(res.statusCode);
              },
            );
            r.on("error", reject);
            r.end();
          }),
          403,
        );
        assert.equal((await req("/users", null, c.viewer)).status, 403);
      },
    );
    await t.test(
      "manual owner-only administrator provisioning and immutable owner",
      async () => {
        const user = {
          username: "another.admin",
          name: "בדיקת ניהול",
          email: "",
          role: "admin",
          roomIds: [],
          active: true,
        };
        assert.equal((await req("/users", user, c.admin)).status, 403);
        const admin = ok(await req("/users", user, c.owner));
        assert.equal(
          (await req("/users/" + admin.id, {}, c.admin, "DELETE")).status,
          403,
        );
        ok(await req("/users/" + admin.id, {}, c.owner, "DELETE"));
        assert.equal(
          (await req("/users/" + u.owner.id, {}, c.owner, "DELETE")).status,
          403,
        );
        const own = await db.collection("users").findOne({ id: u.owner.id });
        assert.equal(
          (
            await req(
              "/users/" + own.id,
              {
                username: own.username,
                name: own.name,
                email: "",
                role: "viewer",
                roomIds: [],
                active: false,
              },
              c.owner,
              "PATCH",
            )
          ).status,
          403,
        );
        assert.equal(
          (await req("/owner/settings", {}, c.admin, "PATCH")).status,
          403,
        );
      },
    );
    await t.test(
      "rooms distinguish command centers and conference rooms without zone",
      async () => {
        r1 = ok(
          await req(
            "/rooms",
            { name: "מרחב בדיקות API", type: "חמ״ל", zone: "must disappear" },
            c.admin,
          ),
        ).id;
        r2 = ok(
          await req(
            "/rooms",
            { name: "חד״ן בדיקות API", type: "חד״ן" },
            c.owner,
          ),
        ).id;
        assert.equal((await room()).zone, undefined);
        for (const role of ["technician", "commander", "viewer"])
          await db
            .collection("users")
            .updateOne({ id: u[role].id }, { $set: { roomIds: [r1] } });
        assert.equal(
          (await req("/rooms", { name: "אסור", type: "חמ״ל" }, c.commander))
            .status,
          403,
        );
      },
    );
    const asset = (name, extra = {}) => ({
      name,
      kind: "computer",
      category: "computing",
      critical: false,
      network: "שחורה",
      ip: "192.168.1.7",
      phone: "should clear",
      serial: "",
      parentId: null,
      dependency: "none",
      backupIds: [],
      x: 50,
      y: 50,
      rotation: 0,
      ...extra,
    });
    const add = async (value) => {
      const r = await room();
      return ok(
        await req(
          "/rooms/" + r1 + "/assets",
          { version: r.version, asset: value },
          c.admin,
        ),
      ).id;
    };
    await t.test(
      "type-sensitive inventory validates IP and clears irrelevant phone fields",
      async () => {
        a1 = await add(asset("PC-ONE"));
        a2 = await add(asset("PC-TWO"));
        const r = await room();
        assert.equal(r.assets[0].phone, "");
        assert.equal(
          (
            await req(
              "/rooms/" + r1 + "/assets",
              { version: r.version, asset: asset("BAD", { ip: "not-an-ip" }) },
              c.admin,
            )
          ).status,
          400,
        );
        assert.equal(r.metrics.categories.power.score, null);
        assert.equal(r.metrics.overall.score, 100);
      },
    );
    const check = async (
      outcomes,
      scope = "selected",
      role = "technician",
      version,
    ) => {
      const r = await room(),
        st = await state();
      return req(
        `/rooms/${r1}/check`,
        {
          version: version ?? r.version,
          scope,
          roundId: st.settings.round?.id || null,
          outcomes,
        },
        c[role],
      );
    };
    const outcome = (id, action, extra = {}) => ({
      assetId: id,
      action,
      note:
        action === "fault"
          ? "תקלת בדיקה"
          : action === "close"
            ? "הציוד תוקן והוחזר לפעילות"
            : "",
      ...extra,
    });
    await t.test(
      "bulk reporting is atomic and partial checks do not renew full validity",
      async () => {
        const v = (await room()).version;
        ok(
          await check([outcome(a1, "fault"), outcome(a2, "fault")], "selected"),
        );
        let r = await room();
        assert.equal(r.faults.length, 2);
        assert.equal(r.lastCheck, null);
        assert.ok(r.lastPartialCheck);
        assert.equal(
          (
            await check([
              outcome(a1, "close", { verified: true }),
              outcome(a2, "close", { note: "x", verified: true }),
            ])
          ).status,
          400,
        );
        r = await room();
        assert.equal(r.faults.filter((f) => f.status === "closed").length, 0);
        assert.equal(
          (await check([outcome(a1, "keep")], "selected", "technician", v))
            .status,
          409,
        );
      },
    );
    await t.test(
      "manager can immediately close any active fault without verification",
      async () => {
        let r = await room(),
          f = r.faults.find((f) => f.assetId === a1);
        ok(
          await req(
            `/rooms/${r1}/faults/${f.id}`,
            {
              version: r.version,
              status: "closed",
              note: "החלטת מנהל לסגור מיידית",
              severity: "high",
              assigneeId: "",
              slaAt: new Date(Date.now() + 86400000).toISOString(),
            },
            c.admin,
            "PATCH",
          ),
        );
        r = await room();
        assert.equal(
          r.faults.find((x) => x.id === f.id).closureMode,
          "direct_admin",
        );
        ok(await check([outcome(a2, "close")], "selected", "admin"));
        assert.equal((await room()).metrics.overall.score, 100);
      },
    );
    await t.test(
      "technician can verify and close during one check; verification is required",
      async () => {
        ok(await check([outcome(a1, "fault"), outcome(a2, "fault")]));
        assert.equal((await check([outcome(a1, "close")])).status, 400);
        ok(
          await check(
            [
              outcome(a1, "close", { verified: true }),
              outcome(a2, "close", { verified: true }),
            ],
            "full",
          ),
        );
        const r = await room();
        assert.ok(r.lastCheck.at);
        assert.equal(r.faults.at(-1).closureMode, "verified_during_check");
        assert.equal(r.freshness, "fresh");
      },
    );
    await t.test(
      "viewer sees own inventory but no checker identity/history; commander sees checker",
      async () => {
        const st = await state("viewer");
        assert.equal(st.rooms.length, 1);
        const r = st.rooms[0];
        assert.equal(r.assets.length, 2);
        assert.equal(r.lastCheck.actor, undefined);
        assert.equal(r.assets[0].checkedBy, undefined);
        assert.equal(r.audit, undefined);
        assert.equal(r.archivedAssets, undefined);
        assert.ok(!JSON.stringify(r).includes(u.technician.name));
        assert.equal(
          (await room(r1, "commander")).lastCheck.actor,
          u.technician.name,
        );
        assert.equal(
          (await req(`/rooms/${r2}/requests`, {}, c.commander)).status,
          404,
        );
        assert.equal((await req("/export", null, c.commander)).status, 403);
      },
    );
    await t.test(
      "commander requests date/reason/scope, admin approves, room immediately requires check",
      async () => {
        let r = await room();
        const body = {
          version: r.version,
          requestedFor: new Date(Date.now() + 86400000).toISOString(),
          reason: "הכנה לתרגיל",
          details: "בדיקת קישוריות למחשב",
          scope: "selected",
          assetIds: [a1],
        };
        assert.equal(
          (await req(`/rooms/${r1}/requests`, body, c.viewer)).status,
          403,
        );
        requestId = ok(
          await req(`/rooms/${r1}/requests`, body, c.commander),
        ).id;
        r = await room();
        assert.equal(r.requests[0].status, "pending");
        assert.equal(
          (
            await req(
              `/rooms/${r1}/requests/${requestId}`,
              {
                version: r.version,
                decision: "approved",
                note: "מאושר לתרגיל",
              },
              c.commander,
              "PATCH",
            )
          ).status,
          403,
        );
        ok(
          await req(
            `/rooms/${r1}/requests/${requestId}`,
            { version: r.version, decision: "approved", note: "מאושר לתרגיל" },
            c.admin,
            "PATCH",
          ),
        );
        assert.equal((await room()).freshness, "expired");
        assert.equal((await room(r1, "technician")).requests.length, 1);
        assert.equal((await room(r1, "viewer")).requests.length, 0);
      },
    );
    await t.test(
      "only covering check completes approved targeted request and queues each email once",
      async () => {
        ok(await check([outcome(a2, "pass")]));
        assert.equal((await room()).requests[0].status, "approved");
        ok(await check([outcome(a1, "pass")]));
        assert.equal((await room()).requests[0].status, "completed");
        const jobs = createMailJobs(db, base);
        await jobs.tick();
        await jobs.tick();
        const msgs = await db
          .collection("mailOutbox")
          .find({ roomId: r1 })
          .toArray();
        assert.equal(msgs.length, 3);
        assert.ok(msgs.every((m) => m.status === "waiting_configuration"));
        assert.ok(msgs.every((m) => !m.sentAt));
      },
    );
    await t.test(
      "scheduled checks produce visible overdue state and owner weights are editable",
      async () => {
        let st = await state();
        ok(
          await req(
            "/settings",
            {
              version: st.settings.version,
              baseName: st.settings.baseName,
              freshnessDays: 7,
              note: "הערכת מנהל מערכת",
              schedule: { enabled: true, day: 4, time: "09:30" },
              remindersEnabled: false,
              reminderDay: 4,
              reminderTime: "09:30",
              requestMailEnabled: false,
              recipients: [],
            },
            c.admin,
            "PATCH",
          ),
        );
        st = await state();
        ok(
          await req(
            "/owner/settings",
            {
              version: st.settings.version,
              appName: "מצפן בדיקות",
              accentColor: "#77bbcc",
              defaultTheme: "dark",
              density: "compact",
              networks: ["רשת בדיקה"],
              defaultSlaHours: 48,
              scoring: {
                critical: 4,
                regular: 1,
                low: 0.2,
                medium: 0.5,
                high: 1,
              },
            },
            c.owner,
            "PATCH",
          ),
        );
        assert.equal((await state()).settings.appName, "מצפן בדיקות");
        assert.equal(
          (await req("/settings", { ...st.settings }, c.admin, "PATCH")).status,
          400,
        );
      },
    );
    await t.test(
      "base image is authenticated, re-encoded and marker visibility is filtered on server",
      async () => {
        const image = await sharp({
          create: {
            width: 100,
            height: 60,
            channels: 3,
            background: "#6699aa",
          },
        })
          .png()
          .toBuffer();
        const upload = async (bytes, type = "image/png", role = "admin") =>
          fetch(base + "/api/base-map/image", {
            method: "POST",
            headers: {
              Cookie: c[role],
              Origin: base,
              "X-Readiness-Client": "dashboard",
              "Content-Type": type,
            },
            body: bytes,
          });
        assert.equal((await upload(image, "image/png", "viewer")).status, 403);
        assert.equal((await upload(Buffer.from("<svg/>"))).status, 400);
        const res = await upload(image);
        assert.equal(res.status, 201);
        const imageId = (await res.json()).id;
        assert.equal(
          (await fetch(base + "/api/base-map/image/" + imageId)).status,
          401,
        );
        const pic = await fetch(base + "/api/base-map/image/" + imageId, {
          headers: { Cookie: c.viewer },
        });
        assert.equal(pic.status, 200);
        assert.equal(
          (await sharp(Buffer.from(await pic.arrayBuffer())).metadata()).format,
          "webp",
        );
        const st = await state();
        ok(
          await req(
            "/base-map/markers",
            {
              version: st.settings.version,
              markers: [
                { roomId: r1, x: 25, y: 50 },
                { roomId: r2, x: 75, y: 50 },
              ],
            },
            c.admin,
            "PUT",
          ),
        );
        assert.equal(
          (await state("technician")).settings.baseMap.markers.length,
          2,
        );
        const viewer = (await state("viewer")).settings.baseMap.markers;
        assert.equal(viewer.length, 1);
        assert.equal(viewer[0].roomId, r1);
      },
    );
    await t.test(
      "floor plan persists polygon, angled furniture, walls and rotations",
      async () => {
        const r = await room();
        const plan = {
          width: 1000,
          height: 700,
          shape: "polygon",
          points: [
            { x: 5, y: 5 },
            { x: 95, y: 5 },
            { x: 65, y: 95 },
            { x: 5, y: 65 },
          ],
          walls: [
            { id: randomUUID(), x1: 5, y1: 50, x2: 40, y2: 30, kind: "door" },
          ],
          tables: [
            {
              id: randomUUID(),
              x: 35,
              y: 35,
              w: 20,
              h: 10,
              rotation: 35,
              shape: "ellipse",
              label: "שולחן דיונים",
            },
          ],
        };
        ok(
          await req(
            `/rooms/${r1}/plan`,
            {
              version: r.version,
              plan,
              positions: [{ id: a1, x: 15, y: 20, rotation: 45 }],
            },
            c.admin,
            "PUT",
          ),
        );
        assert.equal((await room()).plan.tables[0].rotation, 35);
        assert.equal((await room()).assets[0].rotation, 45);
      },
    );
    await t.test(
      "optional UPS backup does not cascade computer failure; hard UPS dependency rejected",
      async () => {
        ups = await add(
          asset("UPS", {
            kind: "ups",
            category: "power",
            critical: true,
            ip: "",
          }),
        );
        let r = await room();
        ok(
          await req(
            `/rooms/${r1}/assets/${a1}`,
            {
              version: r.version,
              asset: asset("PC-ONE", { backupIds: [ups] }),
            },
            c.admin,
            "PATCH",
          ),
        );
        r = await room();
        assert.equal(
          (
            await req(
              `/rooms/${r1}/assets/${a1}`,
              {
                version: r.version,
                asset: asset("PC-ONE", { parentId: ups, dependency: "hard" }),
              },
              c.admin,
              "PATCH",
            )
          ).status,
          400,
        );
        ok(await check([outcome(ups, "fault")]));
        r = await room();
        assert.equal(r.metrics.categories.computing.score, 100);
        assert.equal(r.metrics.categories.power.score, 0);
        assert.equal(r.metrics.warning, true);
      },
    );
    await t.test(
      "archive removes operational impact but preserves all fault and retirement history",
      async () => {
        let r = await room();
        const n = r.faults.length;
        ok(
          await req(
            `/rooms/${r1}/assets/${ups}`,
            { version: r.version, reason: "הציוד אינו בשימוש" },
            c.admin,
            "DELETE",
          ),
        );
        r = await room();
        assert.equal(r.assets.length, 2);
        assert.equal(r.archivedAssets.length, 1);
        assert.equal(r.faults.length, n);
        assert.equal(r.faults.at(-1).closureMode, "asset_retired");
        assert.equal(r.metrics.categories.power.score, null);
        assert.equal(r.metrics.overall.score, 100);
        assert.equal(r.assets[0].backupIds.length, 0);
        assert.equal((await room(r1, "viewer")).archivedAssets, undefined);
        ok(
          await req(
            `/rooms/${r1}/assets/${ups}/restore`,
            { version: r.version },
            c.admin,
          ),
        );
        assert.equal((await room()).assets.length, 3);
      },
    );
    await t.test(
      "Excel contains nine RTL sheets, archives and complete request lifecycle",
      async () => {
        const x = await req("/export", null, c.owner);
        ok(x);
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(x.value);
        assert.equal(workbook.worksheets.length, 9);
        assert.ok(workbook.worksheets.every((s) => s.views[0].rightToLeft));
        assert.ok(workbook.getWorksheet("בקשות בדיקה").rowCount > 1);
        assert.ok(workbook.getWorksheet("מעברי סטטוס").rowCount > 1);
      },
    );
    await t.test(
      "preferences persist, static assets local, no secrets or private files exposed",
      async () => {
        ok(await req("/preferences", { theme: "light" }, c.viewer, "PATCH"));
        assert.equal((await state("viewer")).user.preferences.theme, "light");
        const res = await fetch(base + "/.env");
        const text = await res.text();
        assert.ok(!text.includes("TRUSTED_PROXY_SECRET="));
        assert.equal((await fetch(base + "/")).status, 404);
        const page = await readFile("frontend/index.html", "utf8");
        assert.match(page, /dir="rtl"/);
        assert.ok(!/https?:\/\//.test(page));
        const diagnostic = ok(await req("/owner/diagnostics", null, c.owner));
        assert.equal(diagnostic.testMode, true);
        assert.ok(!JSON.stringify(diagnostic).includes("PASSWORD"));
      },
    );
    await t.test(
      "new defaults, dynamic all-room grants, technician inventory, multi-parent reporting and closure",
      async () => {
        assert.equal(
          (await db.collection("settings").findOne({ _id: "main" }))
            .lightDefaultApplied,
          true,
        );
        const extraId = ok(
          await req(
            "/users",
            {
              username: "new_light_user",
              role: "technician",
              roomIds: [],
              active: true,
            },
            c.owner,
          ),
        ).id;
        assert.deepEqual(
          (await db.collection("users").findOne({ id: extraId })).preferences,
          {},
        );
        assert.equal(
          (
            await req(
              `/rooms/${r2}/assets/bulk`,
              { version: (await room(r2)).version, assets: [asset("denied")] },
              c.technician,
            )
          ).status,
          404,
        );
        assert.equal(
          (
            await req(
              `/rooms/${r2}`,
              { version: (await room(r2)).version, name: "denied" },
              c.technician,
              "PATCH",
            )
          ).status,
          404,
        );
        const tech = await db
          .collection("users")
          .findOne({ id: u.technician.id });
        const grant = {
          username: tech.username,
          name: tech.name,
          role: tech.role,
          roomIds: tech.roomIds,
          allRooms: true,
          active: true,
        };
        ok(await req(`/users/${tech.id}`, grant, c.owner, "PATCH"));
        // Created after the grant: this must work without rewriting the user's roomIds.
        const rid = ok(
          await req(
            "/rooms",
            { name: "מרחב בדיקת רגרסיה", type: "חד״ן" },
            c.admin,
          ),
        ).id;
        let r = await room(rid, "technician");
        assert.ok(r);
        assert.ok(
          !(
            await db.collection("users").findOne({ id: tech.id })
          ).roomIds.includes(rid),
        );
        assert.ok(
          (await state("commander")).technicians.some(
            (t) => t.id === tech.id && t.allRooms,
          ),
        );
        assert.equal(
          (
            await req(
              `/rooms/${rid}/assets/bulk`,
              { version: r.version, assets: [asset("denied")] },
              c.viewer,
            )
          ).status,
          404,
        );
        const ids = ok(
          await req(
            `/rooms/${rid}/assets/bulk`,
            {
              version: r.version,
              assets: [
                asset("MATRIX-A", { kind: "matrix", category: "display" }),
                asset("MATRIX-B", { kind: "matrix", category: "display" }),
                asset("SCREEN", { kind: "screen", category: "display" }),
              ],
            },
            c.technician,
          ),
        ).ids;
        r = await room(rid);
        assert.equal(r.assets.length, 3);
        ok(
          await req(
            `/rooms/${rid}/assets/${ids[2]}`,
            {
              version: r.version,
              asset: { ...r.assets[2], parentIds: ids.slice(0, 2) },
            },
            c.technician,
            "PATCH",
          ),
        );
        r = await room(rid);
        const before = r.version;
        const bad = await req(
          `/rooms/${rid}/assets/bulk`,
          {
            version: before,
            assets: [
              asset("GOOD"),
              asset("BAD", { parentIds: [randomUUID()] }),
            ],
          },
          c.technician,
        );
        assert.equal(bad.status, 400);
        assert.equal((await room(rid)).version, before);
        assert.equal((await room(rid)).assets.length, 3);
        assert.equal(
          (
            await req(
              `/rooms/${rid}/assets/${ids[0]}`,
              {
                version: before,
                asset: { ...r.assets[0], parentIds: [ids[2]] },
              },
              c.technician,
              "PATCH",
            )
          ).status,
          400,
        );
        const runCheck = async (outcomes, scope = "full") =>
          req(
            `/rooms/${rid}/check`,
            {
              version: (await room(rid)).version,
              roundId: (await state()).settings.round?.id || null,
              scope,
              outcomes,
            },
            c.technician,
          );
        // Reporting the parent while leaving a healthy child on pass used to reject the whole save.
        ok(
          await runCheck([
            outcome(ids[0], "fault", {
              assigneeId: tech.id,
              assigneeText: "צוות תחזוקה חיצוני",
            }),
            outcome(ids[1], "pass"),
            outcome(ids[2], "pass"),
          ]),
        );
        r = await room(rid);
        assert.equal(r.faults.length, 1);
        assert.equal(r.faults[0].assigneeText, "צוות תחזוקה חיצוני");
        assert.equal(r.assets[2].status, "healthy");
        assert.equal(r.metrics.assets[2].loss, 1);
        assert.deepEqual(r.assets[2].lastCheckResult.affectedByIds, [ids[0]]);
        assert.ok(r.lastCheck);
        // Repairing a separate child fault never clears the inherited upstream impact.
        ok(await runCheck([outcome(ids[2], "fault")], "selected"));
        assert.equal(
          (await runCheck([outcome(ids[2], "close")], "selected")).status,
          400,
        );
        ok(
          await runCheck(
            [outcome(ids[2], "close", { verified: true })],
            "selected",
          ),
        );
        r = await room(rid);
        assert.equal(r.metrics.assets[2].loss, 1);
        assert.equal(
          r.faults.find((f) => f.assetId === ids[2]).status,
          "closed",
        );
        ok(
          await runCheck(
            [outcome(ids[0], "close", { verified: true })],
            "selected",
          ),
        );
        assert.equal((await room(rid)).metrics.overall.score, 100);
        // A keep result can also refer to an upstream fault first reported in this batch,
        // even when the dependent component appears before the parent in the request.
        ok(
          await runCheck(
            [outcome(ids[2], "keep"), outcome(ids[1], "fault")],
            "selected",
          ),
        );
        assert.equal(
          (await room(rid)).metrics.assets.find((a) => a.id === ids[2]).loss,
          1,
        );
        ok(
          await runCheck(
            [outcome(ids[1], "close", { verified: true })],
            "selected",
          ),
        );
        r = await room(rid);
        ok(
          await req(
            `/rooms/${rid}`,
            { version: r.version, name: "מרחב מעודכן", type: "חמ״ל" },
            c.technician,
            "PATCH",
          ),
        );
        r = await room(rid);
        assert.equal(
          (
            await req(
              `/rooms/${rid}`,
              { version: r.version, note: "הערכה לא מורשית" },
              c.technician,
              "PATCH",
            )
          ).status,
          403,
        );
        ok(
          await req(
            `/rooms/${rid}/plan`,
            {
              version: r.version,
              plan: r.plan,
              positions: r.assets.map(({ id, x, y, rotation }) => ({
                id,
                x,
                y,
                rotation,
              })),
            },
            c.technician,
            "PUT",
          ),
        );
        r = await room(rid);
        ok(
          await req(
            `/rooms/${rid}/assets/${ids[0]}`,
            { version: r.version, reason: "יצא משימוש" },
            c.technician,
            "DELETE",
          ),
        );
        r = await room(rid);
        assert.deepEqual(r.assets.find((a) => a.id === ids[2]).parentIds, [
          ids[1],
        ]);
        assert.ok(r.archivedAssets.some((a) => a.id === ids[0]));
        assert.ok(r.faults.some((f) => f.assetId === ids[0]));
        ok(
          await req(
            `/users/${tech.id}`,
            { ...grant, allRooms: false },
            c.owner,
            "PATCH",
          ),
        );
        assert.equal(
          (await state("technician")).rooms.some((r) => r.id === rid),
          false,
        );
      },
    );
    await t.test(
      "representatives and commanders can access multiple explicitly assigned rooms only",
      async () => {
        for (const role of ["viewer", "commander"]) {
          const person = await db
            .collection("users")
            .findOne({ id: u[role].id });
          const input = {
            username: person.username,
            name: person.name,
            role,
            roomIds: [r1, r2],
            allRooms: false,
            active: true,
          };
          ok(await req(`/users/${person.id}`, input, c.owner, "PATCH"));
          const view = await state(role);
          assert.deepEqual(
            new Set(view.rooms.map((r) => r.id)),
            new Set([r1, r2]),
          );
          assert.equal(
            (
              await req(
                `/rooms/${r2}/assets`,
                { version: (await room(r2)).version, asset: asset("DENIED") },
                c[role],
              )
            ).status,
            404,
          );
          assert.equal(
            (
              await req(
                `/users/${person.id}`,
                { ...input, roomIds: [] },
                c.owner,
                "PATCH",
              )
            ).status,
            400,
          );
          ok(
            await req(
              `/users/${person.id}`,
              { ...input, roomIds: person.roomIds },
              c.owner,
              "PATCH",
            ),
          );
        }
      },
    );
    await t.test(
      "parent editor applies dependent selections atomically without overwriting other sources",
      async () => {
        const rid = ok(
          await req(
            "/rooms",
            { name: "בדיקת רכיב מזין", type: "חד״ן" },
            c.admin,
          ),
        ).id;
        let r = await room(rid);
        const ids = ok(
          await req(
            `/rooms/${rid}/assets/bulk`,
            {
              version: r.version,
              assets: [
                asset("MATRIX", { kind: "matrix" }),
                asset("SOURCE", { kind: "matrix" }),
                asset("DISPLAY", { kind: "screen" }),
              ],
            },
            c.admin,
          ),
        ).ids;
        const edit = async (index, dependentIds) => {
          const current = await room(rid);
          return req(
            `/rooms/${rid}/assets/${ids[index]}`,
            {
              version: current.version,
              asset: { ...current.assets[index], dependentIds },
            },
            c.admin,
            "PATCH",
          );
        };
        ok(await edit(1, [ids[2]]));
        ok(await edit(0, [ids[2]]));
        r = await room(rid);
        assert.deepEqual(
          new Set(r.assets[2].parentIds),
          new Set([ids[0], ids[1]]),
        );
        assert.equal(r.assets[0].dependentIds, undefined);
        const v = r.version;
        assert.equal((await edit(2, [ids[0]])).status, 400);
        assert.equal((await room(rid)).version, v);
        assert.equal((await edit(0, [a1])).status, 400);
        ok(await edit(0, []));
        assert.deepEqual((await room(rid)).assets[2].parentIds, [ids[1]]);
      },
    );
    await t.test(
      "database survives restart with same roles, settings, plan and archive history",
      async () => {
        await stop();
        await start();
        const st = await state();
        assert.equal(st.settings.appName, "מצפן בדיקות");
        assert.equal((await room()).plan.tables[0].rotation, 35);
        assert.equal((await state("viewer")).user.preferences.theme, "light");
      },
    );
  } finally {
    await stop();
    assert.ok(database.startsWith("readiness_test_"));
    await db.dropDatabase();
    await mongo.close();
  }
});
