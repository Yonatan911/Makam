import test from "node:test";
import { sampleRooms } from "../backend/src/seed.js";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { MongoClient } from "mongodb";
import { escapeLdap, syncAdProfile } from "../backend/src/ad-profile.js";
test("LDAP escapes filter characters and never creates or grants a role", async () => {
  assert.equal(escapeLdap("a*)(x=1)\\"), "a\\2a\\29\\28x=1\\29\\5c");
  const user = { id: "x", name: "Manual", role: "viewer" };
  assert.equal(await syncAdProfile(user, null), user);
  assert.equal(await syncAdProfile(null, null), null);
});
test("trusted Windows proxy accepts manually provisioned identities only", async () => {
  const database = "readiness_test_proxy_" + Date.now(),
    runtime = path.resolve(".runtime", database),
    base = "http://127.0.0.1:4312",
    secret = "a".repeat(64);
  await mkdir(runtime, { recursive: true });
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  await mongo.connect();
  const db = mongo.db(database);
  const server = spawn(
    process.execPath,
    [
      process.env.MAKAM_TEST_SERVER_ROOT
        ? path.join(process.env.MAKAM_TEST_SERVER_ROOT, "src/server.js")
        : "backend/src/server.js",
    ],
    {
      env: {
        ...process.env,
        PORT: "4312",
        APP_ORIGIN: base,
        MONGODB_DATABASE: database,
        RUNTIME_DIR: runtime,
        AUTO_INITIALIZE_TEST_DB: "true",
        AUTH_MODE: "windows-proxy",
        TRUSTED_PROXY_SECRET: secret,
        AD_DOMAIN: "DOMAIN",
        BOOTSTRAP_OWNER_SAM: "org.owner",
        LDAP_URL: "",
        SMTP_HOST: "",
        NODE_ENV: "test",
      },
      stdio: "ignore",
      windowsHide: true,
    },
  );
  try {
    let ready = false;
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(base + "/api/health")).ok) {
          ready = true;
          break;
        }
      } catch {}
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.equal(ready, true);
    async function get(identity, provided = secret) {
      const response = await fetch(base + "/api/state", {
        headers: { "X-Remote-User": identity, "X-Readiness-Proxy": provided },
      });
      return { status: response.status, body: await response.json() };
    }
    assert.equal((await get("DOMAIN\\unassigned")).status, 401);
    const id = randomUUID(),
      room = sampleRooms()[0];
    await db.collection("rooms").insertOne(room);
    await db.collection("users").insertOne({
      _id: id,
      id,
      username: "operator",
      name: "נציג מורשה",
      rank: "",
      role: "viewer",
      baseIds: [(await db.collection("bases").findOne({ _id: "original" })).id],
      roomIds: [room.id],
      active: true,
      preferences: { theme: "light" },
    });
    assert.equal((await get("DOMAIN\\operator", "wrong-secret")).status, 401);
    assert.equal((await get("DOMAIN\\operator", "")).status, 401);
    const valid = await get("DOMAIN\\operator");
    assert.equal(valid.status, 200);
    assert.equal(valid.body.user.role, "viewer");
    assert.equal(valid.body.rooms.length, 1);
    assert.ok(Array.isArray(valid.body.rooms[0].assets));
    assert.equal(valid.body.rooms[0].lastCheck?.actor, undefined);
    assert.equal((await get("OTHER\\operator")).status, 401);
    assert.equal((await get("operator")).status, 401);
    assert.equal((await fetch(base + "/api/auth/local-users")).status, 404);
    assert.equal(
      (
        await fetch(base + "/api/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Readiness-Client": "dashboard",
            Origin: base,
          },
          body: JSON.stringify({ username: "admin", password: "any" }),
        })
      ).status,
      403,
    );
    assert.equal(
      await db
        .collection("users")
        .countDocuments({ username: "domain\\unassigned" }),
      0,
    );
  } finally {
    server.kill();
    if (!database.startsWith("readiness_test_"))
      throw new Error("Unsafe test database name");
    await db.dropDatabase();
    await mongo.close();
  }
});
