import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { MongoClient } from "mongodb";
import {
  preflight,
  applyMigration,
  restoreMigration,
} from "../backend/src/migrations.js";
import { verifySchema } from "../backend/src/database.js";
import { sampleRooms } from "../backend/src/seed.js";

test("latest multi-base migration preserves every namespace, grants, maps, history and media; interruption/resume/restore", async () => {
  const mongo = await new MongoClient("mongodb://127.0.0.1:27028").connect();
  const db = mongo.db("readiness_test_multibase_migration_" + Date.now());
  try {
    const a = { _id: "original", id: randomUUID(), prefix: "", version: 4 };
    const b = {
      _id: "second",
      id: randomUUID(),
      prefix: "base_" + randomUUID().replaceAll("-", "") + "_",
      version: 7,
    };
    await db.collection("bases").insertMany([a, b]);
    const rooms = sampleRooms();
    for (const base of [a, b]) {
      await db
        .collection(base.prefix + "rooms")
        .insertMany(rooms.map((r) => ({ ...r, name: base.id + r.name })));
      await db
        .collection(base.prefix + "settings")
        .insertOne({
          _id: "main",
          schemaVersion: 2,
          version: 10,
          appName: "מכ״ם",
          makamBrandApplied: true,
          lightDefaultApplied: true,
          defaultTheme: "dark",
          freshnessDays: base === a ? 7 : 14,
          baseMap: {
            imageId: base.id,
            markers: [{ roomId: rooms[0].id, x: 20, y: 30 }],
          },
        });
      await db
        .collection(base.prefix + "media")
        .insertOne({ _id: base.id, bytes: Buffer.from("local-image") });
      await db
        .collection(base.prefix + "mailOutbox")
        .insertOne({
          _id: base.id,
          status: "unknown",
          attemptedAt: new Date(),
        });
    }
    await db
      .collection("commandSnapshots")
      .insertOne({ _id: "previous", baseId: b.id, score: 78 });
    await db.collection("users").insertMany([
      {
        _id: "owner",
        id: "owner",
        username: "ARMY\\m9267680",
        role: "owner",
        active: true,
        baseIds: [],
        roomIds: [],
        preferences: { theme: "dark" },
      },
      {
        _id: "command",
        id: "command",
        username: "command",
        role: "command_admin",
        active: true,
        baseIds: [],
        roomIds: [],
      },
      {
        _id: "mixed",
        id: "mixed",
        username: "mixed",
        role: "viewer",
        active: true,
        baseIds: [a.id, b.id],
        roomIds: [],
        baseGrants: {
          [a.id]: {
            role: "admin",
            active: true,
            allRooms: true,
            roomIds: [],
            version: 9,
          },
          [b.id]: {
            role: "viewer",
            active: true,
            allRooms: false,
            roomIds: [rooms[0].id],
            version: 8,
          },
        },
      },
    ]);
    const names = [
      "users",
      "bases",
      "rooms",
      "settings",
      b.prefix + "rooms",
      b.prefix + "settings",
      "media",
      b.prefix + "media",
      "mailOutbox",
      b.prefix + "mailOutbox",
      "commandSnapshots",
    ];
    const snapshot = async () =>
      Object.fromEntries(
        await Promise.all(
          names.map(async (n) => [
            n,
            await db.collection(n).find().sort({ _id: 1 }).toArray(),
          ]),
        ),
      );
    const before = await snapshot();
    const plan = await preflight(db);
    assert.deepEqual(await snapshot(), before);
    assert.ok(plan.collections.includes(b.prefix + "rooms"));
    let interrupted = false;
    await assert.rejects(
      applyMigration(db, plan, {
        onCheckpoint: (collection) => {
          if (!interrupted && collection === b.prefix + "settings") {
            interrupted = true;
            throw Error("interrupted second base");
          }
        },
      }),
      /interrupted/,
    );
    await assert.rejects(verifySchema(db), /in progress/);
    const { runId } = await db
      .collection("migrationRuns")
      .findOne({ _id: "active" });
    await applyMigration(db, null, { resumeId: runId });
    await verifySchema(db);
    const after = await snapshot();
    assert.deepEqual(after.bases, before.bases);
    assert.deepEqual(after.rooms, before.rooms);
    assert.deepEqual(after[b.prefix + "rooms"], before[b.prefix + "rooms"]);
    assert.deepEqual(
      after.users.find((u) => u.id === "mixed").baseGrants,
      before.users.find((u) => u.id === "mixed").baseGrants,
    );
    for (const n of names.filter((n) =>
      /media|mailOutbox|commandSnapshots/.test(n),
    ))
      assert.deepEqual(after[n], before[n]);
    for (const base of [a, b]) {
      assert.deepEqual(
        after[base.prefix + "settings"][0].baseMap,
        before[base.prefix + "settings"][0].baseMap,
      );
      assert.equal(
        after[base.prefix + "settings"][0].iisnodeMultibaseSchema,
        1,
      );
    }
    assert.equal((await preflight(db)).changed, false);
    await restoreMigration(db, runId);
    assert.deepEqual(await snapshot(), before);
    // A malformed record in a secondary base must fail before any writes, including indexes/journal.
    await db
      .collection(b.prefix + "rooms")
      .updateOne({ id: rooms[0].id }, { $set: { "plan.tables": "malformed" } });
    const malformed = await snapshot();
    const journals = await db.collection("migrationRuns").find().toArray();
    await assert.rejects(preflight(db), /Malformed/);
    assert.deepEqual(await snapshot(), malformed);
    assert.deepEqual(
      await db.collection("migrationRuns").find().toArray(),
      journals,
    );
  } finally {
    await db.dropDatabase();
    await mongo.close();
  }
});
