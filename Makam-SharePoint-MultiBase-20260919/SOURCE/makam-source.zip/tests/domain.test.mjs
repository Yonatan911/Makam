import test from "node:test";
import assert from "node:assert/strict";
import {
  readiness,
  freshness,
  aggregate,
  publicRoom,
} from "../shared/domain.mjs";
import {
  canRead,
  canWrite,
  passwordHash,
  verifyPassword,
} from "../backend/src/security.js";
const asset = (id, changes = {}) => ({
  id,
  name: id,
  kind: "computer",
  category: "computing",
  critical: false,
  status: "healthy",
  severity: "high",
  parentId: null,
  dependency: "none",
  ...changes,
});
const room = (assets) => ({
  id: "r",
  name: "חמ״ל",
  assets,
  maintenance: false,
  faults: [],
  audit: [],
  lastCheck: {
    at: new Date().toISOString(),
    actor: "PRIVATE",
    actorId: "secret",
  },
  plan: {},
  version: 1,
});
test("matrix failure propagates to two displays without double counting", () => {
  const r = room([
    asset("matrix", {
      kind: "matrix",
      category: "display",
      critical: true,
      status: "faulty",
    }),
    asset("screen1", {
      category: "display",
      parentId: "matrix",
      dependency: "hard",
    }),
    asset("screen2", {
      category: "display",
      parentId: "matrix",
      dependency: "hard",
      status: "faulty",
    }),
  ]);
  const m = readiness(r);
  assert.equal(m.overall.score, 0);
  assert.equal(m.overall.lossWeight, 5);
  assert.equal(m.impacted, 3);
  assert.equal(m.categories.display.score, 0);
});
test("UPS affects power readiness, not computer availability", () => {
  const m = readiness(
    room([
      asset("ups", {
        kind: "ups",
        category: "power",
        critical: true,
        status: "faulty",
      }),
      asset("pc", { parentId: "ups", dependency: "redundancy" }),
    ]),
  );
  assert.equal(m.categories.computing.score, 100);
  assert.equal(m.categories.power.score, 0);
  assert.equal(m.overall.score, 25);
  assert.equal(m.warning, true);
});
test("scheduled maintenance and hard dependents are excluded from the denominator", () => {
  const m = readiness(
    room([
      asset("matrix", { status: "maintenance", critical: true }),
      asset("screen", { parentId: "matrix", dependency: "hard" }),
      asset("pc"),
    ]),
  );
  assert.equal(m.overall.totalWeight, 1);
  assert.equal(m.overall.score, 100);
  assert.equal(m.planned, 2);
});
test("planned room / empty inventory do not invent a readiness percentage", () => {
  assert.equal(
    readiness({ ...room([asset("x")]), maintenance: true }).overall.score,
    null,
  );
  assert.equal(readiness(room([])).overall.score, null);
  assert.equal(aggregate([]).overall, null);
});
test("severity weighting and repaired-awaiting-verification still reduce readiness", () => {
  assert.equal(
    readiness(
      room([
        asset("x", { status: "repaired", severity: "medium", critical: true }),
        asset("y"),
      ]),
    ).overall.score,
    55,
  );
});
test("freshness boundaries and emergency rounds use captured round IDs", () => {
  const now = Date.now(),
    s = { freshnessDays: 7, round: null };
  const r = room([]);
  r.lastCheck.at = new Date(now - 7 * 86400000 * 0.75).toISOString();
  assert.equal(freshness(r, s, now), "aging");
  r.lastCheck.at = new Date(now - 7 * 86400000).toISOString();
  assert.equal(freshness(r, s, now), "expired");
  r.lastCheck.at = new Date(now).toISOString();
  s.round = { id: "new", roomIds: ["r"] };
  assert.equal(freshness(r, s, now), "expired");
  r.lastCheck.roundId = "new";
  assert.equal(freshness(r, s, now), "fresh");
});
test("viewer sees inventory without logs, fault opening times or checker identity", () => {
  const r = room([asset("SECRET-IP")]);
  r.audit = [{ actor: "PRIVATE" }];
  r.faults = [
    { id: "f", openedBy: "PRIVATE", openedAt: "PRIVATE", status: "faulty" },
  ];
  const result = publicRoom(r, { role: "viewer" }, { freshnessDays: 7 });
  assert.equal(result.assets.length, 1);
  assert.equal(result.audit, undefined);
  assert.equal(result.faults.length, 1);
  assert.ok(!JSON.stringify(result).includes("PRIVATE"));
  assert.ok(JSON.stringify(result).includes("SECRET-IP"));
  assert.ok(result.lastCheck.at);
});
test("technician cannot retrieve completed faults or checker history", () => {
  const r = room([]);
  r.faults = [
    { id: "closed", status: "closed" },
    {
      id: "open",
      status: "faulty",
      openedBy: "PRIVATE",
      openedAt: "PRIVATE",
      history: [{ actor: "PRIVATE" }],
    },
  ];
  const p = publicRoom(r, { role: "technician" }, { freshnessDays: 7 });
  assert.equal(p.faults.length, 1);
  assert.equal(p.audit, undefined);
  assert.ok(!JSON.stringify(p).includes("PRIVATE"));
});
test("manual room assignment controls read and write permissions", () => {
  const user = { role: "technician", roomIds: ["one"] };
  assert.equal(canWrite(user, "one"), true);
  assert.equal(canWrite(user, "two"), false);
  assert.equal(canRead({ role: "viewer", roomIds: ["one"] }, "one"), true);
  assert.equal(canWrite({ role: "viewer", roomIds: ["one"] }, "one"), false);
});
test("password verification uses salted hashes", () => {
  const a = passwordHash("long-test-password"),
    b = passwordHash("long-test-password");
  assert.notEqual(a, b);
  assert.equal(verifyPassword("long-test-password", a), true);
  assert.equal(verifyPassword("wrong", a), false);
});
