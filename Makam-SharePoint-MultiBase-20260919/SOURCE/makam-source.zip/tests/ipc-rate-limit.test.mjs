import test from "node:test";
import assert from "node:assert/strict";
import { request } from "node:http";
import { once } from "node:events";
import { randomUUID } from "node:crypto";
import { createRequire } from "node:module";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { MongoClient } from "mongodb";

// This exercises real IPC transport and MongoDB. Native IIS headers are simulated;
// only the organizational IIS acceptance can prove their provenance.
const backend = createRequire(
  path.resolve(process.env.MAKAM_TEST_SERVER_ROOT || "backend", "package.json"),
);
const { createApp } = backend("./src/app.js");
const { loadConfiguration } = backend("./src/config.js");
const { preflight, applyMigration } = backend("./src/migrations.js");

test("IPC session quotas isolate trusted identities and reject untrusted key inputs", async (t) => {
  const id = randomUUID().replaceAll("-", "");
  const socketPath =
    process.platform === "win32"
      ? "\\\\.\\pipe\\makam-quota-" + id
      : "/tmp/makam-quota-" + id + ".sock";
  const client = await new MongoClient("mongodb://127.0.0.1:27028").connect();
  const db = client.db("readiness_test_ipc_" + id);
  const config = loadConfiguration({
    env: {
      NODE_ENV: "test",
      AUTH_MODE: "iis-session",
      PORT: socketPath,
      TRUSTED_IDENTITY_VERIFIED: "true",
      AD_DOMAIN: "ARMY",
      PUBLIC_API_URL: "http://127.0.0.1:4310/makam/api",
      SHAREPOINT_ORIGIN: "http://127.0.0.1:4179",
      MONGODB_DATABASE: db.databaseName,
    },
  });
  const evidence = {
    platform: process.platform,
    architecture: process.arch,
    node: process.version,
    transport:
      process.platform === "win32"
        ? "real Windows Named Pipe HTTP"
        : "real Unix-domain HTTP socket",
    database: "real isolated MongoDB",
    identityHeaders: "SIMULATED — IIS NOT RUN",
    trustProxy: false,
    remoteAddress: null,
    probes: {},
    warnings: [],
  };
  const originalError = console.error;
  const warnings = [];
  console.error = (...args) => {
    warnings.push(args.map(String).join(" "));
    originalError(...args);
  };
  let server;
  const send = (identity, extras = {}, route = "/auth/session") =>
    new Promise((resolve, reject) => {
      const req = request(
        {
          socketPath,
          path: "/makam/api" + route,
          method: "POST",
          headers: {
            Host: "127.0.0.1:4310",
            Origin: "http://127.0.0.1:4179",
            "Content-Type": "application/json",
            ...(identity
              ? {
                  "x-iisnode-auth_user": identity,
                  "x-iisnode-auth_type": "Negotiate",
                }
              : {}),
            ...extras,
          },
        },
        (res) => {
          res.resume();
          res.on("end", () =>
            resolve({
              status: res.statusCode,
              remaining: res.headers["ratelimit-remaining"],
              retryAfter: res.headers["retry-after"],
            }),
          );
        },
      );
      req.on("error", reject);
      // These browser-controlled values must never choose the identity or quota.
      req.end(
        JSON.stringify({
          username: randomUUID(),
          userId: randomUUID(),
          role: "owner",
        }),
      );
    });
  try {
    await applyMigration(
      db,
      await preflight(db, { ownerSam: "quota.owner", adminSam: "quota.admin" }),
    );
    const app = await createApp({ db, config });
    assert.equal(app.get("trust proxy"), false);
    server = app.listen(socketPath);
    server.on("request", (req) => {
      evidence.remoteAddress = req.socket.remoteAddress ?? null;
    });
    await once(server, "listening");
    await t.test(
      "42 anonymous IPC requests stay rejected without a shared login bucket",
      async () => {
        const results = [];
        for (let i = 0; i < 42; i++)
          results.push(
            (await send(null, { "X-Forwarded-For": "192.0.2." + (i + 1) }))
              .status,
          );
        evidence.probes.anonymous = results;
        assert.deepEqual(results, Array(42).fill(401));
      },
    );
    await t.test(
      "malformed, duplicate, wrong-domain and unsupported native identities fail closed",
      async () => {
        const results = [];
        for (const [identity, headers] of [
          ["OTHER\\quota.owner", {}],
          ["ARMY\\quota.owner, ARMY\\quota.admin", {}],
          [
            "ARMY\\quota.owner",
            {
              "x-iisnode-auth_user": ["ARMY\\quota.owner", "ARMY\\quota.owner"],
            },
          ],
          [
            "ARMY\\quota.owner",
            { "x-iisnode-auth_type": ["NTLM", "Negotiate"] },
          ],
          ["ARMY\\quota.owner", { "x-iisnode-auth_type": "Basic" }],
          [
            null,
            {
              "X-Remote-User": "ARMY\\quota.owner",
              "X-User-Id": "quota.owner",
            },
          ],
        ])
          results.push((await send(identity, headers)).status);
        evidence.probes.invalid = results;
        assert.deepEqual(results, Array(6).fill(401));
      },
    );
    await t.test(
      "one trusted identity is limited despite changing XFF, body, case and route alias",
      async () => {
        const results = [];
        for (let i = 0; i < 40; i++)
          results.push(
            (
              await send("ARMY\\quota.owner", {
                "X-Forwarded-For": "198.51.100." + (i + 1),
              })
            ).status,
          );
        evidence.probes.firstIdentity = results;
        assert.deepEqual(results, Array(40).fill(201));
        const blocked = await send(
          "army\\QUOTA.OWNER",
          { "X-Forwarded-For": "203.0.113.8" },
          "/auth/session.js",
        );
        evidence.probes.firstBlocked = blocked;
        assert.equal(blocked.status, 429);
        assert.ok(Number(blocked.retryAfter) > 0);
      },
    );
    await t.test(
      "a second trusted identity has its own full quota on the same IPC listener",
      async () => {
        const results = [];
        for (let i = 0; i < 40; i++)
          results.push((await send("ARMY\\quota.admin")).status);
        evidence.probes.secondIdentity = results;
        assert.deepEqual(results, Array(40).fill(201));
        assert.equal((await send("ARMY\\quota.admin")).status, 429);
        assert.equal((await send("ARMY\\quota.owner")).status, 429);
      },
    );
    await t.test(
      "unassigned identities are rejected and limited; inactive accounts cannot obtain a session",
      async () => {
        const results = [];
        for (let i = 0; i < 40; i++)
          results.push((await send("ARMY\\quota.unassigned")).status);
        assert.deepEqual(results, Array(40).fill(403));
        assert.equal((await send("ARMY\\quota.unassigned")).status, 429);
        await db
          .collection("users")
          .insertOne({
            id: randomUUID(),
            username: "quota.inactive",
            active: false,
          });
        assert.equal((await send("ARMY\\quota.inactive")).status, 403);
        evidence.probes.unassigned = results;
      },
    );
    await t.test(
      "disabled local endpoints do not invoke an IP limiter on IPC; no validation warnings",
      async () => {
        for (const route of [
          "/auth/local-login",
          "/auth/launch",
          "/auth/login",
        ])
          assert.ok([403, 404].includes((await send(null, {}, route)).status));
        assert.equal(evidence.remoteAddress, null);
        evidence.warnings = warnings;
        assert.deepEqual(warnings, []);
      },
    );
  } finally {
    console.error = originalError;
    evidence.warnings = warnings;
    if (server) await new Promise((resolve) => server.close(resolve));
    await db.dropDatabase();
    await client.close();
    if (process.env.MAKAM_EVIDENCE_DIR) {
      await mkdir(process.env.MAKAM_EVIDENCE_DIR, { recursive: true });
      await writeFile(
        path.join(process.env.MAKAM_EVIDENCE_DIR, "ipc-rate-limit.json"),
        JSON.stringify(evidence, null, 2) + "\n",
      );
    }
  }
});
