import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { request } from "node:http";
import { MongoClient } from "mongodb";
import { randomUUID } from "node:crypto";
import { loadConfiguration, parseListenTarget } from "../backend/src/config.js";
import { startServer } from "../backend/src/server.js";
import { createApp } from "../backend/src/app.js";
import {
  preflight,
  applyMigration,
  restoreMigration,
} from "../backend/src/migrations.js";
import { verifySchema } from "../backend/src/database.js";
import { sampleRooms } from "../backend/src/seed.js";
import { createMailJobs } from "../backend/src/mail-jobs.js";
import { hash } from "../backend/src/security.js";

const prod = {
  NODE_ENV: "production",
  AUTH_MODE: "iis-session",
  MONGODB_URI: "mongodb://org.example:27017",
  MONGODB_DATABASE: "makam",
  PUBLIC_API_URL: "https://api.example/makam/api",
  APP_PUBLIC_URL: "https://sp.example/sites/ops",
  SHAREPOINT_ORIGIN: "https://sp.example",
  AD_DOMAIN: "ARMY",
  TRUSTED_IDENTITY_VERIFIED: "true",
  PORT: "\\\\.\\pipe\\makam-test",
};
const httpFetch = (url, options = {}) =>
  new Promise((resolve, reject) => {
    const r = request(
      url,
      { method: options.method, headers: options.headers },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () =>
          resolve(
            new Response(
              res.statusCode === 204 ? null : Buffer.concat(chunks),
              { status: res.statusCode, headers: res.headers },
            ),
          ),
        );
      },
    );
    r.on("error", reject);
    r.end(options.body);
  });
async function fixture(task) {
  const client = new MongoClient("mongodb://127.0.0.1:27028");
  await client.connect();
  const db = client.db(
    "readiness_test_remediation_" + randomUUID().replaceAll("-", ""),
  );
  try {
    await task(db);
  } finally {
    await db.dropDatabase();
    await client.close();
  }
}
const init = async (db) =>
  applyMigration(
    db,
    await preflight(db, { ownerSam: "m9267680", adminSam: "c9812933" }),
  );
const stateOf = async (db) => {
  const result = {};
  for (const n of [
    "users",
    "rooms",
    "settings",
    "migrationRuns",
    "migrationRecords",
  ])
    result[n] = await db.collection(n).find().sort({ _id: 1 }).toArray();
  return result;
};
test("config preserves named pipe, host precedence and root-relative dotenv", async () => {
  const root = await mkdtemp(path.join(tmpdir(), "makam-config-"));
  try {
    await writeFile(
      path.join(root, ".env"),
      "PORT=4321\nNODE_ENV=development\nMONGODB_DATABASE=from_file\nAUTH_MODE=local\n",
    );
    const c = loadConfiguration({
      root,
      env: {
        PORT: "\\\\.\\pipe\\host-pipe",
        MONGODB_DATABASE: "host_db",
        NODE_ENV: "test",
      },
    });
    assert.equal(c.listenTarget, "\\\\.\\pipe\\host-pipe");
    assert.equal(c.database, "host_db");
    assert.equal(c.root, root);
    assert.equal(loadConfiguration({ root, env: {} }).listenTarget, 4321);
    assert.equal(parseListenTarget("0"), 0);
    assert.throws(() => parseListenTarget("abc"));
    assert.throws(() => parseListenTarget("65536"));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
test("production invalid config fails before connecting; no local or identity fallback", async () => {
  assert.throws(
    () => loadConfiguration({ env: { NODE_ENV: "production" } }),
    /Missing/,
  );
  assert.throws(
    () => loadConfiguration({ env: { ...prod, AUTH_MODE: "local" } }),
    /requires/,
  );
  assert.throws(
    () =>
      loadConfiguration({
        env: { ...prod, TRUSTED_IDENTITY_VERIFIED: "false" },
      }),
    /DevOps/,
  );
  assert.throws(
    () =>
      loadConfiguration({ env: { ...prod, ENABLE_LOCAL_TEST_LOGIN: "true" } }),
    /Production/,
  );
  let connected = false;
  await assert.rejects(
    startServer({
      config: loadConfiguration({ env: { ...prod, PORT: "4310" } }),
      connect: async () => {
        connected = true;
      },
    }),
    /IISNode/,
  );
  assert.equal(connected, false);
  assert.equal(loadConfiguration({ env: prod }).apiPrefix, "/makam");
});
test("application import/create and schema verification perform zero initialization writes", () =>
  fixture(async (db) => {
    await assert.rejects(verifySchema(db), /setup/);
    assert.deepEqual(await db.listCollections().toArray(), []);
    await init(db);
    const before = await stateOf(db);
    const app = await createApp({
      db,
      config: loadConfiguration({ env: { NODE_ENV: "test", PORT: "0" } }),
    });
    assert.equal(typeof app, "function");
    assert.deepEqual(await stateOf(db), before);
    assert.equal(app.get("trust proxy"), false);
  }));
test("actual Windows named-pipe HTTP listener and graceful shutdown", () =>
  fixture(async (db) => {
    await init(db);
    const pipe = "\\\\.\\pipe\\makam-" + randomUUID();
    let closed = 0;
    const config = loadConfiguration({
      env: {
        NODE_ENV: "test",
        PORT: pipe,
        AUTH_MODE: "local",
        MONGODB_DATABASE: db.databaseName,
      },
    });
    const runtime = await startServer({
      config,
      connect: async () => ({ db, client: { close: async () => closed++ } }),
    });
    try {
      assert.equal(runtime.server.address(), pipe);
      const result = await new Promise((resolve, reject) => {
        const r = request(
          {
            socketPath: pipe,
            path: "/api/health",
            headers: { Host: "127.0.0.1:4310" },
          },
          (res) => {
            let body = "";
            res.on("data", (d) => (body += d));
            res.on("end", () =>
              resolve({ status: res.statusCode, body: JSON.parse(body) }),
            );
          },
        );
        r.on("error", reject);
        r.end();
      });
      assert.equal(result.status, 200);
      assert.equal(result.body.ok, true);
    } finally {
      await Promise.all([runtime.shutdown(), runtime.shutdown()]);
      assert.equal(closed, 1);
      assert.equal(runtime.server.listening, false);
    }
  }));
test("migration preflight rejects collisions/malformed records without ANY writes", () =>
  fixture(async (db) => {
    const id = randomUUID();
    await db.collection("settings").insertOne({ _id: "main", version: 1 });
    await db.collection("users").insertMany([
      {
        _id: id,
        id,
        username: "ARMY\\Owner",
        owner: true,
        role: "admin",
        active: true,
        roomIds: [],
      },
      {
        _id: "b",
        id: "b",
        username: "owner",
        role: "viewer",
        active: true,
        roomIds: [],
      },
    ]);
    let before = await stateOf(db);
    await assert.rejects(preflight(db), /Duplicate/);
    assert.deepEqual(await stateOf(db), before);
    await db.collection("users").deleteOne({ _id: "b" });
    await db.collection("rooms").insertOne({
      id: "bad",
      version: 1,
      assets: [],
      faults: [],
      audit: [],
      plan: { tables: "bad" },
    });
    before = await stateOf(db);
    await assert.rejects(preflight(db), /Malformed/);
    assert.deepEqual(await stateOf(db), before);
  }));
test("migration interrupted apply is recoverable, rerun is safe, and backup restores exact records", () =>
  fixture(async (db) => {
    const owner = {
      _id: "owner",
      id: "owner",
      username: "ARMY\\Legacy.Owner",
      role: "admin",
      owner: true,
      active: true,
      roomIds: [],
      preferences: { theme: "dark", custom: "preserved" },
      rank: "legacy",
    };
    await db.collection("users").insertOne(owner);
    await db
      .collection("settings")
      .insertOne({ _id: "main", version: 4, freshnessDays: 14, note: "keep" });
    await db.collection("rooms").insertMany(sampleRooms());
    const original = await stateOf(db),
      plan = await preflight(db);
    let once = true;
    await assert.rejects(
      applyMigration(db, plan, {
        onCheckpoint: () => {
          if (once) {
            once = false;
            throw new Error("simulated interruption");
          }
        },
      }),
      /interruption/,
    );
    const active = await db
      .collection("migrationRuns")
      .findOne({ _id: "active" });
    assert.ok(active.runId);
    await assert.rejects(verifySchema(db), /in progress/);
    await applyMigration(db, null, { resumeId: active.runId });
    await verifySchema(db);
    assert.equal(
      (await db.collection("users").findOne({ id: "owner" })).preferences
        .custom,
      "preserved",
    );
    assert.equal((await preflight(db)).changed, false);
    assert.equal(await applyMigration(db, await preflight(db)), null);
    await restoreMigration(db, active.runId);
    const restored = await stateOf(db);
    for (const n of ["users", "rooms", "settings"])
      assert.deepEqual(restored[n], original[n]);
  }));
test("IIS adapter simulation: trusted native identity, duplicates, forged body, revocation/expiry, CORS/prefix and file denials", () =>
  fixture(async (db) => {
    await init(db);
    const config = loadConfiguration({
        env: { ...prod, NODE_ENV: "test", MONGODB_DATABASE: db.databaseName },
      }),
      app = await createApp({ db, config }),
      server = app.listen(0, "127.0.0.1");
    await new Promise((r) => server.once("listening", r));
    const url = "http://127.0.0.1:" + server.address().port;
    const call = (route, options = {}) =>
      httpFetch(url + "/makam/api" + route, {
        ...options,
        headers: {
          Host: "api.example",
          Origin: "https://sp.example",
          ...options.headers,
        },
      });
    try {
      const pre = await call("/state", {
        method: "OPTIONS",
        headers: {
          "Access-Control-Request-Method": "PATCH",
          "Access-Control-Request-Headers":
            "authorization,content-type,x-readiness-client",
        },
      });
      assert.equal(pre.status, 204);
      assert.equal(pre.headers.get("access-control-allow-credentials"), "true");
      assert.equal(
        pre.headers.get("access-control-expose-headers"),
        "Content-Disposition",
      );
      assert.equal((await call("/state")).status, 401);
      assert.equal(
        (
          await call("/auth/session", {
            method: "POST",
            headers: {
              "Content-Type": "text/plain",
              "X-IISNode-Auth-User": "ARMY\\m9267680",
            },
            body: "",
          })
        ).status,
        401,
      );
      assert.equal(
        (
          await call("/auth/session", {
            method: "POST",
            headers: {
              "Content-Type": "text/plain",
              "x-iisnode-auth_user": "ARMY\\m9267680, ARMY\\attacker",
              "x-iisnode-auth_type": "Negotiate",
            },
          })
        ).status,
        401,
      );
      const r = await call("/auth/session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-iisnode-auth_user": "ARMY\\c9812933",
          "x-iisnode-auth_type": "Negotiate",
        },
        body: JSON.stringify({ username: "m9267680", role: "owner" }),
      });
      assert.equal(r.status, 201);
      const { token, user } = await r.json();
      assert.equal(user.role, "admin");
      const headers = { Authorization: "Bearer " + token };
      assert.equal((await call("/state", { headers })).status, 200);
      assert.equal((await call("/owner/diagnostics", { headers })).status, 403);
      await db
        .collection("users")
        .updateOne({ id: user.id }, { $set: { active: false } });
      assert.equal((await call("/state", { headers })).status, 401);
      await db
        .collection("users")
        .updateOne({ id: user.id }, { $set: { active: true } });
      await db
        .collection("sessions")
        .updateOne({ _id: hash(token) }, { $set: { expiresAt: new Date(0) } });
      assert.equal((await call("/state", { headers })).status, 401);
      assert.equal(
        (await call("/state", { headers: { Origin: "https://evil.example" } }))
          .status,
        403,
      );
      for (const file of [
        "src/server.js",
        ".env",
        ".env.production",
        "package.json",
        "package-lock.json",
        "logs/x",
        "backups/x",
        "node_modules/x",
        "iisnode/x",
        ".git/config",
        "api/../../src/server.js",
      ]) {
        const response = await httpFetch(url + "/makam/" + file, {
          headers: { Host: "api.example" },
        });
        assert.equal(response.status, 404, file);
      }
      assert.equal(
        (
          await httpFetch(url + "/api/health", {
            headers: { Host: "api.example" },
          })
        ).status,
        404,
      );
    } finally {
      await new Promise((r) => server.close(r));
    }
  }));
test("SMTP durable atomic claims, stale sends and partial/unknown outcomes are never blindly resent", () =>
  fixture(async (db) => {
    await db.collection("settings").insertOne({
      _id: "main",
      remindersEnabled: true,
      reminderDay: 99,
      reminderTime: "09:30",
      schedule: { day: 4, time: "17:00" },
      recipients: ["a@unit.example"],
    });
    await db.collection("mailOutbox").insertMany([
      {
        _id: "one",
        id: "one",
        kind: "weekly",
        status: "pending",
        subject: "test",
        text: "test",
      },
      {
        _id: "stale",
        id: "stale",
        kind: "weekly",
        status: "sending",
        leaseUntil: new Date(0),
      },
      { _id: "partial", id: "partial", kind: "weekly", status: "partial" },
    ]);
    const saved = { host: process.env.SMTP_HOST, from: process.env.SMTP_FROM };
    process.env.SMTP_HOST = "mock.invalid";
    process.env.SMTP_FROM = "mock@unit.example";
    let count = 0;
    const factory = () => ({
      sendMail: async () => {
        count++;
        await new Promise((r) => setTimeout(r, 30));
        return { accepted: ["a"], rejected: [] };
      },
      close() {},
    });
    try {
      const a = createMailJobs(db, "https://sp.example", factory),
        b = createMailJobs(db, "https://sp.example", factory);
      await Promise.all([a.tick(), b.tick()]);
      assert.equal(count, 1);
      assert.equal(
        (await db.collection("mailOutbox").findOne({ _id: "stale" })).status,
        "outcome_unknown",
      );
      await db.collection("mailOutbox").insertOne({
        _id: "ambiguous",
        id: "ambiguous",
        kind: "weekly",
        status: "pending",
      });
      await createMailJobs(db, "https://sp.example", () => ({
        sendMail: async () => {
          count++;
          throw new Error("disconnect after DATA");
        },
      })).tick();
      await a.tick();
      assert.equal(count, 2);
      assert.equal(
        (await db.collection("mailOutbox").findOne({ _id: "ambiguous" }))
          .status,
        "outcome_unknown",
      );
      a.stop();
      await a.tick();
      assert.equal(count, 2);
    } finally {
      for (const [key, value] of [
        ["SMTP_HOST", saved.host],
        ["SMTP_FROM", saved.from],
      ])
        if (value === undefined) delete process.env[key];
        else process.env[key] = value;
    }
  }));
test("web.config retains auth on physical handler, forbids caller headers and has no static file bypass", async () => {
  const xml = await readFile("backend/web.config", "utf8");
  assert.match(xml, /path="src\/server.js"/);
  assert.match(xml, /promoteServerVars="AUTH_USER,AUTH_TYPE"/);
  assert.match(xml, /<location path="api\/auth\/session.js">/);
  assert.match(xml, /RejectClientIdentityHeaders/);
  assert.ok(
    xml.indexOf("RejectClientIdentityHeaders") <
      xml.indexOf("AnonymousPreflight"),
  );
  assert.ok(!xml.includes('matchType="IsFile"'));
  assert.match(xml, /devErrorsEnabled="false"/);
});
