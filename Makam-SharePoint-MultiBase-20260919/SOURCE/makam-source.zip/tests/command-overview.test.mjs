import test from "node:test";
import assert from "node:assert/strict";
import {
  summarizeBase,
  summarizeCommand,
  slaMetrics,
  checkState,
  commandWorkbook,
  commandDate,
} from "../backend/src/command-overview.js";
import { readinessBand } from "../shared/model.mjs";
const now = Date.parse("2026-09-20T10:00:00Z");
const iso = (days) => new Date(now + days * 86400000).toISOString();
const settings = {
  baseName: "בסיס בדיקה",
  freshnessDays: 7,
  schedule: { enabled: false },
};
const asset = (id, extra = {}) => ({
  id,
  name: id,
  category: "computing",
  status: "healthy",
  ...extra,
});
const room = (extra = {}) => ({
  id: "r",
  name: "מרחב",
  type: "חמ״ל",
  assets: [asset("a")],
  faults: [],
  requests: [],
  lastCheck: { at: iso(-1) },
  ...extra,
});

test("command readiness boundaries and empty bases stay unknown", () => {
  assert.deepEqual([69, 70, 90, 91, null].map(readinessBand), [
    "red",
    "orange",
    "orange",
    "green",
    "unknown",
  ]);
  const empty = summarizeBase({ id: "empty" }, [], settings, now).summary;
  assert.equal(empty.score, null);
  assert.equal(empty.sla.percent, null);
  assert.equal(summarizeCommand([empty]).score, null);
  assert.equal(
    summarizeBase({ id: "b" }, [room({ lastCheck: null })], settings, now)
      .summary.checkExceptions,
    1,
  );
});
test("command weighting excludes removed and planned assets including inherited maintenance", () => {
  const first = summarizeBase(
    { id: "a" },
    [
      room({
        assets: [
          asset("a", { status: "faulty", severity: "high" }),
          asset("b", { archived: true }),
          asset("c", { status: "maintenance" }),
          asset("d", { parentIds: ["c"] }),
        ],
      }),
    ],
    settings,
    now,
  ).summary;
  const second = summarizeBase(
    { id: "b" },
    [room({ assets: [asset("1"), asset("2"), asset("3")] })],
    settings,
    now,
  ).summary;
  assert.equal(first.assetCount, 1);
  assert.equal(first.score, 0);
  assert.equal(summarizeCommand([first, second]).score, 75);
  assert.equal(
    summarizeBase({ id: "c" }, [room({ maintenance: true })], settings, now)
      .summary.assetCount,
    0,
  );
});
test("SLA counts closed late, open late, in time, no target and planned separately", () => {
  const value = slaMetrics(
    [
      { status: "closed", slaAt: iso(-1), closedAt: iso(-2) },
      { status: "closed", slaAt: iso(-2), closedAt: iso(-1) },
      { status: "waiting", slaAt: iso(-1) },
      { status: "faulty", slaAt: iso(1) },
      { status: "faulty" },
      { status: "maintenance", slaAt: iso(-1) },
    ],
    now,
  );
  assert.deepEqual(value, {
    eligible: 4,
    met: 2,
    breached: 2,
    openBreached: 1,
    withoutTarget: 1,
    unknownClosure: 0,
    percent: 50,
  });
  assert.equal(
    slaMetrics([{ status: "closed", slaAt: iso(1) }], now).unknownClosure,
    1,
  );
  assert.equal(slaMetrics([{ status: "faulty", slaAt: iso(0) }], now).met, 1);
});
test("freshness distinguishes never, aging, schedule, round and requested checks", () => {
  assert.equal(checkState(room(), settings, now), "fresh");
  assert.equal(
    checkState(room({ lastCheck: { at: iso(-6) } }), settings, now),
    "aging",
  );
  assert.equal(
    checkState(room({ lastCheck: { at: iso(-8) } }), settings, now),
    "expired",
  );
  assert.equal(checkState(room({ lastCheck: null }), settings, now), "never");
  assert.equal(
    checkState(room({ requests: [{ status: "approved" }] }), settings, now),
    "pending",
  );
  assert.equal(
    checkState(
      room(),
      { ...settings, round: { id: "round", roomIds: ["r"] } },
      now,
    ),
    "pending",
  );
  assert.equal(
    checkState(room({ maintenance: true }), settings, now),
    "planned",
  );
  assert.equal(
    checkState(
      room(),
      { ...settings, schedule: { enabled: true, day: 0, time: "09:00" } },
      now,
    ),
    "expired",
  );
});
test("Excel includes every metric, Hebrew dates and theme without exposing raw inventory", async () => {
  const base = summarizeBase({ id: "a" }, [room()], settings, now).summary;
  const generatedAt = new Date(now).toISOString();
  for (const dark of [false, true]) {
    const wb = await commandWorkbook({ bases: [base], generatedAt }, dark);
    const sheet = wb.worksheets[0];
    assert.equal(sheet.rowCount, 2);
    assert.equal(sheet.columnCount, 31);
    assert.equal(sheet.views[0].rightToLeft, true);
    assert.equal(sheet.getCell("A2").value, settings.baseName);
    assert.equal(
      sheet.getCell("A2").fill.fgColor.argb,
      dark ? "FF1A242F" : "FFF5F8FA",
    );
    assert.doesNotMatch(
      JSON.stringify(sheet.getRow(2).values),
      /\b(?:AM|PM)\b/,
    );
    assert.ok((await wb.xlsx.writeBuffer()).byteLength > 0);
  }
  assert.match(commandDate("2026-09-20T20:59:00Z"), /23:59/);
});
