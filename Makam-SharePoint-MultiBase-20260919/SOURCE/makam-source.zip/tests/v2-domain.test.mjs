import test from "node:test";
import assert from "node:assert/strict";
import {
  scheduleState,
  israelTime,
  freshness,
  readiness,
  DEFAULT_SCORING,
  publicRoom,
} from "../shared/model.mjs";
import { normalizeWindowsIdentity } from "../backend/src/security.js";
import {
  validateDependencies,
  applyDependents,
} from "../backend/src/validation.js";
import {
  hasRoomAccess,
  canEditRoom,
  readinessBand,
  sortRooms,
} from "../shared/model.mjs";
test("readiness color boundaries and stable sorting keep missing scores separate", () => {
  assert.deepEqual([null, 0, 69, 70, 90, 91, 100].map(readinessBand), [
    "unknown",
    "red",
    "red",
    "orange",
    "orange",
    "green",
    "green",
  ]);
  const rooms = [null, 91, 69, 70].map((score, i) => ({
    name: String(i),
    metrics: { overall: { score } },
  }));
  assert.deepEqual(
    sortRooms(rooms, "score-low").map((r) => r.metrics.overall.score),
    [69, 70, 91, null],
  );
  assert.deepEqual(
    sortRooms(rooms, "score-high").map((r) => r.metrics.overall.score),
    [91, 70, 69, null],
  );
  assert.equal(rooms[0].metrics.overall.score, null);
});
test("parent-side assignment preserves other parents, removes only selected edges and rejects cycles", () => {
  const a = { id: "a", kind: "matrix" },
    b = { id: "b", kind: "matrix" },
    c = { id: "c", kind: "screen", parentIds: ["b"] };
  const room = { assets: [a, b, c] };
  applyDependents(room, a, ["c"]);
  assert.deepEqual(c.parentIds, ["b", "a"]);
  validateDependencies(room);
  applyDependents(room, a, []);
  assert.deepEqual(c.parentIds, ["b"]);
  applyDependents(room, c, ["b"]);
  assert.throws(() => validateDependencies(room), /מעגל תלות/);
  assert.throws(() => applyDependents(room, a, ["missing"]), /מאותו מרחב/);
});
test("multiple upstream paths propagate loss once, reject cycles and preserve UPS semantics", () => {
  const asset = (id, extra = {}) => ({
    id,
    name: id,
    status: "healthy",
    kind: "matrix",
    severity: "high",
    category: "display",
    ...extra,
  });
  const a = asset("a", { status: "faulty" }),
    b = asset("b", { parentIds: ["a"] }),
    c = asset("c", { kind: "screen", parentIds: ["a", "b"] });
  const room = { assets: [a, b, c] };
  validateDependencies(room);
  assert.equal(readiness(room).overall.score, 0);
  assert.deepEqual(readiness(room).assets[2].causeIds, ["a"]);
  a.status = "healthy";
  assert.equal(readiness(room).overall.score, 100);
  a.parentIds = ["c"];
  assert.throws(() => validateDependencies(room), /מעגל תלות/);
  a.parentIds = [];
  a.kind = "ups";
  assert.throws(() => validateDependencies(room), /אל־פסק/);
});
test("all-room scope is explicit, includes future rooms and does not elevate a read-only role", () => {
  const tech = { role: "technician", roomIds: ["old"], allRooms: true };
  assert.equal(canEditRoom(tech, "future"), true);
  assert.equal(canEditRoom({ ...tech, allRooms: false }, "future"), false);
  assert.equal(
    hasRoomAccess({ role: "viewer", allRooms: true }, "future"),
    true,
  );
  assert.equal(
    canEditRoom({ role: "viewer", allRooms: true }, "future"),
    false,
  );
});
const settings = {
  freshnessDays: 7,
  schedule: { enabled: true, day: 4, time: "09:30" },
};
test("weekly due date is based on Jerusalem calendar including DST", () => {
  const now = israelTime(2026, 9, 10, 10),
    r = { assets: [], requests: [], lastCheck: null };
  assert.equal(scheduleState(r, settings, now).overdue, true);
  r.lastCheck = { at: new Date(israelTime(2026, 9, 10, 8)).toISOString() };
  assert.equal(scheduleState(r, settings, now).overdue, false);
  assert.equal(
    scheduleState(r, settings, now).dueAt,
    "2026-09-10T06:30:00.000Z",
  );
  assert.equal(
    scheduleState(r, settings, israelTime(2026, 12, 10, 10)).dueAt,
    "2026-12-10T07:30:00.000Z",
  );
  r.lastCheck.at = new Date(israelTime(2026, 9, 9, 23, 59)).toISOString();
  assert.equal(scheduleState(r, settings, now).overdue, true);
});
test("approved requests invalidate readiness even with a fresh full check", () => {
  const r = {
    assets: [],
    requests: [{ status: "approved" }],
    lastCheck: { at: new Date().toISOString() },
  };
  assert.equal(freshness(r, { freshnessDays: 7 }), "expired");
  r.requests[0].status = "completed";
  assert.equal(freshness(r, { freshnessDays: 7 }), "fresh");
});
test("absent UPS has no penalty, archives and custom weights remain transparent", () => {
  const r = {
    assets: [
      {
        id: "pc",
        name: "pc",
        kind: "computer",
        category: "computing",
        status: "healthy",
      },
      {
        id: "old",
        name: "old",
        kind: "ups",
        category: "power",
        status: "faulty",
        archived: true,
      },
    ],
  };
  assert.equal(readiness(r).overall.score, 100);
  assert.equal(readiness(r).categories.power.score, null);
  assert.equal(readiness(r).warning, false);
  r.assets.push({
    id: "two",
    name: "two",
    kind: "computer",
    category: "computing",
    status: "faulty",
    critical: true,
    severity: "medium",
  });
  const m = readiness(r, {
    scoring: { ...DEFAULT_SCORING, critical: 4, medium: 0.5 },
  }).overall;
  assert.equal(m.score, 60);
  assert.equal(m.deductions[0].points, 40);
});
test("Windows identity requires configured domain and exact sAMAccountName", () => {
  assert.equal(
    normalizeWindowsIdentity("UNIT\\John.Smith", "unit"),
    "john.smith",
  );
  for (const value of [
    "John.Smith",
    "OTHER\\john.smith",
    "UNIT\\john.smith@unit",
    "UNIT\\..\\x",
    "UNIT\\a*)(x)",
  ])
    assert.equal(normalizeWindowsIdentity(value, "UNIT"), null);
});
