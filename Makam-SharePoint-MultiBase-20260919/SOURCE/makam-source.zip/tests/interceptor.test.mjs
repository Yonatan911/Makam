import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { MongoClient } from "mongodb";
test("IISNode interceptor-style require starts the entry after argv rewrite, without require.main equality", async () => {
  await mkdir(".verification", { recursive: true });
  const file = path.resolve(".verification/interceptor-fixture.cjs");
  await writeFile(file, `process.argv.splice(1,1);require(process.argv[1]);`);
  const database = "readiness_test_interceptor_" + Date.now(),
    child = spawn(
      process.execPath,
      [file, path.resolve("backend/src/server.js")],
      {
        windowsHide: true,
        env: {
          ...process.env,
          NODE_ENV: "test",
          AUTO_INITIALIZE_TEST_DB: "true",
          AUTH_MODE: "local",
          PORT: "4183",
          APP_ORIGIN: "http://127.0.0.1:4183",
          MONGODB_URI: "mongodb://127.0.0.1:27028",
          MONGODB_DATABASE: database,
          JOBS_ENABLED: "false",
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );
  let logs = "";
  child.stdout.on("data", (d) => (logs += d));
  child.stderr.on("data", (d) => (logs += d));
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  try {
    let ready = false;
    for (let i = 0; i < 70; i++) {
      try {
        if ((await fetch("http://127.0.0.1:4183/api/health")).ok) {
          ready = true;
          break;
        }
      } catch {}
      if (child.exitCode !== null) throw new Error(logs);
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.equal(ready, true, logs);
  } finally {
    if (child.exitCode === null) {
      const finished = once(child, "exit");
      child.kill();
      await finished;
    }
    await mongo.connect();
    await mongo.db(database).dropDatabase();
    await mongo.close();
  }
});
