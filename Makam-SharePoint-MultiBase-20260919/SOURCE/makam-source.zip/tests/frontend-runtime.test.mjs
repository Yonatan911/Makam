import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { validateRuntime } from "../frontend/src/config/runtime.js";
import { createApiClient } from "../frontend/src/services/client.js";
import {
  createDraft,
  editDraft,
  receiveDraft,
} from "../frontend/src/hooks/useVersionedDraft.js";
import { datetimeInput, israelInputToIso } from "../frontend/src/api.js";
const runtime = validateRuntime({
  schemaVersion: 1,
  apiBaseUrl: "https://api.example/makam/api",
  environment: "production",
  releaseVersion: "3.0.0",
  authMode: "iis-session",
});
const json = (v, status = 200) =>
  new Response(JSON.stringify(v), {
    status,
    headers: { "Content-Type": "application/json" },
  });
test("missing/invalid config fails explicitly; dedicated and prefixed API contracts are consistent", () => {
  assert.throws(() => validateRuntime());
  assert.throws(() => validateRuntime({ ...runtime, apiBaseUrl: "/api" }));
  assert.throws(() =>
    validateRuntime({ ...runtime, apiBaseUrl: "https://sp.example/" }),
  );
  assert.equal(
    validateRuntime({ ...runtime, apiBaseUrl: "https://api.example/api/" })
      .apiBaseUrl,
    "https://api.example/api",
  );
  assert.throws(() => validateRuntime({ ...runtime, authMode: "local" }));
});
test("client CORS-simple exchange and prefix; same client handles JSON, upload and binary without cookies on bearer calls", async () => {
  const calls = [];
  const client = createApiClient({
    runtime,
    fetchImpl: async (url, opts) => {
      calls.push({ url, opts });
      if (url.endsWith("/auth/session"))
        return json({
          token: "a".repeat(64),
          expiresAt: new Date(Date.now() + 60000).toISOString(),
        });
      if (new URL(url).pathname.endsWith("/export"))
        return new Response(new Uint8Array([80, 75]), {
          headers: {
            "Content-Type":
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "Content-Disposition": "attachment; filename=report.xlsx",
          },
        });
      return json({ ok: true });
    },
  });
  await client.json("/state");
  await client.json("/settings", { version: 1 }, "PATCH");
  await client.request("/base-map/image", {
    method: "POST",
    headers: { "Content-Type": "image/png" },
    body: new Blob(["x"]),
  });
  const binary = await client.request("/export?theme=dark");
  assert.equal((await binary.arrayBuffer()).byteLength, 2);
  assert.ok(calls.at(-1).url.endsWith("/export?theme=dark"));
  assert.equal(
    binary.headers.get("Content-Disposition"),
    "attachment; filename=report.xlsx",
  );
  assert.equal(calls[0].opts.credentials, "include");
  assert.equal(calls[0].opts.headers["Content-Type"], "text/plain");
  for (const call of calls.slice(1)) {
    assert.ok(call.url.startsWith("https://api.example/makam/api/"));
    assert.equal(call.opts.credentials, "omit");
    assert.equal(
      call.opts.headers.get("Authorization"),
      "Bearer " + "a".repeat(64),
    );
  }
});
test("API never replays writes; preserves conflict, expired auth, HTML and unknown-network outcomes", async () => {
  for (const [response, state, status] of [
    [json({ error: "parallel update" }, 409), "conflict", 409],
    [json({ error: "expired" }, 401), "authExpired", 401],
    [
      new Response("<html>Login</html>", {
        headers: { "Content-Type": "text/html" },
      }),
      "outcomeUnknown",
      200,
    ],
    [null, "outcomeUnknown", 0],
  ]) {
    let calls = 0;
    const client = createApiClient({
      runtime: { ...runtime, environment: "test", authMode: "local" },
      fetchImpl: async () => {
        calls++;
        if (!response) throw Error("connection reset");
        return response;
      },
    });
    await assert.rejects(
      client.json("/rooms", { name: "new" }),
      (e) => e.state === state && e.status === status,
    );
    assert.equal(calls, 1);
  }
  let calls = 0;
  const client = createApiClient({
    runtime,
    fetchImpl: async () => {
      calls++;
      return json({});
    },
  });
  await assert.rejects(
    client.json("/rooms", { name: "new" }),
    (e) => e.state === "authExpired",
  );
  assert.equal(calls, 0);
});
test("two realistic editor drafts retain their original version after remote update and require explicit reload", () => {
  const original = [{ roomId: "one", x: 10, y: 10 }];
  let editorA = createDraft(original, 3),
    editorB = createDraft(original, 3);
  editorA = editDraft(editorA, (ms) => ms.map((m) => ({ ...m, x: 30 })));
  editorB = editDraft(editorB, (ms) => ms.map((m) => ({ ...m, y: 60 })));
  const savedA = editorA.value,
    remoteVersion = 4;
  editorB = receiveDraft(editorB, savedA, remoteVersion);
  assert.equal(editorB.version, 3);
  assert.equal(editorB.value[0].x, 10);
  assert.equal(editorB.value[0].y, 60);
  assert.notEqual(editorB.version, remoteVersion);
  editorB = createDraft(savedA, remoteVersion);
  assert.equal(editorB.version, 4);
  assert.equal(editorB.value[0].x, 30);
  assert.equal(editorB.dirty, false);
});
test("Israel 24-hour input is independent of workstation time zone, including DST", () => {
  assert.equal(datetimeInput("2026-01-15T21:45:00.000Z"), "2026-01-15T23:45");
  assert.equal(
    israelInputToIso("2026-01-15T23:45"),
    "2026-01-15T21:45:00.000Z",
  );
  assert.equal(
    israelInputToIso("2026-07-15T23:45"),
    "2026-07-15T20:45:00.000Z",
  );
});
test("frontend bootstrap precedes React and polling/object URLs have teardown paths", async () => {
  const html = await readFile("frontend/index.html", "utf8");
  assert.ok(html.indexOf("runtime-config.js") < html.indexOf("/src/main.jsx"));
  assert.match(html, /dir="rtl"/);
  const lifecycle = await readFile(
    "frontend/src/hooks/useDashboardState.js",
    "utf8",
  );
  assert.match(lifecycle, /clearTimeout\(timer\)/);
  assert.match(lifecycle, /controller.current\?\.abort/);
  assert.match(lifecycle, /if\s*\(pending.current\)\s*return pending.current/);
  const image = await readFile(
    "frontend/src/components/AuthenticatedImage.jsx",
    "utf8",
  );
  assert.match(image, /revokeObjectURL/);
  assert.match(image, /active = false/);
});
