import test from "node:test";
import assert from "node:assert/strict";
import { MongoClient } from "mongodb";
import {
  preflight,
  applyMigration,
  restoreMigration,
} from "../backend/src/migrations.js";
test("interruption before backup commit writes no application records; resume re-preflights and preserves bootstrap admin", async () => {
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  await mongo.connect();
  const db = mongo.db("readiness_test_preparation_" + Date.now());
  try {
    const plan = await preflight(db, {
      ownerSam: "m9267680",
      adminSam: "c9812933",
    });
    await assert.rejects(
      applyMigration(db, plan, {
        onPreparation: () => {
          throw Error("interruption before apply");
        },
      }),
      /interruption/,
    );
    assert.equal(await db.collection("users").countDocuments(), 0);
    assert.equal(await db.collection("settings").countDocuments(), 0);
    const { runId } = await db
      .collection("migrationRuns")
      .findOne({ _id: "active" });
    await assert.rejects(restoreMigration(db, runId), /Incomplete backup/);
    await applyMigration(db, null, { resumeId: runId });
    assert.equal(
      (await db.collection("users").findOne({ username: "m9267680" })).role,
      "owner",
    );
    assert.equal(
      (await db.collection("users").findOne({ username: "c9812933" })).role,
      "admin",
    );
    assert.equal(
      await db.collection("migrationRuns").findOne({ _id: "active" }),
      null,
    );
  } finally {
    await db.dropDatabase();
    await mongo.close();
  }
});
