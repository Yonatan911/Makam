import { connectDatabase } from "../../backend/src/database.js";
import { preflight, applyMigration } from "../../backend/src/migrations.js";
// Explicit regression fixture helper, never imported by the normal server.
export async function initializeDatabase() {
  const database = process.env.MONGODB_DATABASE;
  if (!database?.startsWith("readiness_test_"))
    throw new Error("Only isolated test database allowed");
  const connection = await connectDatabase({
    mongoUri: process.env.MONGODB_URI || "mongodb://127.0.0.1:27028",
    database,
  });
  try {
    const plan = await preflight(connection.db, {
      ownerSam: process.env.BOOTSTRAP_OWNER_SAM || "admin",
      adminSam: process.env.BOOTSTRAP_ADMIN_SAM,
    });
    await applyMigration(connection.db, plan);
    return connection;
  } catch (e) {
    await connection.client.close();
    throw e;
  }
}
