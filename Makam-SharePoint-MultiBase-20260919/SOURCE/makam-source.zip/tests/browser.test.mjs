import test from "node:test";
import assert from "node:assert/strict";
import { chromium } from "playwright";
import express from "express";
import { MongoClient } from "mongodb";
import sharp from "sharp";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { createApp } from "../backend/src/app.js";
import { loadConfiguration } from "../backend/src/config.js";
import { initializeForTest } from "../backend/src/migrations.js";
import { buildFrontend } from "../scripts/build.mjs";

test("real Chromium: nested SharePoint adapter, runtime failure, workflows, PNG, dark/light and two dirty map editors", async () => {
  const release = process.env.MAKAM_TEST_RELEASE_ROOT;
  if (!release) await buildFrontend();
  const front = path.resolve(
    release ? path.join(release, "FRONT") : ".build/FRONT",
  );
  const packaged = release
    ? createRequire(path.resolve(release, "SERVER/package.json"))
    : null;
  const makeApp = packaged ? packaged("./src/app.js").createApp : createApp;
  const readConfig = packaged
    ? packaged("./src/config.js").loadConfiguration
    : loadConfiguration;
  const initialize = packaged
    ? packaged("./src/migrations.js").initializeForTest
    : initializeForTest;
  const mongo = new MongoClient("mongodb://127.0.0.1:27028");
  await mongo.connect();
  const db = mongo.db("readiness_test_browser_" + Date.now());
  const base = "http://127.0.0.1:4179",
    apiOrigin = "http://127.0.0.1:4180",
    library = "/sites/operations/SiteAssets/Makam";
  const config = readConfig({
    env: {
      NODE_ENV: "test",
      AUTH_MODE: "local-test",
      ENABLE_LOCAL_TEST_LOGIN: "true",
      PORT: "4180",
      PUBLIC_API_URL: apiOrigin + "/makam/api",
      SHAREPOINT_ORIGIN: base,
      MONGODB_DATABASE: db.databaseName,
      BOOTSTRAP_OWNER_SAM: "m9267680",
      BOOTSTRAP_ADMIN_SAM: "c9812933",
    },
  });
  await initialize(db, config);
  const app = express();
  const runtime = `window.MAKAM_RUNTIME_CONFIG=Object.freeze(${JSON.stringify({ schemaVersion: 1, apiBaseUrl: config.apiBaseUrl, environment: "test", releaseVersion: "3.1.0", authMode: "local-test" })});`;
  app.get(library + "/runtime-config.js", (req, res) =>
    res
      .type("application/javascript")
      .send(req.query.invalid ? "window.MAKAM_RUNTIME_CONFIG=null;" : runtime),
  );
  app.use(library, express.static(front));
  app.get("/sp-page", (req, res) =>
    res
      .type("html")
      .send(
        `<html lang="he" dir="rtl"><body><script src="${library}/loader.js"></script></body></html>`,
      ),
  );
  app.get("/invalid", (req, res) =>
    res
      .type("html")
      .send(
        `<html lang="he" dir="rtl"><script src="${library}/runtime-config.js?invalid=1"></script><div id="root"></div><script type="module" src="${library}/${(awaitIndex.match(/src="(\.\/assets\/[^\"]+\.js)"/) || [])[1]?.slice(2)}"></script></html>`,
      ),
  );
  const awaitIndex = await readFile(path.join(front, "index.html"), "utf8");
  const server = app.listen(4179, "127.0.0.1");
  const apiServer = (await makeApp({ db, config })).listen(4180, "127.0.0.1");
  await Promise.all(
    [server, apiServer].map((s) => new Promise((r) => s.once("listening", r))),
  );
  let browser;
  try {
    browser = await chromium.launch({
      headless: true,
      executablePath:
        process.env.CHROME_PATH ||
        "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    });
    const contextA = await browser.newContext({
        viewport: { width: 1440, height: 1000 },
        timezoneId: "America/New_York",
      }),
      contextB = await browser.newContext({
        viewport: { width: 1366, height: 900 },
        timezoneId: "Asia/Jerusalem",
      }),
      pageA = await contextA.newPage(),
      pageB = await contextB.newPage(),
      errors = [],
      external = [];
    for (const page of [pageA, pageB]) {
      page.on("pageerror", (e) => errors.push(e.message));
      page.on("request", (r) => {
        if (
          !r.url().startsWith(base) &&
          !r.url().startsWith(apiOrigin) &&
          !r.url().startsWith("blob:") &&
          !r.url().startsWith("data:")
        )
          external.push(r.url());
      });
    }
    await pageA.goto(base + "/invalid");
    await pageA
      .getByRole("heading", { name: "לא ניתן להפעיל את מכ״ם" })
      .waitFor();
    assert.equal(await db.collection("sessions").countDocuments(), 0);
    const login = async (page) => {
      await page.goto(base + "/sp-page");
      const frame = page.frameLocator("iframe");
      await frame
        .locator(".account-list button")
        .filter({ hasText: "m9267680" })
        .click();
      await frame
        .getByRole("heading", { name: "תמונת מצב", exact: true })
        .waitFor();
      return frame;
    };
    const a = await login(pageA),
      b = await login(pageB);
    let selectedBase;
    const api = async (route, body, method = body ? "POST" : "GET") => {
      const r = await pageA.evaluate(
        async ({ url, body, method, baseId }) => {
          const response = await fetch(url, {
            method,
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
              "X-Readiness-Client": "dashboard",
              ...(baseId ? { "X-Base-Id": baseId } : {}),
            },
            ...(body ? { body: JSON.stringify(body) } : {}),
          });
          return { ok: response.ok, text: await response.text() };
        },
        { url: config.apiBaseUrl + route, body, method, baseId: selectedBase },
      );
      assert.ok(r.ok, r.text);
      return JSON.parse(r.text);
    };
    selectedBase = (await api("/bases"))[0].id;
    const room = (
      await api("/rooms", { name: "חמ״ל בדיקת דפדפן", type: "חמ״ל" })
    ).id;
    const asset = await api(`/rooms/${room}/assets/bulk`, {
      version: 1,
      assets: [
        {
          name: "PC-TEST-01",
          kind: "computer",
          critical: false,
          status: "healthy",
          category: "computing",
          network: "שחורה",
          ip: "10.0.0.1",
          phone: "",
          parentIds: [],
          backupIds: [],
          note: "",
        },
      ],
    });
    assert.ok(asset);
    await pageA.reload();
    await a.getByRole("heading", { name: "תמונת מצב", exact: true }).waitFor();
    await a.getByRole("button", { name: "דוחות ותובנות", exact: true }).click();
    await a
      .getByRole("heading", { name: "דוחות ותובנות", exact: true })
      .waitFor();
    const excelPromise = pageA.waitForEvent("download");
    await a.getByRole("button", { name: "ייצוא דוח Excel מלא" }).click();
    const excel = await excelPromise;
    assert.ok(excel.suggestedFilename().endsWith(".xlsx"));
    await mkdir(".verification/browser", { recursive: true });
    await excel.saveAs(".verification/browser/report.xlsx");
    const excelHeaders = await pageA.evaluate(async (url) => {
      const r = await fetch(url, { credentials: "include" });
      return {
        status: r.status,
        disposition: r.headers.get("content-disposition"),
        bytes: (await r.arrayBuffer()).byteLength,
      };
    }, config.apiBaseUrl + "/export");
    assert.equal(excelHeaders.status, 200);
    assert.match(excelHeaders.disposition, /attachment/);
    assert.ok(excelHeaders.bytes > 0);
    await mkdir(".verification/browser", { recursive: true });
    await pageA.screenshot({
      path: ".verification/browser/light.png",
      fullPage: true,
    });
    const pngPromise = pageA.waitForEvent("download");
    await a
      .getByRole("button", { name: /שמירת תמונת מצב/ })
      .first()
      .click();
    const png = await pngPromise;
    await png.saveAs(".verification/browser/snapshot.png");
    const meta = await sharp(".verification/browser/snapshot.png").metadata();
    assert.ok(meta.width >= 1000 && meta.height > 0);
    await api("/preferences", { theme: "dark" }, "PATCH");
    await pageA.reload();
    await a.getByRole("heading", { name: "תמונת מצב", exact: true }).waitFor();
    await pageA.screenshot({
      path: ".verification/browser/dark.png",
      fullPage: true,
    });
    const theme = await a.locator("html").getAttribute("data-theme");
    assert.equal(theme, "dark");
    // Upload and initial marker through the real protected API; two independent browser cookies edit the map.
    const image = await sharp({
      create: { width: 600, height: 400, channels: 3, background: "#537478" },
    })
      .png()
      .toBuffer();
    const response = await pageA.evaluate(
      async ({ url, bytes }) => {
        const r = await fetch(url, {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "image/png",
            "X-Readiness-Client": "dashboard",
          },
          body: new Uint8Array(bytes),
        });
        return { status: r.status };
      },
      { url: config.apiBaseUrl + "/base-map/image", bytes: [...image] },
    );
    assert.equal(response.status, 201);
    let state = await api("/state");
    await api(
      "/base-map/markers",
      {
        version: state.settings.version,
        markers: [{ roomId: room, x: 10, y: 10 }],
      },
      "PUT",
    );
    await Promise.all([pageA.reload(), pageB.reload()]);
    const openMap = async (frame) => {
      await frame.locator(".base-link").click();
      await frame.locator(".base-map").waitFor();
    };
    await openMap(a);
    await openMap(b);
    await a.getByLabel("מרחב למיקום מדויק").selectOption(room);
    await b.getByLabel("מרחב למיקום מדויק").selectOption(room);
    await a.getByLabel("מיקום אופקי (%)").fill("30");
    await b.getByLabel("מיקום אנכי (%)").fill("60");
    await a.getByRole("button", { name: "שמירת מיקומי מרחבים" }).click();
    await a.locator(".base-map").waitFor({ state: "hidden" });
    await b
      .getByText("המפה עודכנה בזמן העריכה.", { exact: false })
      .waitFor({ timeout: 40000 });
    assert.equal(await b.getByLabel("מיקום אנכי (%)").inputValue(), "60");
    assert.equal(await b.getByLabel("מיקום אופקי (%)").inputValue(), "10");
    assert.equal(
      await b.getByRole("button", { name: "שמירת מיקומי מרחבים" }).isDisabled(),
      true,
    );
    await pageB.screenshot({
      path: ".verification/browser/map-conflict.png",
      fullPage: true,
    });
    await b
      .getByRole("button", { name: "טעינת המפה המעודכנת וביטול הטיוטה" })
      .click();
    assert.equal(await b.getByLabel("מיקום אופקי (%)").inputValue(), "30");
    assert.equal(await b.getByLabel("מיקום אנכי (%)").inputValue(), "10");
    const latestRoom = (await api("/state")).rooms.find((r) => r.id === room);
    await api(
      `/rooms/${room}/assets/${asset.ids[0]}`,
      { version: latestRoom.version, reason: "בדיקת DELETE בדפדפן" },
      "DELETE",
    );
    const archivedRoom = (await api("/state")).rooms.find((r) => r.id === room);
    assert.equal(
      archivedRoom.archivedAssets.find((a) => a.id === asset.ids[0]).archived,
      true,
    );
    await api(`/rooms/${room}/assets/${asset.ids[0]}/restore`, {
      version: archivedRoom.version,
    });
    const secondBase = (
      await api("/bases", { name: "בסיס נוסף — בדיקת מידור" })
    ).id;
    await pageA.reload();
    await a.getByLabel("בחירת בסיס").waitFor();
    assert.equal(await a.getByLabel("בחירת בסיס").locator("option").count(), 2);
    await a
      .getByRole("button", { name: "תמונת מצב פיקודית", exact: true })
      .click();
    await a.locator(".command-card").first().waitFor();
    assert.equal(await a.locator(".command-card").count(), 2);
    await pageA.screenshot({
      path: ".verification/browser/command-dark.png",
      fullPage: true,
    });
    const commandExcelPromise = pageA.waitForEvent("download");
    await a
      .locator(".command-actions")
      .getByRole("button", { name: "ייצוא Excel", exact: true })
      .click();
    await (
      await commandExcelPromise
    ).saveAs(".verification/browser/command.xlsx");
    const commandPngPromise = pageA.waitForEvent("download");
    await a
      .locator(".command-actions")
      .getByRole("button", { name: "שמירת תמונת מצב", exact: true })
      .click();
    await (await commandPngPromise).saveAs(".verification/browser/command.png");
    await a.getByLabel("בחירת בסיס").selectOption(secondBase);
    await a.getByRole("heading", { name: "תמונת מצב", exact: true }).waitFor();
    assert.equal(
      await a
        .locator(".base-link")
        .innerText()
        .then((s) => s.includes("בסיס נוסף")),
      true,
    );
    assert.equal(
      await a.getByText("חמ״ל בדיקת דפדפן", { exact: true }).count(),
      0,
    );
    // A single-base admin's real browser must have no selector or global command navigation.
    const localAdmin = await db
      .collection("users")
      .findOne({ username: "test.admin" });
    await pageB.evaluate(
      async ({ url, id }) => {
        await fetch(url + "/auth/local-login", {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            "X-Readiness-Client": "dashboard",
          },
          body: JSON.stringify({ userId: id }),
        });
      },
      { url: config.apiBaseUrl, id: localAdmin.id },
    );
    await pageB.reload();
    await b.getByRole("heading", { name: "תמונת מצב", exact: true }).waitFor();
    assert.equal(await b.getByLabel("בחירת בסיס").count(), 0);
    assert.equal(
      await b
        .getByRole("button", { name: "תמונת מצב פיקודית", exact: true })
        .count(),
      0,
    );
    const denied = await pageB.evaluate(
      async ({ url, id }) => {
        const command = await fetch(url + "/command-overview", {
          credentials: "include",
        });
        const foreign = await fetch(url + "/state", {
          credentials: "include",
          headers: { "X-Base-Id": id },
        });
        return [command.status, foreign.status];
      },
      { url: config.apiBaseUrl, id: secondBase },
    );
    assert.deepEqual(denied, [403, 403]);
    assert.deepEqual(external, []);
    assert.deepEqual(errors, []);
    await writeFile(
      ".verification/browser/result.json",
      JSON.stringify(
        {
          status: "PASS",
          browser: "Chromium",
          browserVersion: browser.version(),
          testedRelease: release || "source build",
          crossOrigin: true,
          excelDownload: excel.suggestedFilename(),
          nestedAssets: true,
          externalRequests: external.length,
          errors,
          PNG: { width: meta.width, height: meta.height },
          mapContexts: 2,
          rtl: true,
          themes: ["light", "dark"],
          multiBase: {
            bases: 2,
            commandExport: true,
            selection: true,
            singleBaseSelectorHidden: true,
            crossBaseDenial: true,
          },
        },
        null,
        2,
      ),
    );
  } finally {
    await browser?.close();
    await new Promise((r) => server.close(r));
    await new Promise((r) => apiServer.close(r));
    await db.dropDatabase();
    await mongo.close();
  }
});
