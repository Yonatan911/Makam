export const CATEGORIES = {
  computing: "מחשוב",
  telephony: "טלפוניה",
  display: "תצוגה",
  power: "גיבוי חשמל",
};
export const STATUSES = {
  healthy: "תקין",
  faulty: "תקול",
  in_progress: "בטיפול",
  waiting: "ממתין לחלפים או לגורם חוץ",
  repaired: "תוקן, ממתין לאימות",
  closed: "נסגר",
  maintenance: "תחזוקה מתוכננת",
};
export const ROLES = {
  owner: "בעלים",
  admin: "מנהל מערכת",
  command_admin: "מנהל מערכת פיקודי",
  technician: "טכנאי",
  commander: "מפקד מרחב",
  viewer: "נציג מרחב",
};
export const ROOM_TYPES = ["חמ״ל", "חד״ן"];
export const KINDS = {
  computer: "מחשב",
  server: "שרת",
  switch: "מתג תקשורת",
  router: "נתב",
  phone: "טלפון",
  screen: "מסך",
  matrix: "מטריצת תצוגה",
  projector: "מקרן",
  ups: "אל־פסק (UPS)",
  power: "לוח חשמל",
  printer: "מדפסת",
  radio: "מכשיר קשר",
  camera: "מצלמה",
  other: "אמצעי אחר",
};
export const REQUEST_STATUSES = {
  pending: "ממתינה לאישור",
  approved: "אושרה — נדרשת בדיקה",
  rejected: "לא אושרה",
  completed: "הבדיקה הושלמה",
  cancelled: "בוטלה",
};
export const WEEKDAYS = [
  "ראשון",
  "שני",
  "שלישי",
  "רביעי",
  "חמישי",
  "שישי",
  "שבת",
];
export const ACTIVE = ["faulty", "in_progress", "waiting", "repaired"];
export const TRANSITIONS = {
  healthy: ["faulty", "maintenance"],
  faulty: ["in_progress", "waiting", "repaired"],
  in_progress: ["waiting", "repaired"],
  waiting: ["in_progress", "repaired"],
  repaired: ["closed", "faulty"],
  closed: ["faulty", "maintenance"],
  maintenance: ["healthy", "faulty"],
};
export const DEFAULT_SCORING = {
  critical: 3,
  regular: 1,
  low: 0.25,
  medium: 0.6,
  high: 1,
};
export const isManager = (user) => ["owner", "command_admin", "admin"].includes(user?.role);
export const readinessBand = (score) =>
  score == null
    ? "unknown"
    : score > 90
      ? "green"
      : score >= 70
        ? "orange"
        : "red";
export function sortRooms(rooms, order = "name") {
  const byName = (a, b) => a.name.localeCompare(b.name, "he");
  return [...rooms].sort((a, b) => {
    if (order === "name") return byName(a, b);
    if (order === "check-oldest" || order === "check-newest") {
      const first = a.lastCheck?.at ? Date.parse(a.lastCheck.at) : 0;
      const second = b.lastCheck?.at ? Date.parse(b.lastCheck.at) : 0;
      return (
        (order === "check-newest" ? second - first : first - second) ||
        byName(a, b)
      );
    }
    const x = a.metrics.overall.score,
      y = b.metrics.overall.score;
    if (x == null || y == null)
      return (x == null ? 1 : 0) - (y == null ? 1 : 0) || byName(a, b);
    return (order === "score-high" ? y - x : x - y) || byName(a, b);
  });
}
export const hasRoomAccess = (user, roomId) =>
  isManager(user) ||
  user?.allRooms === true ||
  (user?.roomIds || []).includes(roomId);
export const canEditRoom = (user, roomId) =>
  isManager(user) ||
  (user?.role === "technician" && hasRoomAccess(user, roomId));
// Read legacy single-parent records without changing their stored history.
export const dependencyIds = (asset) =>
  asset.parentIds ??
  (asset.dependency === "hard" && asset.parentId ? [asset.parentId] : []);
export const activeAssets = (room) =>
  (room.assets || []).filter((a) => !a.archived);
export const weight = (a, settings = {}) =>
  a.critical ? settings.scoring?.critical || 3 : settings.scoring?.regular || 1;
export function assetProfile(kind) {
  const computer = ["computer", "server"].includes(kind),
    network = [
      "computer",
      "server",
      "switch",
      "router",
      "printer",
      "camera",
    ].includes(kind);
  return {
    nameLabel: computer
      ? "שם מחשב"
      : kind === "phone"
        ? "שם טלפון"
        : "שם אמצעי",
    ip: network,
    network: network || ["phone", "radio"].includes(kind),
    phone: kind === "phone",
    serial: true,
    defaultCategory:
      kind === "ups" || kind === "power"
        ? "power"
        : ["phone", "radio"].includes(kind)
          ? "telephony"
          : ["screen", "matrix", "projector"].includes(kind)
            ? "display"
            : "computing",
  };
}
export function effectiveAsset(
  asset,
  assets,
  visited = new Set(),
  settings = {},
) {
  if (visited.has(asset.id) || asset.archived)
    return { loss: 0, causes: [], causeIds: [], planned: !!asset.archived };
  const next = new Set(visited).add(asset.id);
  if (asset.status === "maintenance")
    return { loss: 0, causes: [], causeIds: [], planned: true };
  const upstream = dependencyIds(asset)
    .map((id) => assets.find((p) => !p.archived && p.id === id))
    .filter(Boolean)
    .map((parent) => effectiveAsset(parent, assets, next, settings));
  if (upstream.some((p) => p.planned))
    return { loss: 0, causes: [], causeIds: [], planned: true };
  const own = ACTIVE.includes(asset.status)
    ? (settings.scoring?.[asset.severity] ??
      DEFAULT_SCORING[asset.severity] ??
      1)
    : 0;
  return {
    loss: Math.max(own, ...upstream.map((p) => p.loss)),
    causes: [
      ...new Set([
        ...(own ? [asset.name] : []),
        ...upstream.flatMap((p) => p.causes),
      ]),
    ],
    causeIds: [
      ...new Set([
        ...(own ? [asset.id] : []),
        ...upstream.flatMap((p) => p.causeIds),
      ]),
    ],
    planned: false,
  };
}
export function readiness(room, settings = {}) {
  const source = activeAssets(room),
    all = source.map((a) => ({
      ...a,
      ...effectiveAsset(a, source, new Set(), settings),
    }));
  const calc = (list) => {
    const eligible = room.maintenance ? [] : list.filter((a) => !a.planned),
      totalWeight = eligible.reduce((n, a) => n + weight(a, settings), 0),
      lossWeight = eligible.reduce(
        (n, a) => n + weight(a, settings) * a.loss,
        0,
      ),
      score = totalWeight
        ? Math.round(100 * (1 - lossWeight / totalWeight))
        : null;
    const deductions = eligible
      .filter((a) => a.loss > 0)
      .map((a) => ({
        id: a.id,
        name: a.name,
        kind: a.kind,
        weight: weight(a, settings),
        severity: a.severity,
        impact: a.loss,
        points:
          Math.round(((weight(a, settings) * a.loss) / totalWeight) * 1000) /
          10,
        causes: a.causes,
        inherited: !ACTIVE.includes(a.status),
        note: a.note || "",
      }));
    return {
      score,
      totalWeight,
      lossWeight,
      assetCount: eligible.length,
      excludedCount: list.length - eligible.length,
      deductions,
      scoring: settings.scoring || DEFAULT_SCORING,
      explanation: room.maintenance
        ? "המרחב נמצא בהשבתה מתוכננת ואינו נכלל בחישוב"
        : !totalWeight
          ? "אין אמצעים בתחום זה; הוא אינו משפיע על הציון"
          : deductions.length
            ? deductions
                .map(
                  (d) =>
                    `${d.name}: ${d.points} נקודות עקב ${d.causes.join(", ")}`,
                )
                .join("\n")
            : "כל האמצעים בתחום תקינים",
    };
  };
  return {
    overall: calc(all),
    categories: Object.fromEntries(
      Object.keys(CATEGORIES).map((c) => [
        c,
        calc(all.filter((a) => a.category === c)),
      ]),
    ),
    planned: room.maintenance
      ? all.length
      : all.filter((a) => a.planned).length,
    impacted: room.maintenance
      ? 0
      : all.filter((a) => a.loss > 0 && !a.planned).length,
    warning:
      !room.maintenance &&
      all.some((a) => a.kind === "ups" && a.loss > 0 && !a.planned),
    hasUps: all.some((a) => a.kind === "ups"),
    assets: all,
  };
}
export function localParts(now = Date.now()) {
  return Object.fromEntries(
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Jerusalem",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
    })
      .formatToParts(new Date(now))
      .filter((p) => p.type !== "literal")
      .map((p) => [p.type, Number(p.value)]),
  );
}
export function israelTime(year, month, day, hour = 0, minute = 0) {
  const wall = Date.UTC(year, month - 1, day, hour, minute);
  let value = wall;
  for (let i = 0; i < 3; i++) {
    const p = localParts(value);
    const rendered = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute);
    value += wall - rendered;
  }
  return value;
}
export function scheduleState(room, settings, now = Date.now()) {
  const schedule = room.scheduleOverride || settings.schedule;
  if (!schedule?.enabled || room.maintenance)
    return { enabled: false, overdue: false };
  const p = localParts(now),
    day = new Date(Date.UTC(p.year, p.month - 1, p.day)).getUTCDay(),
    delta = (day - schedule.day + 7) % 7,
    cycleDate = new Date(Date.UTC(p.year, p.month - 1, p.day - delta)),
    [h, m] = (schedule.time || "17:00").split(":").map(Number);
  const start = israelTime(
      cycleDate.getUTCFullYear(),
      cycleDate.getUTCMonth() + 1,
      cycleDate.getUTCDate(),
    ),
    due = israelTime(
      cycleDate.getUTCFullYear(),
      cycleDate.getUTCMonth() + 1,
      cycleDate.getUTCDate(),
      h,
      m,
    ),
    nextDate = new Date(cycleDate.getTime() + 7 * 86400000),
    nextDue = israelTime(
      nextDate.getUTCFullYear(),
      nextDate.getUTCMonth() + 1,
      nextDate.getUTCDate(),
      h,
      m,
    ),
    completed =
      !!room.lastCheck && new Date(room.lastCheck.at).getTime() >= start;
  return {
    enabled: true,
    day: schedule.day,
    time: schedule.time,
    cycleStart: new Date(start).toISOString(),
    dueAt: new Date(due).toISOString(),
    nextDueAt: new Date(completed ? nextDue : due).toISOString(),
    completed,
    overdue: !completed && now > due,
  };
}
export function freshness(room, settings, now = Date.now()) {
  if (room.maintenance) return "planned";
  if ((room.requests || []).some((r) => r.status === "approved"))
    return "expired";
  const time = room.lastCheck ? new Date(room.lastCheck.at).getTime() : 0;
  if (
    !time ||
    (settings.round?.roomIds?.includes(room.id) &&
      room.lastCheck?.roundId !== settings.round.id) ||
    scheduleState(room, settings, now).overdue
  )
    return "expired";
  const ratio = (now - time) / ((settings.freshnessDays || 7) * 86400000);
  return ratio >= 1 ? "expired" : ratio >= 0.75 ? "aging" : "fresh";
}
export function aggregate(rooms, explain = false, settings = {}) {
  const calculated = rooms.map((r) => readiness(r, settings));
  const metric = (key) => {
    const list = calculated.map((c) => (key ? c.categories[key] : c.overall)),
      totalWeight = list.reduce((n, c) => n + c.totalWeight, 0),
      lossWeight = list.reduce((n, c) => n + c.lossWeight, 0),
      score = totalWeight
        ? Math.round(100 * (1 - lossWeight / totalWeight))
        : null;
    const deductions = list.flatMap((c, i) =>
      c.deductions.map((d) => ({
        ...d,
        roomName: rooms[i].name,
        name: rooms[i].name + " / " + d.name,
        points: totalWeight
          ? Math.round(((d.weight * d.impact) / totalWeight) * 1000) / 10
          : 0,
      })),
    );
    return {
      score,
      totalWeight,
      lossWeight,
      deductions,
      assetCount: list.reduce((n, c) => n + c.assetCount, 0),
      excludedCount: list.reduce((n, c) => n + c.excludedCount, 0),
      scoring: settings.scoring || DEFAULT_SCORING,
      explanation: totalWeight
        ? deductions.length
          ? deductions
              .map((d) => `${d.name}: ירידה של ${d.points} נקודות`)
              .join("\n")
          : "כל האמצעים הנכללים בחישוב תקינים"
        : "אין אמצעים הנכללים בחישוב",
    };
  };
  const overallMetric = metric(),
    categoryMetrics = Object.fromEntries(
      Object.keys(CATEGORIES).map((k) => [k, metric(k)]),
    );
  return {
    overall: overallMetric.score,
    categories: Object.fromEntries(
      Object.entries(categoryMetrics).map(([k, v]) => [k, v.score]),
    ),
    ...(explain ? { overallMetric, categoryMetrics } : {}),
  };
}
export function publicRoom(room, user, settings) {
  const manager = isManager(user),
    commander = user.role === "commander",
    viewer = user.role === "viewer";
  const active = activeAssets(room).map(({ checkedBy, checkedById, ...a }) => ({
    ...a,
    ...(manager || commander ? { checkedBy, checkedById } : {}),
  }));
  const metrics = readiness({ ...room, assets: active }, settings);
  const result = {
    id: room.id,
    name: room.name,
    type: room.type,
    note: room.note || "",
    maintenance: room.maintenance,
    version: room.version,
    demo: !!room.demo,
    assets: active,
    metrics,
    freshness: freshness(room, settings),
    schedule: scheduleState(room, settings),
    scheduleOverride: room.scheduleOverride || null,
    plan: room.plan,
    lastCheck: room.lastCheck
      ? manager || commander
        ? room.lastCheck
        : { at: room.lastCheck.at, roundId: room.lastCheck.roundId }
      : null,
    lastPartialCheck: room.lastPartialCheck
      ? manager || commander
        ? room.lastPartialCheck
        : { at: room.lastPartialCheck.at }
      : null,
  };
  if (manager) {
    result.archivedAssets = (room.assets || []).filter((a) => a.archived);
    result.audit = room.audit || [];
    result.faults = room.faults || [];
    result.requests = room.requests || [];
  } else if (commander) {
    result.faults = (room.faults || []).map(({ history, ...f }) => f);
    result.requests = (room.requests || []).map(({ mailEvents, ...r }) => r);
    result.checks = (room.audit || []).filter(
      (a) => a.action === "בדיקת כשירות" || a.action === "בדיקה ממוקדת",
    );
  } else if (!viewer) {
    result.faults = (room.faults || [])
      .filter((f) => f.status !== "closed")
      .map(
        ({
          history,
          openedBy,
          openedById,
          openedAt,
          closedBy,
          closedById,
          ...f
        }) => f,
      );
    result.requests = (room.requests || [])
      .filter((r) => r.status === "approved")
      .map(({ requestedById, history, ...r }) => r);
  } else {
    result.faults = (room.faults || [])
      .filter((f) => f.status !== "closed")
      .map(({ id, assetId, status, description, severity }) => ({
        id,
        assetId,
        status,
        description,
        severity,
      }));
    result.requests = [];
  }
  return result;
}
