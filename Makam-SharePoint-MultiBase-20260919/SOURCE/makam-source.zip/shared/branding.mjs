export const APP_NAME = 'מכ"ם';
export const APP_DESCRIPTION = "מערכת כשירות מרחבית";
