param([switch]$NoBrowser)
$ErrorActionPreference='Stop'
$previewRoot=$PSScriptRoot
$workspaceRoot=Split-Path (Split-Path $previewRoot -Parent) -Parent
$previewLogs=Join-Path $previewRoot '.runtime\preview-3.1'
New-Item -ItemType Directory -Path $previewLogs -Force | Out-Null
$previewNode=Join-Path $workspaceRoot 'runtime\node\node.exe'
if (-not (Test-Path -LiteralPath $previewNode)) { throw 'Existing local Node runtime not found. See GUIDE/INSTALLATION.he.md for developer setup.' }
$previewReady=$false
try {
  $previewHealth=Invoke-RestMethod 'http://127.0.0.1:4322/api/health' -TimeoutSec 2
  if ($previewHealth.version -ne '3.1.0-multibase') { throw 'Port 4322 belongs to another application.' }
  $previewReady=$previewHealth.ok
} catch { if ($_.Exception.Message -like '*belongs to another*') { throw } }
if (-not $previewReady) {
  # Explicit local test startup only. Reuse a running local Mongo when available.
  $previewMongoReady=Test-NetConnection 127.0.0.1 -Port 27029 -InformationLevel Quiet -WarningAction SilentlyContinue
  if (-not $previewMongoReady) {
    $previewMongo=Join-Path $env:ProgramFiles 'MongoDB\Server\8.0\bin\mongod.exe'
    if (-not (Test-Path -LiteralPath $previewMongo)) { throw 'Existing local MongoDB not found. Start the approved local test MongoDB on 127.0.0.1:27029.' }
    $previewData=Join-Path $previewLogs 'mongo-data'
    New-Item -ItemType Directory -Path $previewData -Force | Out-Null
    Start-Process -FilePath $previewMongo -ArgumentList @('--dbpath', ('"'+$previewData+'"'),'--port','27029','--bind_ip','127.0.0.1','--logpath', ('"'+(Join-Path $previewLogs 'mongodb.log')+'"'),'--logappend') -WorkingDirectory $previewRoot -WindowStyle Hidden | Out-Null
  }
  $previewEntry=Join-Path $previewRoot 'scripts\local-preview.mjs'
  $previewProcess=Start-Process -FilePath $previewNode -ArgumentList ('"'+$previewEntry+'"') -WorkingDirectory $previewRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $previewLogs 'server.log') -RedirectStandardError (Join-Path $previewLogs 'server-error.log')
  for ($previewAttempt=0; $previewAttempt -lt 45; $previewAttempt++) {
    Start-Sleep -Seconds 1
    if ($previewProcess.HasExited) { throw ('Preview failed. See '+(Join-Path $previewLogs 'server-error.log')) }
    try { $previewHealth=Invoke-RestMethod 'http://127.0.0.1:4322/api/health' -TimeoutSec 2; if ($previewHealth.ok -and $previewHealth.version -eq '3.1.0-multibase') { $previewReady=$true; break } } catch {}
  }
  if (-not $previewReady) { throw 'Preview did not start. See .runtime/preview-3.1 logs.' }
}
Write-Output 'Isolated multi-base preview: http://127.0.0.1:4322 (readiness_test_multibase_preview)'
if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:4322' -WindowStyle Hidden }
